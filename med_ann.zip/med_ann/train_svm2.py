import numpy as np
from sklearn import svm
import pickle
import pandas
from sklearn.model_selection import cross_val_score
import sys
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.model_selection import KFold
from logger import Logger
from config import Config
import tensorflow as tf
import os



'''
Link: https://scikit-learn.org/stable/modules/generated/sklearn.svm.SVC.html
Methods

decision_function(X)Evaluates the decision function for the samples in X.
fit(X, y[, sample_weight])Fit the SVM model according to the given training data.
get_params([deep])Get parameters for this estimator.
predict(X)Perform classification on samples in X.
score(X, y[, sample_weight])Returns the mean accuracy on the given test data and labels.
set_params(**params)Set the parameters of this estimator.
'''

'''
for SVM options:
https://scikit-learn.org/stable/modules/generated/sklearn.svm.SVC.html
kernel: one of ‘linear’, ‘poly’, ‘rbf’, ‘sigmoid’, ‘precomputed’ or a callable, default:rbf
gamma: Kernel coefficient for ‘rbf’, ‘poly’ and ‘sigmoid’.
decision_function_shape : ‘ovo’:one vs one, ‘ovr’: one vs. rest, default=’ovr’
'''

SEED=7
conf=None
log=None
labels={}



#########################################################################
def get_gamma():
   str_v = conf.get_prop('gamma')
   if str_v == None: return 'auto'
   try:
      return float(str_v)
   except:
      return str_v
##########################################################################
def train(X,Y):
   gamma_ = get_gamma()
   print('gamma:',gamma_)
   deg = conf.get_as_int('degree')
   kernel_ = conf.get_prop('kernel')
   max_iter_ = conf.get_as_int('max_iter')
   coef = conf.get_as_float('coef0')
   C_= conf.get_as_float('C')
   verb = conf.get_as_int('verbose')
   clf = svm.SVC(C=C_, cache_size=200, class_weight=None, coef0=coef,
        decision_function_shape='ovo', degree=deg, gamma=gamma_, kernel=kernel_,
        max_iter=max_iter_, probability=False, random_state=None, shrinking=True,
                 tol=0.001, verbose=verb)
   log.log_msg("svm_params:",clf)
   clf.fit(X,Y)
   ##tf.contrib.learn.SVM.export_savedmodel(export_dir_base="svm_models/",serving_input_receiver_fn=serving_input_receiver_fun)
  
   scores = cross_val_score(clf,X,Y,cv=10)
   ##scores = clf.score(X,Y)
   print("scores accuracy/fold:", scores)
   log.log_msg("scores:",scores)
   log.log_msg("avg accuracy:", scores.mean())
   log.log_msg("std:" , scores.std()*2)
   ##saved_model(clf,"svm_models/abc.tlite")

def trainNuSvm(X,Y):
   gamma_ = get_gamma()
   deg = conf.get_as_int('degree')
   kernel_ = conf.get_prob('kernel')
   max_iter_ = conf.get_as_int('max_iter')
   coef = conf.get_as_float('coef0')
   C_= conf.get_as_int('C')
   verb = conf.get_as_int('verbose')
   ######################
   clf = svm.NuSVC(nu=0.005,cache_size=200, class_weight=None, coef0=coef,
         decision_function_shape='ovo', degree=deg, gamma=gamma_, kernel=kernel_,
         max_iter=-1, probability=False, random_state=None, shrinking=True, 
         tol=0.001, verbose=verb)
   clf.fit(X,Y)
   log.log_msg("svm nu param:", str(clf))
   scores = cross_val_score(clf,X,Y,cv=5)
   ##scores = clf.score(X,Y)
   print("NuSVC scores:", scores)
   log.log_msg('NuSVM scores accuray/fold', scores)
   log.log_msg('avg accuracy:',scores.mean(), 'std:', scores.std()*2)
   save_model(clf)



def get_clf():
   gamma_ = get_gamma()
   deg = conf.get_as_int('degree')
   kernel_ = conf.get_prop('kernel')
   max_iter_ = conf.get_as_int('max_iter')
   coef = conf.get_as_float('coef0')
   C_= conf.get_as_float('C')
   verb = conf.get_as_int('verbose')
   clf = svm.SVC(C=C_, cache_size=200, class_weight=None, coef0=coef,
        decision_function_shape='ovo', degree=deg, gamma=gamma_, kernel=kernel_,
        max_iter=max_iter_, probability=False, random_state=None, shrinking=True,
                 tol=0.001, verbose=verb)
   log.log_msg('model conf:', clf)
   return clf


##good ref: 
##https://medium.com/datadriveninvestor/k-fold-cross-validation-6b8518070833

def cv_conf_matrix(X,Y):
   print('size of dataset:',len(X))
   print('labels:',labels)
   #scaler = MinMaxScaler(feature_range=(0, 1))
   #X = scaler.fit_transform(X)
   epoc = conf.get_as_int('epoch_size')
   ##model = load_model()
   verb = conf.get_as_int('verbose')
   print('Y',Y)
   acc = 0
   splits = conf.get_as_int('cv_splits')
   kfold = KFold(n_splits=splits, shuffle=True, random_state=SEED)
   for train_index, test_index in kfold.split(X):
      X_tr, X_tes = X[train_index], X[test_index]
      y_tr, y_tes = Y[train_index],Y[test_index]
      clf = get_clf().fit(X_tr,y_tr)
      unique_label = np.unique(y_tr)
      y_pred=clf.predict(X_tes)
      cnf_matrix = confusion_matrix(y_tes, y_pred,labels=unique_label)
      log.log_msg('confusion matrix',cnf_matrix)
      print(cnf_matrix)
      #np.set_printoptions(precision=2)
      unique_label = np.unique(y_tr)
      cm = pandas.DataFrame(cnf_matrix,
            index=['true:{:}'.format(x) for x in unique_label],
            columns=['pred:{:}'.format(x) for x in unique_label])
      log.log_msg('confusion matrix:', cm)
      print(cm)
      facc = accuracy_score(y_tes, y_pred)
      log.log_msg("fold accuracy:", facc)
      print("fold accuracy:",facc)
      acc = acc + facc
      report = classification_report(y_tes, y_pred)
      print(report)
      log.log_msg("fold report:",report)
      log.log_msg("---------------------------")
   log.log_msg("overall accuracy:", acc /splits)
   print("overall accuracy:",acc/ splits)
 
######################################## Saving the model.. ##########################
def saved_model(model,fn):
    with tf.Session() as sess:
        sess.run(tf.global_variables_initializer())
        try:
            tf.keras.models.save_model(model, fn)
            print("saving is over....")
        except:
            print("error saving...")
            pass

def serving_input_receiver_fun():
    your_feature_spec = {
        "some_feature": tf.FixedLenFeature([], dtype=tf.string, default_value=""),
        "some_feature": tf.VarLenFeature(dtype=tf.string),
    }
    serialized_tf_example = tf.placeholder(dtype=tf.string, shape=None, 
                                           name='input_example_tensor')
    # key (e.g. 'examples') should be same with the inputKey when you 
    # buid the request for prediction
    receiver_tensors = {'examples': serialized_tf_example}
    features = tf.parse_example(serialized_tf_example, your_feature_spec)
    return tf.estimator.export.ServingInputReceiver(features, receiver_tensors)
##############################################################################
def save_model(model):
   model_fn = conf.get_prop("model")
   with open(model_fn,'wb') as f:
      pickle.dump(model,f)
    
def load_model():
   model_fn = conf.get_prop("model")
   with open(model_fn,'rb') as f:
      model = pickle.load(f)
   return model

def read_dataset():
    global labels
    filename = conf.get_prop('dataset_fn')
    print('file of dataset:', filename)
    # load pima indians dataset
    dataframe = pandas.read_csv(filename, header=None)
    print('data', dataframe.values)
    dataset = dataframe.values
    #######shuffle the data...
    for i in range(0,5):
       np.random.shuffle(dataset)
    # split into input (X) and output (Y) variables
    X = dataset[:,0:7]
    Y_Nom = dataset[:,7]
    ###########################################
    # convert the labels to numbers.
    ##dict = {}
    rdict = {}
    k = 1
    Y = []
    for v in Y_Nom:
        if v in labels.keys():Y.append( labels[v])
        else:
            Y.append(k)
            labels[v] = k
            rdict[k] = v
            k=k+1
    ########################################
    print('Y:',Y , 'size:', (Y))
    log.log_msg('labels:', labels, '-->', rdict)
    ##print('types:',type(X), type(Y))
    return X,np.array(Y)

def usage():
    print ('python train_svm2.py conf_file_path [-cm]')
    print ('cm: confusion matrix trainng')
    sys.exit(0)

if __name__ =='__main__':
    
    nu=0
    if len(sys.argv) < 2: usage()
    fn = sys.argv[1]  
    conf = Config(fn)
    log = Logger(conf.get_prop('output_fn'))
    log.log_msg('configuration:', conf)
    X,Y= read_dataset()
    log.log_msg("size of data:", len(X))
    if len(sys.argv) == 3: 
        cv_conf_matrix(X,Y) 
    elif len(sys.argv) == 2:
        train(X,Y)
    log.close()

