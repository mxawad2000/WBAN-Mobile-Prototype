import tensorflow as tf

# Add an op to initialize the variables.
def fun1():
    x = tf.Variable([3.3, 4.4]) 
    ##"vv",expected_shape=[3],initial_value=tf.zeros_initializer)
    init = tf.global_variables_initializer()
    with tf.Session() as sess:
        sess.run(init)
        v = sess.run(x)
        print(v)  # will show you your variable.

def print_tfvar(v):
    with tf.Session() as sess:
       sess.run(init_op)
       val = sess.run(v)
       print(val)  # will show you your variable.

fun1()
# Create some variables.
v1 = tf.get_variable("v1", shape=[3], initializer = tf.zeros_initializer)
v2 = tf.get_variable("v2", shape=[5], initializer = tf.zeros_initializer)
inc_v1 = v1.assign(v1+1)
dec_v2 = v2.assign(v2-1)
init_op = tf.global_variables_initializer()

with tf.Session() as abc:
    abc.run(init_op)
    xx = abc.run(v1)
    print(xx)

##print_tfvar(v1)
# Add ops to save and restore all the variables.
saver = tf.train.Saver()


# Later, launch the model, initialize the variables, do some work, and save the
# variables to disk.
with tf.Session() as sess:
  sess.run(init_op)
  # Do some work with the model.
  inc_v1.op.run()
  ##print('v1',v1.eval())
  dec_v2.op.run()
  # Save the variables to disk.
  save_path = saver.save(sess, "./models/model.ckpt")
  print("Model saved in path: %s" % save_path)
  
