import configparser as config

class Config:
    def __init__(self,fn):
        self.conf = config.RawConfigParser()
        self.conf.read(fn)

    def get_prop(self,p):
        if self.conf.has_option('CONF_SECTION',p):
            return self.conf.get('CONF_SECTION',p)
            return None

    def get_as_int(self,p,defV=-1):
        if self.conf.has_option('CONF_SECTION',p):
            return int(self.conf.get('CONF_SECTION',p))
        else: return defV

    def get_as_float(self,p,defV=-1):
        if self.conf.has_option('CONF_SECTION',p):
            return float(self.conf.get('CONF_SECTION',p))
        else: return defV

    def get_as_bool(self,p):
        if conf.has_option('CONF_SECTION',p):
            x = conf.get('CONF_SECTION',p)
            return x in ("True","T", "true","TRUE","1")
        else: return False

    def get_as_list(self,p):
        if self.conf.has_option('CONF_SECTION',p):
            return self.get_prop(p).split(' ')
        else:
            return []
    def __str__(self):
        d = self.conf['CONF_SECTION']
        s = ''
        for k in d.keys():
            s += k + '=' + d[k] + '\n'
        return s

