##http://ozgur.github.io/python-firebase/
from datetime import datetime
from firebase import firebase
import base64
import json
import tkinter
from tkinter import messagebox
from tkinter import *
from tkinter import filedialog

##tutorial about alignment: https://www.python-course.eu/tkinter_layout_management.php


##for the svm
##key: patient1/ft/svm/svm_model1
##file svm_models/svm_model_file1.model
##type: svm

##For ANN
##key: patient1/ft/ann/ann_model1
##file ann_models/ann_model_file1.tflite
##type: ann

##############################################################################
class GUI2:
    def __init__(self):
        self.top = tkinter.Tk()
        self.top.title("Get Model by Key")
        ##self.top.geometry("300x300")
        ##top.resizable(0, 0) #Don't allow resizing in the x or y direction
        labelx = Label(self.top, text="GET MODEL BY KEY" )
        labelx.pack( side = TOP)
        ##
        self.add_entry("KEY:")
        self.top.mainloop()

    def add_entry(self,msg):
        frame = Frame(self.top)
        L1 = Label(frame, text= msg )
        L1.pack( side = LEFT)
        self.E1 = Entry(frame, bd =5)
        self.E1.pack(side=LEFT)
        self.B = tkinter.Button(frame, text ="GET KEY", command = self.get_callBack) 
        self.B.pack(side=LEFT)
        frame.pack()
        
    def get_callBack(self):
        value = self.E1.get()
        print( get_value(value))

####################################################################################

####################################################################################


ENCODING = 'utf-8'
MODEL_NAME = "model_h5_233.tflite"
fb_keys = ['patient1/ft/svm/svm_model1','patient1/ft/ann/ann_model1','patient1/ft/dt/dt_model1']
labels = {'patient1/ft/svm/svm_model1':'1:Battery Alarm,2:Hardware Alarm,3:Normal',
          'patient1/ft/ann/ann_model1':'0:Battery Alarm,1:Hardware Alarm,2:Normal',
          'patient1/ft/dt/dt_model1':'1:Battery Alarm,2:Hardware Alarm,3:Normal'}

selected_file = ""
DB ='models/'
#read a file as bytes
def get_bytes_from_file(filename):  
    return open(filename, "rb").read()

##get a record from firebase given a key.
def get_value(k):
    fb = firebase.FirebaseApplication('https://medical-app-13bc9.firebaseio.com/', None)
    result = fb.get(DB + k, None)
    return result

#add/put/post a record to the firebase, given a key for the record.
def upload(k,fn,model_type='ann'):
    model_str = get_dump(fn)
    fb = firebase.FirebaseApplication('https://medical-app-13bc9.firebaseio.com/', None)
    fn = fn.replace('\\','/').split('/')
    fn = fn[len(fn)-1]
    print('file:',fn)
    ##posting..
    model = {'file_name':fn, 'model_type':model_type,'create_at': str(datetime.now()),'binary': model_str,'labels':labels[k]}
    result = fb.post(DB + k, model)
    print (result)

def upload_sensor_profile(id,dict):
    k = "sensor_profiles/"
    fb = firebase.FirebaseApplication('https://medical-app-13bc9.firebaseio.com/', None)
    print('deleting:', k+id)
    fb.delete(k, id)
    result = fb.post( k+id, dict)
    print (result)

def upload_svm():
    fn = 'svm_models/svm_model_file1.model'
    upload_svm(fn)

def upload_svm(fn):
    ##fn = 'svm_models/svm_model_file1.model'
    k = fb_keys[0] 
    model_type = "svm"
    model_str = get_dump(fn)
    fb = firebase.FirebaseApplication('https://medical-app-13bc9.firebaseio.com/', None)
    fn = fn.replace('\\','/').split('/')
    fn = fn[len(fn)-1]
    print('file:',fn)
    ##posting..
    model = {'file_name':fn, 'model_type':model_type,'create_at': str(datetime.now()),'binary': model_str,'labels':labels[k]}
    fb.delete(DB,k)
    result = fb.post(DB + k, model)
    print (result)

#################################################################################################
def upload_DT():
    fn = 'dt_models/dt_model.weka'
    upload_DT(fn)

def upload_DT(fn): ##upload decision tree model
    ##fn = 'dt_models/dt_model.weka'
    ##dt_labels = file2dict2(fn + ".labels")
    dt_labels = read_file(fn + ".labels")
    k = fb_keys[2] 
    model_type = "dt"
    model_str = get_dump(fn)
    fb = firebase.FirebaseApplication('https://medical-app-13bc9.firebaseio.com/', None)
    fn = fn.replace('\\','/').split('/')
    fn = fn[len(fn)-1]
    print('file:',fn)
    ##posting..
    model = {'file_name':fn, 'model_type':model_type,'create_at': str(datetime.now()),'binary': model_str,'labels':dt_labels}
    fb.delete(DB,k)
    result = fb.post(DB + k, model)
    print (result)

#################################################################################################
def upload_ann():
    fn = 'ann_models/ann_model_file1.tflite'
    upload_ann(fn)
def upload_ann(flite_name):
    fn = flite_name
    k = fb_keys[1] 
    model_type = "ann"
    model_str = get_dump(fn)
    fb = firebase.FirebaseApplication('https://medical-app-13bc9.firebaseio.com/', None)
    fn = fn.replace('\\','/').split('/')
    fn = fn[len(fn)-1]
    print('file:',fn)
    ##posting..
    model = {'file_name':fn, 'model_type':model_type,'create_at': str(datetime.now()),'binary': model_str,'labels':labels[k]}
    fb.delete(DB,k)
    result = fb.post(DB + k, model)
    print (result)

def browse_files(path):
    options = {}
    options['initialdir'] = path
    options['title'] = "Select Sensor Profile"
    ##options['mustexist'] = False
    fileName = filedialog.askopenfilename(**options)
    return fileName

def get_dump(fn):
    barr = get_bytes_from_file(fn)
    ##transform to base64 string
    msg = base64.b64encode(barr)
    b64_str = msg.decode(ENCODING)
    print('size of barr:', len(barr))
    print('size of msg:', len(msg))
    ##decoding..
    ##msg2 = json.dumps(b64_str);
    orig = base64.decodestring(msg)
    print('orig szie:', len(orig))
    #print('size of dump:', len(json.dumps(b64_str)))
    ###loading the json dumps..
    jdump = json.dumps(b64_str)
    orig2 = json.loads(jdump)
    return jdump

def menu():
    print('Usage:')
    print('1. get svm model')
    print('2. get ann model')
    print('3. post svm model ')
    print('4. post ann model')
    print('5. post Decision Tree Model')
    print('0. exit')
    print('-------------------')
    print('enter choice>>')
######################################################################
def file2dict(fileName):
    myprops = {}
    with open(fileName, 'r') as f:
        for line in f:
            line = line.rstrip() #removes trailing whitespace and '\n' chars
            if "=" not in line: continue #skips blanks and comments w/o =
            if line.startswith("#"): continue #skips comments which contain =
            k, v = line.split("=", 1)
            myprops[k] = v
    return myprops
########################################################################
def file2dict2(fileName):
    myprops = {}
    with open(fileName, 'r') as f:
        ind = 0
        for line in f:
            line = line.rstrip() #removes trailing whitespace and '\n' chars
            myprops[ind] = line
            ind=ind+1
    return myprops

def read_file(fileName):
    with open(fileName, 'r') as f:
        lines = ""
        for line in f:
            lines = lines + line.rstrip() + "\n" #removes trailing whitespace and '\n' chars
    return lines

#######################################################################
def print_model(model):
    for k in model:
        dd = model[k]
        for kk in dd:
            print('key:',kk , '-->' , dd[kk])
################### Handler##########################################
BUTTON_GET_SVM = 1
BUTTON_GET_ANN = 2
BUTTON_UPLOAD_SVM = 3
BUTTON_UPLOAD_ANN = 4
BUTTON_GET_MODEL_BY_KEY = 5
BUTTON_GET_MODEL_HANDLER = 6
BUTTON_UPLOAD_SENSOR_PROFILE = 7
BUTTON_UPLOAD_DT = 8
BUTTON_BROWSE_FILES=9


def get_callBack(bt_id):
    global selected_file
    if bt_id == BUTTON_GET_ANN:
        if messagebox.askokcancel("Getting ANN MODEL FROM FB","Are you Sure?"):
            print_model( get_value(fb_keys[1]))
    elif bt_id == BUTTON_GET_SVM:
        messagebox.showinfo("get_svm_model","Are you Sure")
        if messagebox.askokcancel("Getting SVM MODEL FROM FB","Are you Sure?"):
            print_model( get_value(fb_keys[0]))
    elif bt_id == BUTTON_UPLOAD_ANN:
        gui_ann_upload()
    elif bt_id == BUTTON_UPLOAD_SVM:
       gui_svm_upload()
    elif bt_id == BUTTON_GET_MODEL_BY_KEY:
        GUI2()
    elif bt_id == BUTTON_UPLOAD_SENSOR_PROFILE:
        fn = browse_files("./sensor_profiles")
        print('file:', fn)
        if not fn:
            print('profile upload was Cancelled...')
        else:
            dict = file2dict(fn)
            upload_sensor_profile(dict["id"],file2dict(fn))

    elif bt_id == BUTTON_UPLOAD_DT:
       gui_dtree_upload()
    elif bt_id == BUTTON_BROWSE_FILES:
        selected_file = browse_files("./")
        print('selected file:', selected_file)
########################################################################
def gui_ann_upload():
    fn = browse_files("./ann_models")
    if fn and fn.find('.tflite') !=-1:
        msg = "Are you Sure of uploading:" + fn + " file"
        if messagebox.askokcancel("Upload ANN Tree Model"  , msg):
            ##messagebox.showinfo( "upload_ann_model", "Are you sure you want to upload new ANN model?")
            upload_ann(fn)
            rec  =  get_value(fb_keys[1])
            print_model(rec)
        else:
            print("upload was cacelled")
    else:
        messagebox.askokcancel("Erro - file"  , "Invalid TFLite file")
##########################################################################
def gui_svm_upload():
    fn = browse_files("./svm_models")
    if fn and fn.find('.svm') !=-1:
        msg = "Are you Sure of uploading:" + fn + " file"
        if messagebox.askokcancel("Upload SVM Model"  , msg):
            upload_svm(fn)
            rec  =  get_value(fb_keys[1])
            print_model(rec)
        else:
            print("upload was cacelled")
    else:
        messagebox.askokcancel("Erro - file"  , "Invalid .SVM file")
#############################################################################
def gui_dtree_upload():
    fn = browse_files("./dt_models")
    if fn and fn.find('.weka') !=-1:
        msg = "Are you Sure of uploading:" + fn + " file"
        if messagebox.askokcancel("Upload DTree Model"  , msg):
            upload_DT(fn)
            rec  =  get_value(fb_keys[1])
            print_model(rec)
        else:
            print("upload was cacelled")
    else:
        messagebox.askokcancel("Erro - file"  , "Invalid .WEKA file")
########################################################################
def showGUI2():
    top = tkinter.Tk()
    top.title("Get Model by Key")
    top.geometry("300x300")
    ##top.resizable(0, 0) #Don't allow resizing in the x or y direction
    labelx = Label(top, text="GET MODEL BY KEY" )
    labelx.pack( side = TOP)
    ##
    add_entry(top,"KEY:")
    add_button(top,"Get Model",BUTTON_GET_MODEL_BY_KEY)
    top.mainloop()

def add_entry(top,msg):
    L1 = Label(top, text= msg )
    L1.pack( side = LEFT)
    E1 = Entry(top, bd =5)
    E1.pack(side = RIGHT)

def add_button(top,txt,id):
    B = tkinter.Button(top, text =txt, command = lambda: get_callBack(id), height=3, width=50,padx=2,pady=5) 
    B.pack()

def add_browse_frame(top,txt,id1,id2):
    f = Frame(top)
    B1 = Button(f, text= "Browse" ,command =lambda: get_callBack(id1),height=2,width=25,padx=2,pady=5)
    B1.pack( side=LEFT)
    B2 = Button(f, text=txt,command =lambda: get_callBack(id2), height=2,width=25,padx=2,pady=5)
    B2.pack(side = RIGHT)
    f.pack()
################################################################
def showGUI():
    top = tkinter.Tk()
    top.title("Uploader/Trainer")
    top.geometry("500x500")
    top.resizable(0, 0) #Don't allow resizing in the x or y direction
    var = StringVar()
    label = Label(top, textvariable=var, relief=RAISED )
    var.set("Cloud/AI Model Uploader")
    label.pack()
    add_button(top,"Get SVM Model",BUTTON_GET_SVM)
    add_button(top,"Get ANN Model",BUTTON_GET_ANN)
    add_button(top,"Get Model by Key",BUTTON_GET_MODEL_BY_KEY)
    add_button(top,"Upload SVM Model",BUTTON_UPLOAD_SVM)
    add_button(top,"Upload ANN Model",BUTTON_UPLOAD_ANN)
    add_button(top,"Upload Sensor Profile",BUTTON_UPLOAD_SENSOR_PROFILE)
    add_button(top,"Upload Decision Tree Model",BUTTON_UPLOAD_DT)
    ##add_button(top,"Browse Files",BUTTON_BROWSE_FILES)
    #add_browse_frame(top,"Upload ANN Model",BUTTON_BROWSE_FILES,BUTTON_UPLOAD_ANN)
    #add_browse_frame(top,"Upload SVM Model",BUTTON_BROWSE_FILES,BUTTON_UPLOAD_SVM)
    #add_browse_frame(top,"Upload DT Model",BUTTON_BROWSE_FILES,BUTTON_UPLOAD_DT)

    ##c.pack(in_=top, side=LEFT)
    top.mainloop()

def text_menu():
    while False:
        menu()
        c = input()
        if c[0] == '0': break
        elif c[0] == '1':
            ##print('enter key>>')
            ##k = input()
            print_model( get_value(fb_keys[0]))
        elif c[0] == '2': print_model(get_value(fb_keys[1]))
        elif c[0] == '3':
            upload_svm()
            rec  =  get_value(fb_keys[0])
            print_model(rec)
        elif c[0] == '4':
            upload_ann()
            rec  =  get_value(fb_keys[1])
            print_model(rec)

if __name__ == '__main__':
    showGUI()

    



