import configparser as config

class Logger:
    def __init__(self,fn):
        self.log_fn = open(fn, "w")

    def log_msg(self,*args):
        for arg in args:
            self.log_fn.write(str(arg))
            self.log_fn.write("\n")
        self.log_fn.flush()

    def close(self):
        self.log_fn.close()

