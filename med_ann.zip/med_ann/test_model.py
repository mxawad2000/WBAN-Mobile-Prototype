import keras
import numpy as np
import pandas
from keras.models import Sequential
from keras.layers import Dense
from keras.wrappers.scikit_learn import KerasClassifier
from keras.utils import np_utils
from keras.models import load_model
from keras.models import model_from_json
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import KFold
from sklearn.preprocessing import LabelEncoder
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
import sys
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.metrics import accuracy_score
from config import Config
from logger import Logger
import tensorflow as tf
import os
from datetime import datetime
from keras.utils import to_categorical


labels={}
ann_model=None

def read_dataset(fn):
   #fn = conf.get_prop('dataset_fn')
   print('file name:', fn)
   # fix random seed for reproducibility
   seed = 7
   np.random.seed(seed)
   # load dataset
   dataframe = pandas.read_csv(fn, header=None)
   ##print('data', dataframe.values)
   dataset = dataframe.values
   ###shuffle the dataset...
   for i in range(0,5):
      np.random.shuffle(dataset)
   X = dataset[:, 0:7]
   Y = dataset[:, 7]
   #encode class values as integers
   encoder = LabelEncoder()
   encoder.fit(Y)
   #encode labels to 0,1,2
   encoded_Y = encoder.transform(Y)
   ##print('encoded Y:', encoded_Y);
   ind = 0
   for label in Y:
      labels[label] = encoded_Y[ind]
      ind=ind+1
   # convert integers to dummy variables (i.e. one hot encoded)
   Y = np_utils.to_categorical(encoded_Y)
   print('Dummy y:',Y)
   return X, encoded_Y


def load_h5_model(fn):
    model =  tf.keras.models.load_model(fn)
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy']) 
    return model

def load_h5_modelx(fn_h5):
   fn_json = fn_h5.replace('.h5','.json')
   # load json and create model
   json_file = open(fn_json, 'r')
   loaded_model_json = json_file.read()
   json_file.close()
   loaded_model = model_from_json(loaded_model_json)
   # load weights into new model
   loaded_model.load_weights(fn_h5)
   print("Loaded model from disk")
   loaded_model.compile(loss='categorical_crossentropy', optimizer='adam', 
                        metrics=['accuracy'])   
   return loaded_model


def test_model_h5(X,Y,model_fn):
    model = load_h5_model(model_fn)
    acc = 0
    for x,y in zip(X,Y):
        y_pred = model.predict(np.array([x]))
        m = np.max(y_pred)
        pred = np.where(y_pred == m)[1][0]
        ###print( y_pred,  'index:', pred)
        if y == pred : acc= acc + 1
    print('accuracy:', acc / len(X))
    dx = np.array(X)
    dy = np.array(Y)
    train_labels = to_categorical(Y)
    ##print("sample:", train_labels[0])
    res = model.evaluate(X,train_labels)
    print('res:',res)
    res2 = model.predict(X)
    print('Accuracy Score:', accuracy_score(Y,res2.argmax(axis=1)))


def test_model_tflite(X,Y,model_fn):
    print('model:',model_fn)
    # Load TFLite model and allocate tensors.
    interpreter = tf.lite.Interpreter(model_path=model_fn)
    interpreter.allocate_tensors()

    # Get input and output tensors.
    input_details = interpreter.get_input_details()
    output_details = interpreter.get_output_details()
    # Test model on random input data.
    input_shape = input_details[0]['shape']
    print('input shape:',input_shape)
    acc = 0
    for x,y in zip(X,Y):
       ## print(x)
        #in_data = np.array(np.random.random_sample(input_shape), dtype=np.float32)
        #print('shape of rand:', in_data.shape)
        #print('rand:', in_data)
        input_data = np.array([x],dtype=np.float32)
        print('shape of x:',input_data.shape)
        #print('input  data:', input_data)
        interpreter.set_tensor(input_details[0]['index'], input_data)
        interpreter.invoke()
        # The function `get_tensor()` returns a copy of the tensor data.
        # Use `tensor()` in order to get a pointer to the tensor.
        output_data = interpreter.get_tensor(output_details[0]['index'])
        #print('output:',output_data)
        m = np.max(output_data)
        ind = 0
        i = 0
        max = output_data[0][0]
        for v in output_data[0]:
            if max < v:
                ind=i
                max = v
            i=i+1
        print('max:', max ,' at index:', ind, 'y:',y)
        print('y=',y,'-->',ind)
        if y == ind: acc=acc+1
    print('accuracy:', acc / len(X))


def usage():
    print('tes_model dataset_fn model_fn [h5|tflite]')
    sys.exit(0)

if __name__ == '__main__':
   print('hello')
   fn = ''
   opt = 'h5'
   if len(sys.argv) < 3: usage()
   fn = sys.argv[1]
   model_fn = sys.argv[2]
   if len(sys.argv) == 4:
       opt = sys.argv[3]
   X,Y= read_dataset(fn)
   ##log.log_msg("size of data:", len(X))
   print('model:', model_fn)
   if opt == 'h5':
       test_model_h5(X,Y,model_fn)
   else:
       test_model_tflite(X,Y,model_fn)

   ##test_model(X,Y,model_fn)
   #if len(sys.argv) == 3 and sys.argv[2] == '-cm':    cv_conf_matrix(X,Y)
   #elif len(sys.argv) == 2:
