import numpy as np
import pandas


LABELS = {'Hardware Alarm':0,'Battery Alarm':1,'Normal':2}

##partition the data set,
##dataset: file name, percentage is the percentage of training for each class.
def partition(dataset_fn, percent):
    data = read_dataset(dataset_fn)
    #print("data size:" , data.shape)
    #train_dict = {}
    #test_dict = {}
    train = []
    test = []
    for label in LABELS:
        data2 = [ x for x in data if x[7] == label ]
        N = len(data2)
        all_ind = range( N ) 
        P = int ( percent * N)
        train_ind = np.random.choice(N, P,replace=False)
        for item in [data2[x] for x in train_ind]:
            train.append(item)
        for item in [data2[x] for x in all_ind if x not in train_ind]:
            test.append(item)
    stats(train)
    stats(test)
    np.random.shuffle(train)
    np.random.shuffle(test)
    pre = dataset_fn[0:dataset_fn.rfind('.')]
    test_fn = pre +".test.csv"  ##"abc.tst1.csv";
    train_fn = pre + '.train.csv'
    save(train_fn,train)
    save(test_fn,test)
    return [train_fn,test_fn]


def partition3(dataset_fn, percent):
    data = read_dataset(dataset_fn)
    #print("data size:" , data.shape)
    train_dict = {}
    test_dict = {}
    for label in LABELS:
        data2 = [ x for x in data if x[7] == label ]
        N = len(data2)
        all_ind = range( N ) 
        P = int ( percent * N)
        train_ind = np.random.choice(N, P,replace=False)
        train_dict[label] = [data2[x] for x in train_ind]
        test_dict [label] = [data2[x] for x in all_ind if x not in train_ind]
    train = []
    test = []
    for k in train_dict:
        for item in train_dict[k]:
            train.append(item)
        #print('size of train:', len(train))
        for item in test_dict[k]:
            test.append(item)
        #print('size of test:', len(test))
    stats(train)
    stats(test)
    test_fn = "abc.tst.csv";
    train_fn = "abc.train.csv"
    save(train_fn,train)
    save(test_fn,test)
    return [train_fn,test_fn]

def save(fn,vecs):
    f = open(fn,'w')
    for v in vecs:
        f.write(list2str(v,','))
        f.write('\n')
    f.close()

def list2str(list, sep):
    return sep.join(map(str, list)) 
    
def stats(list):
    total = 0
    for l in LABELS:
        L = len( [x for x in list if x[7] ==l])
        total+=L
        print('label:%s --> %d --> %.2f%%' %(l, L, L/len(list)*100))
    print('total:', total)

def read_dataset(dataset_fn):
   dataset = pandas.read_csv(dataset_fn, header=None)
   ##print('data:',dataset.values[0])
   ##print('data', dataset.values[0][:-1])
   dataset = dataset.values
   return dataset

#ds = read_dataset('./data/med.csv')
#partition('./data/med.csv',0.9)
#partition3('./data/med.csv',0.7)
#print(ds.shape)