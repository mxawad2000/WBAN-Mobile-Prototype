import tensorflow as tf
import sklearn.datasets as datasets
import numpy as np

######################################################################################
##https://medium.com/cs-note/tensorflow-ch4-support-vector-machines-c9ad18878c76
##tutorial of using tensor flow for SVM regression and classification.
#######################################################################################

##Section: Working with a Linear SVM
sess = tf.Session()
iris = datasets.load_iris()
##to access the data use iris.data
##print(iris.target)
x_vals = np.array([[x[0], x[3]] for x in iris.data])
##set the targets to be either 1 or -1 (one vs rest).
y_vals = np.array([1 if y==0 else -1 for y in iris.target])

#####################################################
##for plotting.....
print('xvalue:', x_vals[0])
##sepearte setosa training examples
setosa_x = [d[1] for i,d in enumerate(x_vals) if y_vals[i]==1]
print('setosa at 0:', setosa_x[0])
##separte setosa target examples.
setosa_y = [d[0] for i,d in enumerate(x_vals) if y_vals[i]==1]
##separate non-setosa trainng..
not_setosa_x = [d[1] for i,d in enumerate(x_vals) if y_vals[i]==-1]
not_setosa_y = [d[0] for i,d in enumerate(x_vals) if y_vals[i]==-1]

###################################################
##split trainng and testing...
##take 80% of the trainning data
train_indices = np.random.choice(len(x_vals), round(len(x_vals)*0.8), replace=False)
## set substraction: all indexes - train_indices
test_indices = np.array(list( set(range(len(x_vals))) - set(train_indices)))
x_vals_train = x_vals[train_indices]
x_vals_test = x_vals[test_indices]
y_vals_train = y_vals[train_indices]
y_vals_test = y_vals[test_indices]
print('all data:', len(x_vals))
print('len of training:', len(x_vals_train))
##################################################
##Output the shape of data.
print( 'x_vals_train:',x_vals_train.shape , 'x_vals_test:',x_vals_test.shape, 'y_vals_train:',y_vals_train.shape, 'y_vals_test:',y_vals_test.shape)

###################################################
##Create the placeholder and Variable .
batch_size = 100
x_data = tf.placeholder(shape=[None, 2], dtype=tf.float32)
y_target = tf.placeholder(shape=[None, 1], dtype=tf.float32)
A = tf.Variable(tf.random_normal(shape=[2,1])) ##column vector
b = tf.Variable(tf.random_normal(shape=[1,1]))
print('A:',A)
print('b:',b)
######################################################
##Declare the model output.
##  model =  x_data * A - b
model_output = tf.subtract( tf.matmul(x_data, A), b)
########################################################
##Declare the necessary components for the maximum margin loss.
l2_norm = tf.reduce_sum(tf.square(A))
alpha = tf.constant([0.1])
classification_term = tf.reduce_mean(tf.maximum(0., tf.subtract(1.,tf.multiply(model_output, y_target))))
loss = tf.add(classification_term, tf.multiply(alpha, l2_norm))
########################################################
##Declare the prediction and accuracy functions.
prediction = tf.sign(model_output)
accuracy = tf.reduce_mean(tf.cast(tf.equal(prediction, y_target),tf.float32))
#########################################################
##Declare the optimizer.
my_opt = tf.train.GradientDescentOptimizer(0.01)
train_step = my_opt.minimize(loss)
##init = tf.initialize_all_variables()
init = tf.global_variables_initializer()
sess.run(init)
##########################################################
#training...
loss_vec = []
train_accuracy = []
test_accuracy = []
for i in range(500):
    rand_index = np.random.choice(len(x_vals_train), size=batch_size)
    X = x_vals_train[rand_index]
    Y = np.transpose([y_vals_train[rand_index]])
    sess.run(train_step, feed_dict={x_data: X, y_target: Y})
    temp_loss = sess.run(loss, feed_dict={x_data: X, y_target: Y})
    loss_vec.append(temp_loss)
    train_acc_temp = sess.run(accuracy, feed_dict={x_data: x_vals_train, y_target: np.transpose([y_vals_train])})
    train_accuracy.append(train_acc_temp)
    test_acc_temp = sess.run(accuracy, feed_dict={x_data: x_vals_test, y_target: np.transpose([y_vals_test])})
    test_accuracy.append(test_acc_temp)
print('test accuracyc:', test_accuracy)
