import keras
import numpy as np
import pandas
from keras.models import Sequential
from keras.layers import Dense
from keras.wrappers.scikit_learn import KerasClassifier
from keras.utils import np_utils
from keras.models import load_model
from keras.models import model_from_json
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import KFold
from sklearn.preprocessing import LabelEncoder
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
import sys
from keras.backend import manual_variable_initialization 
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.metrics import accuracy_score 
from config import Config
from logger import Logger
import pickle
##from export import export_pb
import tensorflow as tf
import os
##from tensorflow.python.saved_model.signature_def_utils_impl import predict_signature_def

###https://www.tensorflow.org/lite/convert/python_api#exporting_a_savedmodel_

##check point saving model: https://www.youtube.com/watch?v=HxtBIwfy0kM
##Loading model in Android:
##https://stackoverflow.com/questions/45874245/keras-deep-learning-model-to-android
##very important:
##http://bytedeco.org/javacpp-presets/tensorflow/apidocs/org/tensorflow/lite/Interpreter.html

log=None
labels = {}
conf=None
SEED=7

run_config = tf.estimator.RunConfig(save_checkpoints_steps=500)
def baseline_model():
   # create model
   model = Sequential()
   #input: 8, relu: rectified Linear Unit
   ##setting the input
   input = conf.get_as_list('in_layer')
   print('intput:', input[2])
   model.add(Dense(int(input[0]), input_dim=int(input[1]), 
                   activation=input[2]))
   hidden = conf.get_as_list('hid_layer')
   for v in range(0, int(hidden[0])):
      model.add(Dense(int(hidden[1]), kernel_initializer='normal', 
                      activation=hidden[2]))
   ##model.add(Dense(16, kernel_initializer='normal', activation='relu'))
   output = conf.get_as_list('out_layer')
   model.add(Dense(int(output[0]), activation=output[1]))
   # Compile model
   print('compiling the model')
   model.compile(loss='categorical_crossentropy', optimizer='adam', 
                 metrics=['accuracy'])
   return model

def get_estimator():
   # create model
   model = Sequential()
   #input: 8, relu: rectified Linear Unit
   ##setting the input
   input = conf.get_as_list('in_layer')
   print('intput:', input[2])
   model.add(Dense(int(input[0]), input_dim=int(input[1]), 
                   activation=input[2]))
   hidden = conf.get_as_list('hid_layer')
   for v in range(0, int(hidden[0])):
      model.add(Dense(int(hidden[1]), kernel_initializer='normal', 
                      activation=hidden[2]))
   ##model.add(Dense(16, kernel_initializer='normal', activation='relu'))
   output = conf.get_as_list('out_layer')
   model.add(Dense(int(output[0]), activation=output[1]))
   # Compile model
   print('compiling the model')
   model.compile(loss='categorical_crossentropy', optimizer='adam', 
                 metrics=['accuracy'])
   return model


def read_dataset():
   fn = conf.get_prop('dataset_fn')
   print('file name:', fn)
   # fix random seed for reproducibility
   seed = 7
   np.random.seed(seed)
   # load dataset
   dataframe = pandas.read_csv(fn, header=None)
   print('data', dataframe.values)
   dataset = dataframe.values
   ###shuffle the dataset...
   for i in range(0,5):
      np.random.shuffle(dataset)
   X = dataset[:, 0:7]
   Y = dataset[:, 7]
   #encode class values as integers
   encoder = LabelEncoder()
   encoder.fit(Y)
   #encode labels to 0,1,2
   encoded_Y = encoder.transform(Y)
   ##print('encoded Y:', encoded_Y);
   ind = 0
   for label in Y:
      labels[label] = encoded_Y[ind]
      ind=ind+1
   # convert integers to dummy variables (i.e. one hot encoded)
   Y = np_utils.to_categorical(encoded_Y)
   #print('Dummy y:',Y)
   return X, encoded_Y

   
#####################################################################
def sm(fn):
    print('export file:', fn)
    converter = tf.lite.TFLiteConverter.from_keras_model_file(fn)
    tflite_model = converter.convert()
    open(fn + ".tflite", "wb").write(tflite_model)

    

#####################################################################
##running the ANN and generate the confusion matrix
def cv_conf_matrix(X,Y):
   print('size of dataset:',len(X))
   print('labels:',labels)
   print('yvalues:', Y)
   epoc = conf.get_as_int('epoch_size')
   verb = conf.get_as_int('verbose')
   acc = 0
   splits = conf.get_as_int('splits',10)
   kfold = KFold(n_splits=splits, shuffle=True, random_state=SEED)
   print('splits:', splits)
   model_fn = conf.get_prop('model_fn')
   fold_ind = 1
   for train_index, test_index in kfold.split(X):
      X_tr, X_tes = X[train_index], X[test_index]
      y_tr, y_tes = Y[train_index],Y[test_index]
      estimator = KerasClassifier(build_fn=baseline_model, epochs=epoc, 
                                  batch_size=5, verbose=verb)
      print('ytest:',y_tes)
      unique_label = np.unique(y_tr)
      #############################################################################
      print("-------------- check point ---------------------------")
      chk_pnt_path = ( "ann_models\cp.ckpt_%d" %fold_ind)
      chk_dir = os.path.dirname(chk_pnt_path)
      chk_cb =tf.keras.callbacks.ModelCheckpoint(chk_pnt_path, save_weights_only=True,verbose=1) 
      estimator.fit(X_tr, y_tr,verbose=1,callbacks=[chk_cb])
      #################################################################################
      print("-----------------------Model summary ----------------------")
      estimator.model.summary()
      ##### Saving the model######################
      fn = model_fn + str(fold_ind) + '.json'
      ############################################
      y_pred = estimator.predict(X_tes)
      save_model(estimator.model,fn)
      #print('y_tes:',y_tes)
      cnf_matrix = confusion_matrix(y_tes, y_pred,labels=unique_label)
      log.log_msg('confusion matrix',cnf_matrix)
      print(cnf_matrix)
      cm = pandas.DataFrame(cnf_matrix,
            index=['true:{:}'.format(x) for x in unique_label],
            columns=['pred:{:}'.format(x) for x in unique_label])
      log.log_msg('confusion matrix:', cm)
      print(cm)
      facc = accuracy_score(y_tes, y_pred)
      log.log_msg("fold accuracy:", facc)
      print("fold accuracy:",facc)
      acc = acc + facc
      report = classification_report(y_tes, y_pred)
      print(report)
      log.log_msg("fold report:",report)
      log.log_msg("---------------------------")
      fold_ind = fold_ind + 1
      ####evaluate(X,Y,fn)
   log.log_msg("overall accuracy:", acc /splits)
   print("overall accuracy:",acc/ splits)
#########################################################################
def train_model(X,Y):
   print('size of dataset:',len(X))
   print('labels:',labels)
   print('yvalues:', Y)
   epoc = conf.get_as_int('epoch_size')
   verb = conf.get_as_int('verbose')
   model_fn = conf.get_prop('model_fn')
   
   estimator = get_estimator()
   unique_label = np.unique(Y)
   ############################################################################
   train_labels = np_utils.to_categorical(Y)
   estimator.fit(X,train_labels, epochs=epoc,batch_size=5,verbose=1)
   ##epochs=epoc, batch_size=5,verbose=1)##,callbacks=[chk_cb])
   print("-----------------------Model summary ----------------------")
   estimator.summary()
   ##### Saving the model######################
   fn = model_fn + '_final.h5'
   ############################################
   y_pred = estimator.predict(X)
   log.log_msg('Accuracy Score:', accuracy_score(Y,y_pred.argmax(axis=1)))
   print('Accuracy Score:', accuracy_score(Y,y_pred.argmax(axis=1)))
   print ('Report : ')
   log.log_msg('report:', classification_report(Y,y_pred.argmax(axis=1)))
   print ('report:', classification_report(Y, y_pred.argmax(axis=1) ))
   ##saved_model(estimator,fn)
   save_h5(estimator,fn)
   
#########################################################################
def save_h5(model,fn):
    model.save(fn)
    sm(fn)

def save_model(model,fn_h5):
    fn_json = fn_h5.replace('.h5','.json')
    print('h5-fn:',fn_h5,'json-fn2:',fn_json)
    # serialize model to JSON
    model_json = model.to_json()
    ##open file and clean after that.
    with open(fn_json, "w") as json_file:
      json_file.write(model_json)
      # serialize weights to HDF5
      model.save_weights(fn_h5)
      print("Saved model to disk")

def load_model(fn):
   fn2 = fn.replace('.json','.h5')
   # load json and create model
   json_file = open(fn, 'r')
   loaded_model_json = json_file.read()
   json_file.close()
   loaded_model = model_from_json(loaded_model_json)
   # load weights into new model
   loaded_model.load_weights(fn2)
   print("Loaded model from disk")
   loaded_model.compile(loss='categorical_crossentropy', optimizer='adam', 
                        metrics=['accuracy'])   
   return loaded_model
    
#########################################################################
def usage():
    print ('python train_ann4.py conf_file_path [-cm]')
    print ('cm: confusion matrix trainng')
    sys.exit(0)

if __name__ == '__main__':
   print('hello')
   fn = ''
   if len(sys.argv) < 2: usage()
   fn = sys.argv[1]  
   conf = Config(fn)
   log = Logger(conf.get_prop('output_fn'))
   log.log_msg('configuration:', conf)
   X,Y= read_dataset()
   log.log_msg("size of data:", len(X))
   if len(sys.argv) == 3 and sys.argv[2] == '-cm':    cv_conf_matrix(X,Y)
   elif len(sys.argv) == 2:
      train_model(X,Y)
   else: usage()
   log.close()
