/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medicalapp;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import weka.classifiers.Evaluation;
import weka.classifiers.meta.FilteredClassifier;
import weka.classifiers.trees.J48;
import weka.core.Attribute;
import weka.core.Debug;
import weka.core.DenseInstance;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Utils;
import weka.core.converters.CSVLoader;
import weka.filters.supervised.instance.Resample;
//import weka.filters.supervised.instance.SMOTE;
/*
http://weka.sourceforge.net/doc.dev/weka/classifiers/trees/J48.html
parmeter list from weka docs:
alid options are:
 -U
  Use unpruned tree.
 -O
  Do not collapse tree.
 -C <pruning confidence>
  Set confidence threshold for pruning.
  (default 0.25
 -M <minimum number of instances>
  Set minimum number of instances per leaf.
  (default 2)
 -R
  Use reduced error pruning.
 -N <number of folds>
  Set number of folds for reduced error
  pruning. One fold is used as pruning set.
  (default 3)
 -B
  Use binary splits only.
 -S
  Don't perform subtree raising.
 -L
  Do not clean up after the tree has been built.
 -A
  Laplace smoothing for predicted probabilities.
 -J
  Do not use MDL correction for info gain on numeric attributes.
 -Q <seed>
  Seed for random data shuffling (default 1).
 -doNotMakeSplitPointActualValue
  Do not make split point actual value.
*/
/**
 *
 * @author Mamoun.Awad
 */
public class DTreeTrainer {
    //private List<String> labels = new ArrayList();
    static final String[] j48_params = {"U", "O","C","M", "R", "N","B","S","L","A","J","Q","doNotMakeSplitPointActualValue"};
    private Config config;
    private String trainingResult;
    private J48 j48;
    private Instances dataset;
    Map<Integer,String> labels = new HashMap();
    
    public DTreeTrainer(String dataset_fn, String conf_fn){
        config = new Config(conf_fn);
        this.dataset = loadInstances(dataset_fn);
        for(int i=0;i<3;i++)
            labels.put(i,this.dataset.classAttribute().value(i));
        System.out.println("Labels:" + labels);
    }

    public String getTrainingResult() {
        return trainingResult;
    }
    
    
    public static Instances loadInstances(String CSVFilePath) {
        Instances data = null;
        try {
            CSVLoader loader = new CSVLoader();
            loader.setSource(new File(CSVFilePath));
            String[] options = new String[1];
            options[0] = "-H";
            loader.setOptions(options);
            data = loader.getDataSet();
            data.setClassIndex(data.numAttributes()-1);
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        //System.out.println("data:" + data.toString());
        return data;
    }
    
    private  void setJ48(J48 j48){
        if(config.getInt("U")==1) j48.setUnpruned(true);
        if(config.getInt("O")==1) j48.setCollapseTree(true);
        if(config.hasKey("C") ) j48.setConfidenceFactor(config.getFloat("C"));
        if(config.hasKey("M") ) j48.setMinNumObj(config.getInt("M"));
        if(config.getInt("R")==1 ) j48.setReducedErrorPruning(true);
        if(config.hasKey("N")) j48.setNumFolds(config.getInt("N"));
        if(config.getInt("B")==1 ) j48.setBinarySplits(true);
        if(config.getInt("S")==1 ) j48.setSubtreeRaising(true);
        System.out.println("unpruned:" + j48.getUnpruned());
        System.out.println("confidence:" + j48.getConfidenceFactor());
        System.out.println("Min Leaf:" + j48.getMinNumObj());
    }
    
    public String getCVResults(){
        try{
            J48 j48 = new J48();
            setJ48(j48);
            j48.buildClassifier(this.dataset);
            Resample resample = new Resample();
            resample.setInputFormat(this.dataset);
            //classifier filter
            FilteredClassifier fc = new FilteredClassifier();
            fc.setClassifier(j48);
            fc.setFilter(resample);
            
            Evaluation eval = new Evaluation(this.dataset);
            eval.crossValidateModel(fc, dataset, 10,new Random(1));
            String res1 = eval.toSummaryString();
            String res2 =eval.toClassDetailsString();
            String  res3 = eval.toMatrixString();
            return "CV:\n" + res1 + "\nClass Details:\n" + res2+"\nCM:\n" + res3;
        }catch(Exception ex){
            ex.printStackTrace();
            return "Erro in CV:" + ex.getMessage();
        }
    }
    public void train(){
        try{
            this.j48 = new J48();
            setJ48(this.j48);
            j48.buildClassifier(this.dataset);
            Evaluation eval = new Evaluation(dataset);	
            //System.out.println(eval.toSummaryString());
            eval.evaluateModel(this.j48, dataset);
            System.out.println("Training Summary:" + eval.toSummaryString());
            System.out.printf(" precision %4.3f recall %4.3f fMeasure:%4.3f\n", eval.precision(0), eval.recall(0), eval.fMeasure(0));
            System.out.printf(" precision %4.3f recall %4.3f fMeasure:%4.3f\n", eval.precision(1), eval.recall(1), eval.fMeasure(1));
            System.out.printf(" Accuracy rate %4.3f \n\n", (1-eval.errorRate()));
            System.out.println("Tree:" + j48.toString());
            this.trainingResult = 
                    String.format("Training Summary: %s\n", eval.toSummaryString())+
                    String.format(" precision %4.3f recall %4.3f fMeasure:%4.3f\n", eval.precision(0), eval.recall(0), eval.fMeasure(0))+
                    String.format(" precision %4.3f recall %4.3f fMeasure:%4.3f\n", eval.precision(1), eval.recall(1), eval.fMeasure(1))+
                    String.format(" Accuracy rate %4.3f \n\n", (1-eval.errorRate())) +
                    "Cross Validation Results:" + this.getCVResults() + "\n"  + 
                    String.format("Tree:" + j48.toString());
            ///////////////////////////////////////////////////////////////////////
            System.out.println("persisting the model...");
            String model = this.dataset.relationName()+"_dt.weka";
            this.saveJ48Model(model);
            ////DTModel.serializeModel(model, "some_fb_key", "some_date", j48);
            //predict..
            /*
            Instances tdata = loadInstances("./data/all_med_nominal.csv");
            System.out.println("retrieving the model and evaluation....");
            SerializedClassifier classifier = new SerializedClassifier();
            classifier.setModelFile(new File(model));
            eval = new Evaluation(tdata);	
            eval.evaluateModel(classifier, tdata); //.crossValidateModel(classifier, tdata, 10, new Random(1));
            System.out.println(eval.toSummaryString());
            */
            ///////////////////////////////////////////////////////////////////
            
            System.out.println("Labels:" + this.labels);
            System.out.println("Prediciton missing:" +  Utils.missingValue());
            double[][] arr ={ {0,290,773,2.5,15,14,-64},//battery
                              {0,108,2,3.1,15,15,-44},//noromal
                              {37,24,29,2.8,7,14,-72}};//hardware
            
            //double[] arr = {2057,306,69,2.7,15,15,-64};
            for(int i=0;i<arr.length;i++){
                Instance inst = getWekaInstance(arr[i]);
                System.out.println("weka ins:" + inst);
                double v = j48.classifyInstance(inst);
                System.out.println("predicted value:v="+v+ " label:" + labels.get((int)v) );
            }
            
            
            System.out.println("Normal:" + dataset.classAttribute().indexOfValue("Normal"));
            System.out.println("Hardware:" + dataset.classAttribute().indexOfValue("Hardware Alarm"));
            System.out.println("Battery:" + dataset.classAttribute().indexOfValue("Battery Alarm"));
            
        }catch(Exception ex){
            ex.printStackTrace();
            this.trainingResult = ex.getMessage();
        }
    }
    public String validate(String csv_testset){
        try{
        //////////////////////////////////////////
        Instances tdata = loadInstances(csv_testset);
        System.out.println("Testing meta data of class:" + tdata.classAttribute().getMetadata());
        System.out.println("retrieving the model and evaluation....");
        
        Evaluation eval = new Evaluation(tdata);	
	//eval.crossValidateModel(this.j48, tdata, 10, new Random(1));
        eval.evaluateModel(j48, tdata);
        double acc =0 ;
        for(Instance inst : tdata){
            double v = (int) j48.classifyInstance(inst);
            String label =  labels.get((int) v);
            String rLabel = inst.classAttribute().value((int)inst.value(tdata.classIndex()));
            if(label.equalsIgnoreCase(rLabel)){
                acc++;
            }else{
                System.out.println("Inst:" + inst);
                System.out.println("prediciton:" + v + "(" + label+")---> correct:" + 
                        inst.classValue() +"(" + rLabel + ")" );    
            }
            
        }
        
        System.out.println("My Accurcy:" + acc / tdata.size());
        System.out.println(eval.toSummaryString());
        System.out.println("Test Normal:" + tdata.classAttribute().indexOfValue("Normal"));
        System.out.println("Test Hardware:" + tdata.classAttribute().indexOfValue("Hardware Alarm"));
        System.out.println("Test Battery:" + tdata.classAttribute().indexOfValue("Battery Alarm"));
        return 
            String.format("%s\n", eval.toSummaryString())+
            String.format(" precision %4.3f recall %4.3f fMeasure:%4.3f\n", eval.precision(0), eval.recall(0), eval.fMeasure(0))+
            String.format(" precision %4.3f recall %4.3f fMeasure:%4.3f\n", eval.precision(1), eval.recall(1), eval.fMeasure(1))+
            String.format(" Accuracy rate %4.3f \n\n", (1-eval.errorRate())) +
            "MY Accuracy:" + acc/tdata.size();
            
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return "Error in validations";
    }
    
    public Instance getWekaInstance(double[] arr){
        ArrayList<Attribute> attributes = new ArrayList();
        for(int i=0;i<arr.length;i++){
            attributes.add(new Attribute("attx" + (i + 1)) );
        }
        ArrayList<String> lst = new ArrayList();
        lst.add("Normal");lst.add("Hardware Alarm"); lst.add("Battery Alarm");
        attributes.add(new Attribute("class",lst));
        Instances data  = new Instances("TestInstances", attributes, 0);
        data.setClassIndex(data.numAttributes() - 1);
        Instance inst = new DenseInstance(arr.length);
        for(int i=0;i<arr.length;i++){
            inst.setValue(i, arr[i]);
        }
        //data.add(inst);
        inst.setDataset(data);
        System.out.println("Inst Normal:" + data.classAttribute().indexOfValue("Normal"));
        System.out.println("Inst Hardware:" + data.classAttribute().indexOfValue("Hardware Alarm"));
        System.out.println("Inst Battery:" + data.classAttribute().indexOfValue("Battery Alarm"));
        return inst;
    }
    
    public void saveJ48Model(String path){
        File file = new File(path);
        Debug.saveToFile(path, j48);
        //save the labels..
        try{
            PrintWriter pw = new PrintWriter ( path + ".labels");
            Iterator<Integer> iter = labels.keySet().iterator();
            String s = "";
            for(;iter.hasNext();){
                int code = iter.next();
                String v = labels.get(code);
                if(iter.hasNext()) s += code + ":" + v +",";
                else s += code + ":" + v;
            }
            pw.print(s);
            pw.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
}
