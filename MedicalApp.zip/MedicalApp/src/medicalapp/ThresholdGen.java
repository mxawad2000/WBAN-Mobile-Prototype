/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medicalapp;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import weka.classifiers.Evaluation;
import weka.classifiers.functions.MultilayerPerceptron;
import weka.classifiers.meta.FilteredClassifier;
import weka.classifiers.trees.J48;
import weka.core.Instances;
import weka.core.converters.CSVLoader;
import weka.filters.supervised.instance.Resample;

/**
 *
 * @author Mamoun.Awad
 */
public class ThresholdGen {
    static String logger_fn = "./data/dt_thresholds.txt";
    static String dataset_fn = "faults.csv";
    static int N = 100000;
    static Logger logger;
    public static void main(String[] ar) {
       //DTMain();
       //SVMMain();
       ANNMain();
       
    }
    public static void DTMain() {
        for(int n=95;n>=5;n-=5){
            logger = new Logger("./data/","dt_thresholds-" + n + ".txt",false);
            for(int i=0;i<1;i++){
               execRound(500,n,DT);
            }
            logger.close();
        }
    }
    
    public static void SVMMain() {
        for(int n=100;n>1;n-=5){
            logger = new Logger("./data/","svm_thresholds-" + n + ".txt",false);
            for(int i=0;i<1;i++){
               execRound(500,n,SVM);
            }
            logger.close();
        }
    }
    public static void ANNMain() {
        for(int n=5;n<=100;n+=5){
            logger = new Logger("./data/","ann_thresholds-" + n + ".txt",false);
            for(int i=0;i<1;i++){
               execRound(500,n,ANN);
            }
            logger.close();
        }
    }
    static final int SVM = 1;
    static final int DT =2;
    static final int ANN = 3;
    public static void execRound(int Sensors,int Traffic, int trainerType){
        //generate readings with different thesholds and then try to identify the faults..
        ThresholdGen gen = new ThresholdGen();
        Threshold[] ths = getRandomSensors(Sensors);//gen.getThresholds();
        System.out.println("number of thresholds:" + ths.length);
        double normal = 0;
        double total = 0;
        gen.dataset = getDataset(ths, Traffic);
        //gen.testset = getDataset(ths);
        gen.dump(dataset_fn,trainerType);
        if(trainerType == SVM){
            gen.getCV4SVMResults();
            System.out.println("SVM threshold training is done...");
        }else if(trainerType == DT){
            //gen.trainDT();
            String res = gen.getDTCVResults();
            System.out.println("Cross Validation:" + res);
            logger.println("CV results:" + res);
        }else if(trainerType == ANN){
            String res = gen.getANNCVResults();
            System.out.println("Cross Validation:" + res);
            logger.println("CV results:" + res);
        }
    }
    
    static Threshold[] getRandomSensors(int N){
        Threshold[] arr = new Threshold[N];
        for(int i=0;i<N;i++){
            arr[i] = new Threshold();
            arr[i].attrib=1;
            arr[i].sensor_id = i+1;
            arr[i].from = r.nextInt(10);
            arr[i].to = arr[i].from + r.nextDouble() * 10 ;
        }
        /*
        for(Threshold t : arr){
            System.out.println("t:" + t);
        }
        */
        return arr;
    }
    static List<String> getDataset(Threshold[] ths, int M){
        ThresholdGen gen = new ThresholdGen();
        double normal = 0;
        double total = 0;
        List<String> lst = new ArrayList();
        for(Threshold t : ths){
            for(int i=0;i<M;i++){
                String data = gen.generate(t,5);
                //System.out.println("Data:" + data);
                lst.add(data);
                //System.out.println("============================");
                if(data.contains("Normal")) normal++;
                total++;
            }
        }
         System.out.println("Normal:" + normal / total + " out of " + total);
         return lst;
    }
    List<String> dataset = new ArrayList();
    List<String> testset = new ArrayList();
    Config config = new Config("./data/j48.conf");
    
    Threshold[] getThresholds(){
        List<Threshold> lst = new ArrayList();
        try{
            Scanner sc = new Scanner( new File("thresholds.txt"));
            while(sc.hasNext()){
                String line = sc.nextLine();
                if(line.startsWith("#")) continue;
                String[] fields = line.split(",");
                lst.add( 
                        new Threshold(Integer.parseInt(fields[0]),
                                Integer.parseInt(fields[1]),
                                Double.parseDouble(fields[2]),
                                Double.parseDouble(fields[3]))
                ); 
                
            }
            sc.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return lst.toArray(new Threshold[0]);
    }
    private void shuffle(){
        int N = dataset.size();
        for(int i=0;i<2*N;i++){
            int ind1 = r.nextInt(N);
            int ind2 = r.nextInt(N);
            String d1 = dataset.get(ind1);
            String d2 = dataset.set(ind2, d1);
            dataset.set(ind1, d2);
        }
    }
    private void dump(String fn,int type){
        shuffle();
        try{
            PrintWriter pw = new PrintWriter( fn );
            if(type==SVM){
                for(String s:dataset){
                    String ss = s;
                    if(s.contains("Fault"))ss= s.replace("Fault", "-1");
                    else if(s.contains("Normal")) ss = s.replace("Normal", "1");
                    pw.println(ss);
                }
            }else{
                for(String s: dataset){
                    pw.println(s);
                }
            }
            pw.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
    static Random r = new Random(System.currentTimeMillis());
    private String generate(Threshold t,double distance){
        String label = "Normal";
        double v = (t.from - distance) + (t.to - t.from + distance) * r.nextDouble();
        //System.out.println("threshodl:" + t);
        //System.out.println("value:" + v);
        if(inRange(v,t.from,t.to)); //System.out.println("label is normal");
        else {
            //System.out.println("Label is irregular");
            label = "Fault";
        }
        return t.sensor_id + "," + t.attrib + ","+v+","+label;   
    }
    static boolean inRange(double v, double start, double end){
        return v >=start && v<end;
    }
    ////////////////////////////////////////////////////////////////////////////
    
    public static Instances loadInstances(String CSVFilePath) {
        Instances data = null;
        try {
            CSVLoader loader = new CSVLoader();
            loader.setSource(new File(CSVFilePath));
            String[] options = new String[1];
            options[0] = "-H";
            loader.setOptions(options);
            data = loader.getDataSet();
            data.setClassIndex(data.numAttributes()-1);
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        //System.out.println("data:" + data.toString());
        return data;
    }
    
    public void trainDT(){
        try{
            J48 j48 = new J48();
            setJ48(j48);
            Instances dataset = loadInstances(dataset_fn);
            j48.buildClassifier(dataset);
            Evaluation eval = new Evaluation(dataset);	
            //System.out.println(eval.toSummaryString());
            eval.evaluateModel(j48, dataset);
            System.out.println("Training Summary:" + eval.toSummaryString());
            System.out.printf(" precision %4.3f recall %4.3f fMeasure:%4.3f\n", eval.precision(0), eval.recall(0), eval.fMeasure(0));
            System.out.printf(" precision %4.3f recall %4.3f fMeasure:%4.3f\n", eval.precision(1), eval.recall(1), eval.fMeasure(1));
            System.out.printf(" Accuracy rate %4.3f \n\n", (1-eval.errorRate()));
            System.out.println("Tree:" + j48.toString());
            
            ///////////////////////////////////////////////////////////////////////
            //System.out.println("persisting the model...");
            //String model = this.dataset.relationName()+"_dt.weka";
            //this.saveJ48Model(model);
            
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
    
    public void trainANN(){
        try{
            Instances dataset = loadInstances(dataset_fn);
            //Instance of NN
            MultilayerPerceptron mlp = new MultilayerPerceptron();
            //Setting Parameters
            mlp.setLearningRate(0.1);
            mlp.setMomentum(0.2);
            mlp.setTrainingTime(2000);
            mlp.setHiddenLayers("3");
            mlp.buildClassifier(dataset);
            Evaluation eval = new Evaluation(dataset);	
            //System.out.println(eval.toSummaryString());
            eval.evaluateModel(mlp, dataset);
            System.out.println("Training Summary:" + eval.toSummaryString());
            System.out.printf(" precision %4.3f recall %4.3f fMeasure:%4.3f\n", eval.precision(0), eval.recall(0), eval.fMeasure(0));
            System.out.printf(" precision %4.3f recall %4.3f fMeasure:%4.3f\n", eval.precision(1), eval.recall(1), eval.fMeasure(1));
            System.out.printf(" Accuracy rate %4.3f \n\n", (1-eval.errorRate()));
            System.out.println("Tree:" + mlp.toString());
        }catch(Exception ex){
        ex.printStackTrace();
        }
    }
    private String getDTCVResults(){
         BenchMark bm = new BenchMark();
        try{
            bm.start("dt_train");
            J48 j48 = new J48();
            Instances dataset = loadInstances(dataset_fn);
            j48.buildClassifier(dataset);
            Resample resample = new Resample();
            resample.setInputFormat(dataset);
            //classifier filter
            FilteredClassifier fc = new FilteredClassifier();
            fc.setClassifier(j48);
            fc.setFilter(resample);
            Evaluation eval = new Evaluation(dataset);	
            eval.crossValidateModel(fc, dataset, 10,new Random(1));
            long t = bm.end("dt_train");
            logger.println("training & prediction 10 folds:" + t + " ms");
            return eval.toSummaryString();
        }catch(Exception ex){
            ex.printStackTrace();
            return "Erro in CV:" + ex.getMessage();
        }
    }
    private String getANNCVResults(){
         BenchMark bm = new BenchMark();
        try{
            bm.start("ann_train");
            Instances dataset = loadInstances(dataset_fn);
            MultilayerPerceptron mlp = new MultilayerPerceptron();
            //Setting Parameters
            mlp.setLearningRate(0.1);
            mlp.setMomentum(0.1);
            //set epoch
            mlp.setTrainingTime(10000);
            mlp.setHiddenLayers("10,5,2");
            mlp.buildClassifier(dataset);
            Resample resample = new Resample();
            resample.setInputFormat(dataset);
            //classifier filter
            FilteredClassifier fc = new FilteredClassifier();
            fc.setClassifier(mlp);
            fc.setFilter(resample);
            Evaluation eval = new Evaluation(dataset);	
            eval.crossValidateModel(fc, dataset, 10,new Random(1));
            long t = bm.end("ann_train");
            logger.println("training & prediction 10 folds:" + t + " ms");
            return eval.toSummaryString();
        }catch(Exception ex){
            ex.printStackTrace();
            return "Erro in CV:" + ex.getMessage();
        }
    }
     private void getCV4SVMResults(){
        try{
            List<float[]> data_targets = CommonUtil.file2floatList(dataset_fn, ",");
            List<float[]> data =new ArrayList();
            List<Integer> targets = new ArrayList();
            
            int i =0;
            for(float[] dt : data_targets){
                //System.out.println("data/target:" + Arrays.toString(dt));
                data.add(CommonUtil.subarray(dt,0, dt.length-1));
                targets.add((int)dt[dt.length-1]);
                //System.out.println("data:" + Arrays.toString(data.get(i)));
                //System.out.println("target:" + targets.get(i));
                i++;
            }
            Config config = new Config("./data/svm_threshold.prop");
            //config.addProperty("kernel", "1");
            //config.addProperty("degee", "3");
            SVMUtil.train_svm(data,targets, "th_svm.model", config, logger);
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
     
    ////////////////////////////////////////////////////////////////////////////
    private  void setJ48(J48 j48){
        if(config.getInt("U")==1) j48.setUnpruned(true);
        if(config.getInt("O")==1) j48.setCollapseTree(true);
        if(config.hasKey("C") ) j48.setConfidenceFactor(config.getFloat("C"));
        if(config.hasKey("M") ) j48.setMinNumObj(config.getInt("M"));
        if(config.getInt("R")==1 ) j48.setReducedErrorPruning(true);
        if(config.hasKey("N")) j48.setNumFolds(config.getInt("N"));
        if(config.getInt("B")==1 ) j48.setBinarySplits(true);
        if(config.getInt("S")==1 ) j48.setSubtreeRaising(true);
        System.out.println("unpruned:" + j48.getUnpruned());
        System.out.println("confidence:" + j48.getConfidenceFactor());
        System.out.println("Min Leaf:" + j48.getMinNumObj());
    }
}

class Threshold{
        int sensor_id;
    int attrib;
    double from;
    double to;

    public Threshold() {
    }

    public Threshold(int sensor_id, int attrib, double from, double to) {
        this.sensor_id = sensor_id;
        this.from = from;
        this.to = to;
        this.attrib = attrib;
    }
    

    @Override
    public String toString() {
        return "Threshold{" + "sensor_id=" + sensor_id + ", attrib=" + attrib + ", from=" + from + ", to=" + to + '}';
    }
    
    
}
