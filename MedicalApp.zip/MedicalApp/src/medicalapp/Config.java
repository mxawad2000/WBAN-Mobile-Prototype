/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medicalapp;

import java.io.*;
import java.util.*;

public class Config{

   private static Logger logger = new Logger(); 
   static{
     logger.setClassName(new Config());
   }
   
   private Properties prop = new Properties();
   /**
    * default constructor
    */
   public Config(){}
   
   /**
    * construct a configuration object that reads all properties from a file
    * @param prop_file
    */
   public Config(String prop_file){
	   init(prop_file,false);
   }
   /**
    * construct a value-key Config object. In case values repeats the latest will be used
    * @param prop_file string that represent the file name that holds properties
    * @param isReverse boolean in case true, then construct value-key config object, 
    * in case false construct key-value config object
    */
   public Config(String prop_file,boolean isReverse){
	   init(prop_file,isReverse);
   }
   private void init(String fileName, boolean isReverse){
	     try{
		       Properties prop2 = new Properties();
		       FileInputStream fis = new FileInputStream(fileName);
		       prop2.load(fis);
		       fis.close();
		       if(!isReverse){
		    	   this.prop = prop2;
		       }else{		    	   
			       Iterator<Object> iter = prop2.keySet().iterator();
			       while( iter.hasNext()){
			    	   String key = (String)iter.next();
			    	   String value = prop2.getProperty(key);
			    	   prop.put(value,key);
			       }
		       }
		     }catch(Exception ex){
		       logger.println(ex);  
		     }

   }
   public void addProperty(Object key, Object value){
     this.prop.put(key,value);
   }
   /**
    * retrieve the value of a given property
    * @param property string property name
    * @return an object value associated with that property
    */
   public Object getProperty(String property){
     return this.prop.get(property);
   }

   /**
    * retrieve the value of a given property object
    * @param property object property
    * @return value associated with that property
    */

   public Object getProperty(Object property){
     return this.prop.get(property);
   }

   /**
    * retrieve the value of a given property
    * @param property string property name
    * @return String value associated with that property
    */

   public String getString(String property){
     return prop.getProperty(property);
   }  
   
   /**
    * check if a property exists as a key. 
    * @param key string name of the property
    * @return boolean true if key exists, false otherwise
    */
   public boolean hasKey(String key){
       if(prop.getProperty(key) != null) return true;
       return false;
   }   

   /**
    * retrieve an array value of a given property
    * @param property string property name
    * @param separator string the separator between values
    * @return an array value associated with that property
    */

   public String[] getStringArray(String property,String separator){
     String value = prop.getProperty(property);
     StringTokenizer  st = new StringTokenizer(value,separator);
    try{
      String[] vec = new String[st.countTokens()];
      for(int i=0;i<vec.length;i++){
        vec[i] = st.nextToken();
      }
      return vec;  
    }catch(Exception ex){
      logger.println("invalid format during parsing line:" + value);
      return null;     
    }   
   }

   public int[] getIntArray(String property){return getIntArray(property,",");}
   public int[] getIntArray(String property,String separator){
     String value = prop.getProperty(property);
     StringTokenizer  st = new StringTokenizer(value,separator);
    try{
      int[] vec = new int[st.countTokens()];
      for(int i=0;i<vec.length;i++){
        vec[i] = Integer.parseInt(st.nextToken());
      }
      return vec;  
    }catch(Exception ex){
      logger.println("invalid format during parsing line:" + value);
      return null;     
    }   
   }
        
   public double getDouble(String property){     
     String v = prop.getProperty(property);
     try{
       return Double.parseDouble(v);     
     }catch(Exception ex){
       return Double.NaN;
     }
   }
   public float getFloat(String property){     
     String v = prop.getProperty(property);
     try{
       return Float.parseFloat(v);     
     }catch(Exception ex){
       return Float.NaN;
     }

   }
   
   public int getInt(String property){     
     String v = prop.getProperty(property);
     try{
       return Integer.parseInt(v);     
     }catch(Exception ex){
       return Integer.MAX_VALUE;
     }
   }
   
   public Map<String,String> getMap(String property){
     Map<String,String> map = new HashMap<String,String>();
     String map_str = prop.getProperty(property);
     String[] items = CommonUtil.line2StringArray(map_str,",");
     for(int i=0;i<items.length;i++){
       int index = items[i].indexOf(":");
       if(index == -1) continue;
       map.put(items[i].substring(0,index).trim() , items[i].substring(index + 1).trim());
     }
     return map;
   }
      
   public String toString(){
       return this.prop.toString();
   }
   public Properties getPropObj(){ return this.prop;}

    // clone the a Config object...
   public static Config copy(Config config_obj){
     Config _config = new Config();
     Properties _prop = _config.getPropObj();
     Properties prop = config_obj.getPropObj();
     Enumeration enum1 = prop.propertyNames();
     while(enum1.hasMoreElements()){
	 String element = (String)enum1.nextElement();
	 _prop.put(element,prop.get(element));
     }
     return _config;
   }      

   public static void main(String[] args){
     Config conf = new Config(args[0]);
     Date x = new Date();
     conf.addProperty("date",new Date());
     conf.addProperty(x,"mamoun");
     
     Date d = (Date)conf.getProperty("date");
     String ret = (String) conf.getProperty(x);
     System.out.println("ret:" + ret);
     System.out.println(d);
   }
}
