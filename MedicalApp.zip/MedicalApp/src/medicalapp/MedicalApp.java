/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medicalapp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import libsvm.svm;
import libsvm.svm_model;
import static medicalapp.SVMUtil.test_svm1;
/*
Usage: svm-train [options] training_set_file [model_file]
options:
-s svm_type : set type of SVM (default 0)
	0 -- C-SVC		(multi-class classification)
	1 -- nu-SVC		(multi-class classification)
	2 -- one-class SVM
	3 -- epsilon-SVR	(regression)
	4 -- nu-SVR		(regression)
-t kernel_type : set type of kernel function (default 2)
	0 -- linear: u'*v
	1 -- polynomial: (gamma*u'*v + coef0)^degree
	2 -- radial basis function: exp(-gamma*|u-v|^2)
	3 -- sigmoid: tanh(gamma*u'*v + coef0)
	4 -- precomputed kernel (kernel values in training_set_file)
-d degree : set degree in kernel function (default 3)
-g gamma : set gamma in kernel function (default 1/num_features)
-r coef0 : set coef0 in kernel function (default 0)
-c cost : set the parameter C of C-SVC, epsilon-SVR, and nu-SVR (default 1)
-n nu : set the parameter nu of nu-SVC, one-class SVM, and nu-SVR (default 0.5)
-p epsilon : set the epsilon in loss function of epsilon-SVR (default 0.1)
-m cachesize : set cache memory size in MB (default 100)
-e epsilon : set tolerance of termination criterion (default 0.001)
-h shrinking : whether to use the shrinking heuristics, 0 or 1 (default 1)
-b probability_estimates : whether to train a SVC or SVR model for probability estimates, 0 or 1 (default 0)
-wi weight : set the parameter C of class i to weight*C, for C-SVC (default 1)
-v n: n-fold cross validation mode
-q : quiet mode (no outputs)

*/
/**
 * Battery Alarm -- > 1
 * Hardware Alarm --> 2
 * Normal --> 3
 *
 * @author Mamoun.Awad
 */
public class MedicalApp {

    /**
     * @param args the command line arguments
     */
    static Config config = new Config("./data/svm_conf.prop");
    public static void main(String[] args){
        //trainModel("data/med.csv");
        testModel("data/med.csv");
    }
    
    public static List[] readData(String dataset_fn,boolean isNormalized){
        List<float[]> vecs =CommonUtil.file2floatList(dataset_fn,",");
        CommonUtil.shuffle(vecs);
        List<float[]> data = new ArrayList();
        List<Integer> targets = new ArrayList();
        float[] max_values = new float[ vecs.get(0).length-1];
        for(float[] v : vecs){
            float[] v2 = CommonUtil.subarray(v, 0, v.length-1);
            
            int ind = 0;
            for(float f : v2){
                max_values[ind] = Math.max(max_values[ind], Math.abs(f));
                ind++;
            }
            data.add(v2);
            int t = (int) v[v.length-1]; 
            targets.add(t);
        }
        if(isNormalized){
            int ind = 0;
            for(float[] v : data){
                v = CommonUtil.normalize(v, max_values);
                //System.out.println(Arrays.toString(v) + "-->" + targets.get(ind++));
            }
        }
        return new List[]{data,targets};
    }
    
    public static void trainModel(String dataset_fn) {
        // TODO code application logic here
        //String dataset_fn = "data/fdata.csv"; //"data/med.csv"
        String model_fn = dataset_fn + ".model"; // "med_svm_mode.model"
        List[] lists = readData(dataset_fn,false);
        List<float[]> data = (List<float[]>)lists[0];
        List<Integer> targets = (List<Integer>)lists[1];
        Logger logger = new Logger();
        SVMUtil.train_svm(data, targets, model_fn, config, logger);
    }
    public static void trainModel(String dataset_fn, String conf_fn){
        Config config = new Config(conf_fn);
        String model_fn = dataset_fn + ".model"; // "med_svm_mode.model"
        List[] lists = readData(dataset_fn,false);
        List<float[]> data = (List<float[]>)lists[0];
        List<Integer> targets = (List<Integer>)lists[1];
        Logger logger = new Logger();
        SVMUtil.train_svm(data, targets, model_fn, config, logger);
    }
    
    public static void testModel(String dataset_fn){
        try{
            List[] lists = readData(dataset_fn,false);
            List<float[]> data = (List<float[]>)lists[0];
            List<Integer> targets = (List<Integer>)lists[1];
            svm_model model = svm.svm_load_model(dataset_fn + ".model");
            Logger logger = new Logger();
            Stats stat = new Stats();
            test_svm1(model, data, targets, logger, stat);
            System.out.println(stat);
            logger.println(stat);
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
}
/*

    public static void train_bk() {
        // TODO code application logic here
        String dataset_fn = "data/fdata.csv"; //"data/med.csv"
        String model_fn = "fdata_svm_model.model"; // "med_svm_mode.model"
        List<float[]> vecs =CommonUtil.file2floatList(dataset_fn,",");
        CommonUtil.shuffle(vecs);
        List<float[]> data = new ArrayList();
        List<Integer> targets = new ArrayList();
        float[] max_values = new float[ vecs.get(0).length-1];
        for(float[] v : vecs){
            float[] v2 = CommonUtil.subarray(v, 0, v.length-1);
            int ind = 0;
            for(float f : v2){
                max_values[ind] = Math.max(max_values[ind], Math.abs(f));
                ind++;
            }
            data.add(v2);
            int t = (int) v[v.length-1]; 
            targets.add(t);
            
        }
        System.out.println("Max values:" + Arrays.toString(max_values));
        //int ind = 0;
        //for(float[] v : data){
            //v = CommonUtil.normalize(v, max_values);
            //System.out.println(Arrays.toString(v) + "-->" + targets.get(ind++));
        //}
        Config config = new Config("./data/svm_conf.prop");
        Logger logger = new Logger();
        SVMUtil.train_svm(data, targets, model_fn, config, logger);
    }
*/