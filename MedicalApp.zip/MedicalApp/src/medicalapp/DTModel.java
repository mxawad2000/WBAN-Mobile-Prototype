/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medicalapp;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import med_core.IPredModel;
import weka.classifiers.trees.J48;
import weka.core.Attribute;
import weka.core.DenseInstance;
import weka.core.Instance;
import weka.core.Instances;
/**
 *
 * @author Mamoun.Awad
 */
public class DTModel implements IPredModel {
    J48 smodel;
    String modelId;
    String fbKey;
    String date;
    Map<String,String> labels = new HashMap<>();
    public DTModel() { }
    public DTModel(String modelId, String fbKey, String date, J48 j48) {
        this.modelId = modelId;
        this.fbKey = fbKey;
        this.date = date;
        this.smodel = j48;
    }
    public String getDate(){ return this.date;}
    public String getModelID(){
        return this.modelId;
    }
    public String getModelType(){
        return "dt";
    }
    public String getFBKey(){
        return this.fbKey;
    }
    public void setLabels(Map map){
        this.labels.putAll(map);
    }
    double[] tmpArr;
    public int predict(float[] data){
        try {
            if(tmpArr == null) tmpArr = new double[data.length];
            for(int i=0;i<data.length;i++) tmpArr[i] = data[i];
            Instance instance = getWekaInstance(tmpArr);
            //Log.i(MyApp.TAG,"weka instance:" + instance.toString());
            return (int) smodel.classifyInstance(instance);
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return -1;
    }

    public String getPredLabel(int ind){
        return this.labels.get((ind+""));
    }
    private Instances dataset;
    private ArrayList<String> labelList = new ArrayList<>();
    private Instance getWekaInstance(double[] arr){
        if(dataset == null){
            ArrayList<Attribute> attributes = new ArrayList();
            for(int i=0;i<arr.length;i++){
                attributes.add(new Attribute("att" + (i + 1)) );
            }
            if(labelList.isEmpty()) labelList.addAll(this.labels.values());
            Attribute ca = new Attribute("class", labelList);
            attributes.add(ca);
            dataset  = new Instances("TestInstances", attributes, 0);
            dataset.setClassIndex(dataset.numAttributes() - 1);
        }
        Instance inst = new DenseInstance(arr.length);
        for(int i=0;i<arr.length;i++)inst.setValue(i, arr[i]);
        inst.setDataset(dataset);
        return inst;
    }
     public static void serializeModel(String modelId, String fbKey, String date, J48 j48){
        try{
            DTModel model = new DTModel(modelId,fbKey,date,j48);
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("abc"));
            oos.writeObject(model);
            oos.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
}


   
