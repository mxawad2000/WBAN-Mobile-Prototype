/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medicalapp;


import java.util.*;

public class BenchMark{

  private Map<String,Long> map = new HashMap<String,Long>();
  /**
   * start the clock for this tag
   * @param tag
   */
  public void start(String tag){
    map.put(tag,new Long(System.currentTimeMillis()));
  }  
  /**
   * end the clock for this tag
   * @param tag
   * @return milliseconds this task took
   */
  public long end(String tag){
    Long d =  map.get(tag);
    if( d != null){
       //map.remove(tag);
       return System.currentTimeMillis() - d.longValue();
    }
    return 0;
  }
  /**
   * get task time in seconds.
   * @param tag
   * @return
   */
  public float getSeconds(String tag){
    Long d =  map.get(tag);
    if( d != null){
       return (System.currentTimeMillis() - d.longValue())/1000f;
    }
    return 0;
  }

  public float getMinutes(String tag){
    Long d = map.get(tag);
    if( d != null){
       return (System.currentTimeMillis() - d.longValue())/60000f;
    }
    return 0;
  }

  public float getHours(String tag){
    Long d = map.get(tag);
    float h = 60 * 60 * 1000;
    if( d != null){
       return (System.currentTimeMillis() - d.longValue())/h;
    }
    return 0;
  }
  /**
   * remove a tag from the benchmark.
   * @param tag
   */
  public void reset(String tag){
	  if(map.containsKey(tag))
		  map.remove(tag);
  }
}

