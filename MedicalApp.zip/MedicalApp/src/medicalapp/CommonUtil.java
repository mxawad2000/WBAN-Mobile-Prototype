/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medicalapp;

import java.util.*;
import java.io.*;

/**
 * Title: General Common Utility Functions
 * Description: General Purpose methods
 * Copyright:    Copyright (c) 2004
 * Company: DB-Lab@UTD
 * @author: Mamoun Awad
 * @version 1.0
 * @last date modified: 7/21/04
 */

public class CommonUtil{

  public static Random random = new Random(System.currentTimeMillis());
  private static Logger cout = new Logger();
  static{
    cout.setClassName(new CommonUtil());
  }
  
  /**
   * create a new subarray of a given array starting at index fromIndex (inclusively) up to
   * the end of the array
   * @param ref
   * @param fromIndex
   * @return
   */
  public static String[] subArray(String[] ref,int fromIndex){	  
	  return subArray(ref,fromIndex,ref.length);
  }
  /**
   * create a new subarray of a given array starting at index fromIndex (inclusively) up to
   * index toIndex (exclusively)
   * @param ref
   * @param fromIndex
   * @param toIndex
   * @return
   */
  public static String[] subArray(String[] ref,int fromIndex, int toIndex){	  	
	      String[] ret = new String[toIndex - fromIndex];
	      for(int i=fromIndex,index = 0 ; i<toIndex ;i++,index++){
	        ret[index] = ref[i];
	      }
	      return ret;	  
  }
  /**
   * create a new subarray of a given array starting at index from
   * @param ref
   * @param from
   * @return
   */
  public static float[] subarray(float[] ref,int from){
    return subarray(ref,from,ref.length);
  }
  /**
   * replicate a string n times.
   * @param str string to be replicated
   * @param n int number of times.
   * @return
   */
  public static String replicate(String str, int n){
	  StringBuffer sb = new StringBuffer( ( n + 1 ) * str.length());
	  for(int i=0;i<n;i++)
		  sb.append(str);
	  return sb.toString();
  }
  
  public static float[] subarray(float[] ref, int from, int to){
    if(to > ref.length){
      to = ref.length;
    }
    if(to < 0){
      to = 0;
    }
    if(from > ref.length){
      from = ref.length;
    }
    if(from < 0){
      from = 0;
    }
    if(from > to) return new float[0];
    float[] ret = new float[to - from];
    for(int i=from,index = 0 ; i< to ;i++,index++){
      ret[index] = ref[i];
    }
    return ret;
  }
 
  public static int[] string2intArray(String line, String sep){
    StringTokenizer  st = new StringTokenizer(line,sep);
    try{
      int[] vec = new int[st.countTokens()];
      for(int i=0;i<vec.length;i++){
        vec[i] = (int)Float.parseFloat(st.nextToken());
      }
      return vec;
    }catch(Exception ex){
      System.err.println("invalid format during parsing line:" + line);
      return null;
    }
  }
  public static int getNumTokens(String line, String sep){
	    StringTokenizer  st = new StringTokenizer(line,sep);
	    return st.countTokens();
  }

  public static Set<Integer> string2intSet(String line, String sep){
	  	Set<Integer> set = new HashSet<Integer>();
	    StringTokenizer  st = new StringTokenizer(line,sep);
	    try{
	      for(int i=0;i<st.countTokens();i++)
	    	  set.add(Integer.parseInt(st.nextToken()));	      
	      return set;
	    }catch(Exception ex){
	      System.err.println("invalid format during parsing line:" + line);
	      return null;
	    }
  }
  public static void string2intSet(String line, String sep, Set<Integer> set){
	    StringTokenizer  st = new StringTokenizer(line,sep);
	    try{
	      for(int i=0;i<st.countTokens();i++)
	    	  set.add(Integer.parseInt(st.nextToken()));	      
	    }catch(Exception ex){
	      System.err.println("invalid format during parsing line:" + line);
	    }
  }
  
  public static float[] string2floatArray(String line, String sep){
    StringTokenizer  st = new StringTokenizer(line,sep);
    try{
      float[] vec = new float[st.countTokens()];
      for(int i=0;i<vec.length;i++){
        vec[i] = Float.parseFloat(st.nextToken());
      }
      return vec;
    }catch(Exception ex){
      System.err.println("invalid format during parsing line:" + line);
      return null;
    }
  }
  public static float[] string2floatArray(String line, String sep,int from, int to){
	    StringTokenizer  st = new StringTokenizer(line,sep);
	    try{
	      float[] vec = new float[to-from+1];
	      for(int i=0,j=0;i<st.countTokens();i++){
	    	  float f = Float.parseFloat(st.nextToken());
	    	  if(i >=from  && i <= to)
	    		  vec[j++] = f;
	      }
	      return vec;
	    }catch(Exception ex){
	      System.err.println("invalid format during parsing line:" + line);
	      return null;
	    }
	  }

  public static double[] string2doubleArray(String line, String sep){
    StringTokenizer  st = new StringTokenizer(line,sep);
    try{
      double[] vec = new double[st.countTokens()];
      for(int i=0;i<vec.length;i++){
        vec[i] = Double.parseDouble(st.nextToken());
      }
      return vec;
    }catch(Exception ex){
      System.err.println("invalid format during parsing line:" + line);
      return null;
    }
  }

  // parse a line of a comma separated vector and return
  // the vector as of array of float.
  public static float[] parseLine1(String line, String separator){
    StringTokenizer  st = new StringTokenizer(line,separator);
    try{
      float[] vec = new float[st.countTokens()];
      for(int i=0;i<vec.length;i++){
	  vec[i] = Float.parseFloat(st.nextToken());
      }
      return vec;
    }catch(Exception ex){
      System.err.println("invalid format during parsing line:" + line);
      return null;
    }
  }

  public static List<String> line2List(String line, String separator){
	StringTokenizer  st = new StringTokenizer(line,separator);
	List<String> lst = new ArrayList<String>();
	try{
	  int N = st.countTokens();
	  for(int i=0;i<N;i++) lst.add(st.nextToken());	   
	  return lst;
	}catch(Exception ex){
	  System.err.println("invalid format during parsing line:" + line);
	  return null;
	}
  }

  public static void line2List2(String line, String separator,List<String> lst){
		StringTokenizer  st = new StringTokenizer(line,separator);
		try{
		  int N = st.countTokens();
		  for(int i=0;i<N;i++) lst.add(st.nextToken());	   
		}catch(Exception ex){
		  System.err.println("invalid format during parsing line:" + line);
		}
	  }

  
  public static void parseLine1(String line, String separator, Object[] ref_target){
    StringTokenizer  st = new StringTokenizer(line,separator);
    try{
      int no_tokens = st.countTokens();
      float[] vec = new float[no_tokens - 1];
      for(int i=0;i<vec.length;i++){
        vec[i] = Float.parseFloat(st.nextToken());
      }
      ref_target[0] = vec;
      ref_target[1] = st.nextToken();
    }catch(Exception ex){
      System.err.println("invalid format during parsing line:" + line);
    }
  }

  public static String[] line2StringArray2(String line,String delim){
    List<String> ret = new ArrayList<String>();
    int f_ind = 0;
    int t_ind = 0;
    int len = delim.length();
    boolean isDone = false;
    while(!isDone){
     t_ind = line.indexOf(delim,f_ind);
     if(t_ind == -1){
	 t_ind = line.length();
	 isDone = true;
     }
     ret.add(line.substring(f_ind,t_ind).trim());
     f_ind = t_ind + len;
    }	
    return ret.toArray(new String[0]);
  }

  public static String[] line2StringArray(String line, String separator){
    StringTokenizer  st = new StringTokenizer(line,separator);
    try{
      String[] vec = new String[st.countTokens()];
      for(int i=0;i<vec.length;i++){
        vec[i] = st.nextToken().trim();
      }
      return vec;
    }catch(Exception ex){
      System.err.println("invalid format during parsing line:" + line);
      return null;
    }
  }

  // parse a line of a comma separated vector and return
  // the vector as of array of float.
  public static double[] parseLine(String line, String separator){
    StringTokenizer  st = new StringTokenizer(line,separator);
    try{
      double[] vec = new double[st.countTokens()];
      for(int i=0;i<vec.length;i++){
        vec[i] = Float.parseFloat(st.nextToken());
      }
      return vec;
    }catch(Exception ex){
      System.err.println("invalid format during parsing line:" + line);
      return null;
    }
  }

  // parse a line of a comma separated vector and return
  // the vector as of array of float.
  public static float[] parseLine1(String line, String separator,int dim){
    StringTokenizer  st = new StringTokenizer(line,separator);
    try{
      float[] vec = new float[dim];
      for(int i=0;i<vec.length;i++){
        vec[i] = Float.parseFloat(st.nextToken());
      }
      return vec;
    }catch(Exception ex){
      System.err.println("invalid foramt during parsing line:" + line);
      return null;
    }
  }

  /**
   * parse a line of a the format:
   * keyword1=freq keyword2=freq keyword3=freq .....
   * this is used in the text/document processing datasets.
   */
  public static Map parseLine2(String line, String separator){
    StringTokenizer  st = new StringTokenizer(line,separator);
    Map<String,Integer> vec = new HashMap<String,Integer>();
    try{
      while(st.hasMoreTokens()){
        String token = st.nextToken();
        int equalIndex = token.indexOf("=");
        String kw = token.substring(0,equalIndex);
        Integer freq = new Integer(token.substring(equalIndex + 1));
        vec.put(kw,freq);
      }
    }catch(Exception ex){
      System.err.println("invalid format during parsing line:" + line);
      System.exit(0);
    }
    return vec;
  }

  public static Map parseLine3(String line){
    return parseLine3(line," ");
  }
  public static Map parseLine3(String line, String separator){
    StringTokenizer  st = new StringTokenizer(line,separator);
    Map<String,Float> vec = new HashMap<String,Float>();
    try{
      while(st.hasMoreTokens()){
        String token = st.nextToken();
        int equalIndex = token.indexOf("=");
        String kw = token.substring(0,equalIndex);
        Float weight = new Float(token.substring(equalIndex + 1));
        vec.put(kw,weight);
      }
    }catch(Exception ex){
      System.err.println("invalid format during parsing line:" + line);
      //System.exit(0);
    }
    return vec;
  }

  public static void printMap(Map map){
    Iterator iter = map.keySet().iterator();
    for(;iter.hasNext();){
      Object k = iter.next();
      String key = k.toString();
      String value = map.get(k).toString();
      System.out.println(key + ":" + value);
    }
  }
  /**
   * 
   * @param ref float reference/vector to be formated for printing...
   * @param separator: string seperator between numbers
   * @return : string representation of the vector/ref.
   */
  public static String formatArray(float[] ref, String separator){
    StringBuffer sb = new StringBuffer(100);
    int x = ref.length - 1;
    for(int i=0;i<ref.length;i++){
      sb.append(ref[i]);
      if(i != x)
        sb.append(separator);
    }
    return sb.toString();
  }
/**
 * 
 * @param ref
 * @return string representation of ref
 */
  public static String formatArray(int[] ref){
    return formatArray(ref,",");
  }
/**
 * 
 * @param ref
 * @param separator: seperator used for separating values of the vector
 * @return string represenation of ref/vector
 */
  public static String formatArray(int[] ref, String separator){
    return formatArray(ref,separator,0,ref.length);
  }
/**
 * 
 * @param ref
 * @param separator
 * @param from: starting from index
 * @param to: ending at index
 * @return: string representation of the subarray of the reference.
 */
  public static String formatArray(int[] ref, String separator,int from, int to){
    StringBuffer sb = new StringBuffer(100);
    int x = ref.length - 1;
    for(int i=from;i<to;i++){
      sb.append(ref[i]);
      if(i != x)
        sb.append(separator);
    }
    return sb.toString();
  }
/**
 * 
 * @param ref
 * @param separator
 * @return string representation of the reference.
 */
  public static String formatArray(double[] ref, String separator){
    StringBuffer sb = new StringBuffer(100);
    int x = ref.length - 1;
    for(int i=0;i<ref.length;i++){
      sb.append(ref[i]);
      if(i != x)
        sb.append(separator);
    }
    return sb.toString();
  }

  /**
   * convert an array of string elements into a string with SPACE as separator.
   * @param ref
   * @return
   */
  public static String formatArray(String[] ref){
      return formatArray(ref,",");
  }
  /**
   * convert an array of string elements into a string 
   * @param ref
   * @param separator
   * @return
   */
  public static String formatArray(String[] ref, String separator){
    StringBuffer sb = new StringBuffer(100);
    int x = ref.length - 1;
    for(int i=0;i<ref.length;i++){
      sb.append(ref[i]);
      if(i != x)
        sb.append(separator);
    }
    return sb.toString();
  }
  /**
   * convert an array of string elements into a string starting at (inclusively) fromIndex 
   * up to the end of the array
   * @param ref
   * @param separator
   * @param fromIndex
   * @return
   */
  public static String formatArray(String[] ref,String separator,int fromIndex){
	  return formatArray(ref,separator,fromIndex,ref.length);
  }
  /**
   * convert an array of string elements into a string starting at (inclusively) fromIndex
   * and ending (exclusively) at toIndex.
   * @param ref array of strings
   * @param separator
   * @param fromIndex
   * @param toIndex
   * @return
   */
  public static String formatArray(String[] ref, String separator,int fromIndex, int toIndex){
	    StringBuffer sb = new StringBuffer(100);
	    int x = ref.length - 1;
	    for(int i=fromIndex;i<toIndex;i++){
	      sb.append(ref[i]);
	      if(i != x)
	        sb.append(separator);
	    }
	    return sb.toString();
	  }
/**
 * 
 * @param ref
 * @param from
 * @param to
 * @return string representation of the reference
 */
  public static String formatArray(float[] ref, int from, int to){
    StringBuffer sb = new StringBuffer(100);
    int x = to - 1;
    //sb.append("[");
    for(int i=from;i<to;i++){
      sb.append(ref[i]);
      if(i != x)
        sb.append(" ");
    }
    //sb.append("]");
    return sb.toString();
  }

  public static String formatArray(float[] ref){
    return formatArray(ref," ");
  }

  public static String formatArray(double[] ref){
    return formatArray(ref," ");
  }
  /**
   * return a random integer between from (inclusive) and to (exclusive)
   * @param from from the int (inclusive)
   * @param to up to the int (exclusive)
   * @return the random r, such that   from <=  r < to
   */
  public static int getRandomInt(int from, int to){
    return (int)(Math.abs(to - from ) * random.nextDouble()) + from;    
  }

  public static int getRandomInt(){
      return random.nextInt();
  }

  public static double getRandomDouble(){
    return random.nextDouble();
  }

  public static float getRandomFloat(){
    return random.nextFloat();
  }


  public static double getRandomDouble(double from, double to){
    return (to - from) * random.nextDouble() + from;
  }
  public static float getRandomFloat(float from, float to){
    return (to - from) * (float) random.nextDouble() + from;
  }

  /*
   * prompt the user to enter something.
   */
  public static void prompt(){
    try{
      System.out.print("press any key to continue:\n");
      byte[] line = new byte[100];
      System.in.read(line);
    }catch(Exception ex){
      System.err.println(ex);
    }
  }

  /*
   * read the whole file and return it as a string...
   */
  public static String readFile(String file){
    try{
      BufferedReader br = new BufferedReader(new FileReader(file));
      String line = null;
      StringBuffer sb = new StringBuffer(510);
      while( (line = br.readLine()) != null){
        sb.append(line ).append("\n");
      }
      br.close();
      return sb.toString();
    }catch(Exception ex){
      System.err.println(ex);
      return "";
    }
  }

  public static<T> Map<T,T> list2map(List<T> lst){
      Map<T,T> map = new HashMap<T,T>();
      for(int i=0;i<lst.size();i++){
	  map.put(lst.get(i),lst.get(i));
      }
    return map;
  }

  public static<T> List<T> map2list(Map<T,T> map,boolean isKey){
      Iterator<T> iter = map.keySet().iterator();
      List<T> lst = new ArrayList<T>();
      for(;iter.hasNext();){
	  T obj = iter.next();
	  if(isKey){
	      lst.add(obj);
	  }else{
	      lst.add(map.get(obj));
	  }
      }
    return lst;
  }

  public static List<float[]> file2floatList2(String file, String separator){
    List<float[]> lst = new ArrayList<float[]>();
    try{
      BufferedReader br = new BufferedReader(new FileReader(file));
      String line = null;
      while( (line = br.readLine()) != null){
        if(line.isEmpty()) continue;
        lst.add(parseLine1(line, separator));
      }
      br.close();
    }catch(Exception ex){
      System.err.println(ex);
      System.exit(0);
    }
    return lst;
  }
  public static List<String> file2StringList(String file){
    List<String> lst = new ArrayList<String>();
    try{
      BufferedReader br = new BufferedReader(new FileReader(file));
      String line = null;
      while( (line = br.readLine()) != null){
        if(line.isEmpty() || line.startsWith("#")) continue;
        lst.add(line);
      }
      br.close();
    }catch(Exception ex){
      System.err.println(ex);
      //System.exit(0);
    }
    return lst;
  }

  public static List<float[]> file2floatList(String file, String separator){
    List<float[]> lst = new ArrayList<float[]>();
    try{
      BufferedReader br = new BufferedReader(new FileReader(file));
      String line = null;
      while( (line = br.readLine()) != null){
        if(line.isEmpty()) continue;
        float[] arr = parseLine1(line, separator);
        if(arr != null) lst.add(arr);
      }
      br.close();
    }catch(Exception ex){
      System.err.println(ex);
      System.exit(0);
    }
    return lst;
  }

  public static List<int[]> file2intList(String file, String separator){
    List<int[]> lst = new ArrayList<int[]>();
    try{
      BufferedReader br = new BufferedReader(new FileReader(file));
      String line = null;
      while( (line = br.readLine()) != null){
        if(line.isEmpty()) continue;
        int[] arr = string2intArray(line, separator);
        if(arr != null)lst.add(arr);
      }
      br.close();
    }catch(Exception ex){
      System.err.println(ex);
      System.exit(0);
    }
    return lst;
  }

  public static List<double[]> file2doubleList(String file, String separator){
    List<double[]> lst = new ArrayList<double[]>();
    try{
      BufferedReader br = new BufferedReader(new FileReader(file));
      String line = null;
      while( (line = br.readLine()) != null){
        if(line.isEmpty()) continue;
        lst.add(parseLine(line, separator));
      }
      br.close();
    }catch(Exception ex){
      System.err.println(ex);
      System.exit(0);
    }
    return lst;
  }

  /**
    * The input format of the file is:
    **********************************
    * 1 2 3 4 class
    *
    * The output format of the file is
    **********************************
    * #window:2
    * #The dimention of vectors
    * 16
    * #Target [ point]
    * 1 [0.1139141 4 43 4 ]
    */

  public static void prepareMultiClass(int class1,int class2 ,String file_name,String dest){
    try{
      BufferedReader br = new BufferedReader(new FileReader(file_name));
      String dest_file = dest + class1 + "_" + class2+".txt";
      /*
      if(class2 == 0){
        dest_file = dest_file + "#.txt";
      }else{
        dest_file = dest_file + class2 + ".txt";
      }
      */
      FileWriter fw = new FileWriter(dest_file);
      StringBuffer sb = new StringBuffer(512);
      sb.append("#The dimension of the vectors\n");
      String line = null;
      boolean isFirst = true;
      while((line = br.readLine()) != null){
        float[] vec = parseLine1(line," ");
        int class_index = vec.length - 1;
        //vec[class_index]++; // was added to avoid the classes starts with 0
        if(isFirst){
          sb.append(vec.length).append("\n");
          isFirst = false;
          sb.append("## target [vector value]\n");
        }
        if(class2 != 0){
          if(vec[class_index] == class1){
            sb.append("1 ");
          }else if(vec[class_index] == class2){
            sb.append("-1 ");
          }else{
            // just continue
            continue;
          }
          sb.append(formatArray(vec,0,class_index)).append("\n");
        }else{
          if(vec[class_index] == class1){
            sb.append("1 ");
          }else{
            sb.append("-1 ");
          }
          sb.append(formatArray(vec,0,class_index)).append("\n");
        }
        if(sb.length() > 10 * 1024){
          fw.write(sb.toString());
          sb.delete(0,sb.length());
        }
      }
      fw.write(sb.toString());
      fw.flush();
      fw.close();
    }catch(Exception ex){
      System.out.println(ex);
      System.exit(-1);
    }
  }
  public static void prepareClass(String file_name,String dest){
    try{
      BufferedReader br = new BufferedReader(new FileReader(file_name));
      FileWriter fw = new FileWriter(dest);
      StringBuffer sb = new StringBuffer(512);
      sb.append("#The dimension of the vectors\n");
      String line = null;
      boolean isFirst = true;
      while((line = br.readLine()) != null){
        float[] vec = parseLine1(line," ");
        int class_index = vec.length - 1;
        if(isFirst){
          sb.append(vec.length).append("\n");
          isFirst = false;
          sb.append("## target [vector value]\n");
        }
        sb.append((int)vec[class_index]+1).append(" ");
        sb.append(formatArray(vec,0,class_index)).append("\n");
        if(sb.length() > 10 * 1024){
          fw.write(sb.toString());
          sb.delete(0,sb.length());
        }
      }
      fw.write(sb.toString());
      fw.flush();
      fw.close();
    }catch(Exception ex){
      System.out.println(ex);
      System.exit(-1);
    }
  }
  public static int[] getRandomList(int total,double percentage){
    int t = (int) (percentage * total);
    if(t < total) t++;
    int[] lst = new int[t];
    for(int i=0;i<t;i++){
      int index = getRandomInt(0,total);
      lst[i] = index;
    }
    return lst;
  }

  public static int[] getRandomList(int total){
    int[] lst = new int[total];
    for(int i=0;i<total;i++){
      int index = getRandomInt(0,total);
      lst[i] = index;
    }
    return lst;
  }

  public static int[] getRandomList2(int total, int start){
    int[] lst = new int[total];
    for(int i=0;i<total;i++){
      int index = getRandomInt(0,total) + start;
      lst[i] = index;
    }
    return lst;
  }

  public static int[] getRandomList3(int from, int to,int total){
    Map<String,String> map = new HashMap<String,String>();
    int[] lst = new int[total];
    for(int i=0;i<lst.length;){
      int index = getRandomInt(from,to);
      if(map.get(index+"") == null){
        lst[i] = index;
        map.put(index+"","");
        i++;
      }
    }
    return lst;
  }

  public static<T> void shuffle(List<T> lst){
    List<T> _lst = new ArrayList<T>(lst.size());
    int N = lst.size();
    for(int i=0;i<N;i++){
      int index = getRandomInt(0,lst.size());
      _lst.add(lst.remove(index));
    }
    lst.clear();
    lst.addAll(_lst);
    _lst.clear();
  }

  public static<T> void shuffle(List<T> lst1, List<T> lst2){
    List<T> _lst1 = new ArrayList<T>(lst1.size());
    List<T> _lst2 = new ArrayList<T>(lst1.size());
    int N = lst1.size();

    for(int i=0;i<N;i++){
      int index = getRandomInt(0,lst1.size());
      _lst1.add(lst1.get(index));
      _lst2.add(lst2.get(index));
    }
    lst1.clear();
    lst2.clear();
    lst1.addAll(_lst1);
    lst2.addAll(_lst2);
    _lst1.clear();
    _lst2.clear();
  }

  public static float[] getFloatArray(double[] arr){
    float[] f = new float[arr.length];
    for(int i=0;i<arr.length;i++){
      f[i] = (float)arr[i];
    }
    return f;
  }
  public static void copyArray(double[] src, double[] dest){
    for(int i=0;i<src.length;i++)
     dest[i] = src[i];
  }

  public static String getKernelString(int i){
    String ks = "";
    switch(i){
      case 0: return "L";
      case 1: return "RBF";
      case 2: return "Q";
      case 3: return "C";
    }
    return ks;
  }

  public static String getKernelString2(int i){
    String ks = "";
    switch(i){
    /*
     * 0 -- linear: u'*v
     * 1 -- polynomial: (gamma*u'*v + coef0)^degree
     * 2 -- radial basis function: exp(-gamma*|u-v|^2)
     * 3 -- sigmoid: tanh(gamma*u'*v + coef0)
     */
      case 0: return "LINEAR";
      case 1: return "POLY";
      case 2: return "RBF";
      case 3: return "SIG";
    }
    return ks;
  }

  public static String line2svmlib(String line,String target_plus_1){
     String[] fields = CommonUtil.line2StringArray(line,",");
     StringBuffer sb = new StringBuffer();
     String target = fields[fields.length-1];
     if(target.equals(target_plus_1)){
       sb.append("1 ");
     }else{
       sb.append("-1 ");
     }
     for(int i=0;i<fields.length-1;i++){
       sb.append(i+1).append(':').append(fields[i]);
       if(i<(fields.length-2)){
         sb.append(' ');
       }
     }
     return sb.toString();
  }
  public static long[] stringip2longip(String ip){
    ip = ip.trim();
    StringTokenizer  st = new StringTokenizer(ip,".");
    try{
      long[] vec = new long[st.countTokens()];
      for(int i=0;i<vec.length;i++){
        vec[i] = Long.parseLong(st.nextToken());
      }
      return vec;
    }catch(Exception ex){
      System.err.println("invalid format during ip:" + ip);
      return null;
    }
  }

  public static long getIp(String ip){
    long [] lip = stringip2longip(ip.trim());
    if(lip.length > 4) return -1;
    long myIp = 0;
    for(int i=0;i<lip.length;i++){
      myIp += lip[i] << (8 * (3 - i));
    }
    return myIp;
  }
  public static String getIp(long ip){
    long l = 255;
    String ip_str = "";
    long buf = 0;
    for(int i=0;i<4;i++){
      buf = ip & (l << i * 8);
      buf = buf >> (i * 8);
      if(i != 3)
        ip_str = "." + buf +  ip_str;
      else
        ip_str = buf + ip_str;
    }
    return ip_str;
  }
  public static String replace(String line, String from_str, String to_str){
    StringBuffer buf = new StringBuffer(512);
    int index1 = line.indexOf(from_str);
    int index2 = 0;
    while(index1 >= 0){
      buf.append(line.substring(index2,index1));
      buf.append(to_str);
      index2 = index1 + from_str.length();
      index1 = line.indexOf(from_str,index2);
      if(index1<0) break;
    }
    buf.append(line.substring(index2));
    return buf.toString();
  }
  public static String getColor(int id){
       int index = id % 11;
       switch(index){
         case 0: return "red";
         case 1: return "black";
         case 2: return "cyan";
         case 3: return "blue";
         case 4: return "gray";
         case 5: return "green";
         case 6: return "magenta";
         case 7: return "orange";
         case 8: return "pink";
         case 9: return "white";
         case 10:return "yellow";
         default: return "black";
      }
  }
  public static void persist(String file_name,List lst){
    try{
      BufferedWriter bw = new BufferedWriter(new FileWriter(file_name));
      for(int i=0;i<lst.size();i++){
        bw.write(((String)lst.get(i)) + "\n");
      }
      bw.close();
    }catch(Exception ex){
      cout.println(ex);
    }
  }

  

  public static <T> void printArray(T[] arr){
	for(T i : arr){
		System.out.println(i);
	}
  }

  public static void sort(int[] arr){
    for(int i=0;i<arr.length;i++)
      for(int j=i;j<arr.length;j++){
        if(arr[i] > arr[j]){
          int tmp = arr[i];
          arr[i] = arr[j];
          arr[j] = tmp;
        }
      }
  }
  public static float[] getMaxValues(List<float[]> data){
      float[] max = new float[data.get(0).length];
      for(float[] v : data){
          int ind = 0;
          for(float f : v){
              max[ind] = Math.max(f,max[ind]);
              ind++;
          }
      }
      return max;
  }
  
  public static float[] getMaxValues(String file_name){
    return getMaxValues(file_name,",");
  }

  public static float[] getMaxValues(String file_name, String sep){
    try{
      BufferedReader br = new BufferedReader(new FileReader(file_name));
      String line = null;
      float[] max_values = null;
      int index = 0;
      while((line = br.readLine()) != null){
        if(line.startsWith("#") || line.trim().equals("")) continue;
        float[] ref = parseLine1(line,sep);
        if(index == 0){
          max_values = new float[ref.length];
          for(int i=0;i<max_values.length;i++) max_values[i] = ref[i];
          continue;
        }else{
          for(int i=0;i<max_values.length;i++)
             max_values[i] = Math.max(ref[i],max_values[i]);
        }
        index++;
      }
      return max_values;
    }catch(Exception ex){
      System.err.println(ex);
      return null;
    }
  }

  public static int[] computeIndeces(String s){
    int hash_index = s.indexOf("-");
    if(hash_index != -1){
      int start = Integer.parseInt(s.substring(0,hash_index));
      int end = Integer.parseInt(s.substring(hash_index + 1));
      int[] ret = new int[end - start + 1];
      for(int i=0;i<ret.length;i++)
        ret[i] = start + i;
      return ret;
    }else{
      int[] ret = CommonUtil.string2intArray(s,",");
      return ret;
    }
  }

  public static void main(String[] args){
    String[] cmd = {"C:/Program Files/apriori/apriori.exe",
                    //"C:/Program Files/apriori/apriori.exe",
                    "C:/Program Files/apriori/window_3_output.txt",
                    "C:/Program Files/apriori/rules.txt",
                    "0.001"
                    };
    execute(cmd);
    System.out.println("main is done...");
    System.out.println("running in the same thread.....");
//    execute(cmd);
    System.out.println("done in the main thread....");
  }


  public static void execute(String[] command, boolean noWait){
    if(noWait){
      new ExecThread(command).start();
    }else{
      execute(command);
    }
  }

  public static void execute(String[] command){
    try{
      Process p = Runtime.getRuntime().exec(command);
      VThread t1 = new VThread( p.getErrorStream(),"error>>");
      VThread t2 = new VThread( p.getInputStream(),"output>>");
      t1.start();
      t2.start();
      t1.join();
      t2.join();
            
      System.out.println("status:" + p.exitValue());
      System.out.println("execution is done.........");
    }catch(Exception ex){
      System.out.println(ex);
      System.exit(9);
    }
  }
  public static float[] normalize(float[] ref, float[] max_values){
	float[] ret = new float[ref.length];
	for(int i=0;i<ret.length;i++){
	    if(ref[i] == 0) ret[i] = 0;
	    else
		ret[i] = ref[i] / max_values[i];
	}
	return ret;
  }
  public static float[] normalize2(float[] ref, float[] max_values){
	for(int i=0;i<ref.length;i++){
	    ref[i] = ref[i] / max_values[i];
	}
	return ref;
  }
  public static float trunc(float f,int n){
    if(n < 0) n = 0;    
    String f_str = f + "";    
    int index = f_str.indexOf(".");
    if((index + n) > f_str.length() || index == -1) return f;
    int to= index + n +1;
    if(to > f_str.length()) to = f_str.length();
    return Float.parseFloat(f_str.substring(0,to));
  }
  public static double trunc(double f,int n){
    if(n < 0) n = 0;    
    String f_str = f + "";    
    int index = f_str.indexOf(".");
    if((index + n) > f_str.length() || index == -1) return f;
    int to= index + n +1;
    if(to > f_str.length()) to = f_str.length();
    return Double.parseDouble(f_str.substring(0,to));
  }  
   public static void slide2(float[] session, int window_size, 
			     List<float[]> lst){	
       int n = session.length - window_size + 1 ;
       if(n <= 0) return;
       for(int i=0;i<n;i++){
	   float[] sub = subarray(session,i,window_size + i);
	   lst.add(sub);
       }
   }
}
class VThread extends Thread{
	InputStream is;
	String msg;
	VThread(InputStream is,String msg){ 
		this.is = is;
		this.msg = msg;
	}
	public void run(){
		int b =0;
		try{
			System.out.print(msg);
			while( (b=is.read()) != -1){
				System.out.print((char)b);
				if((char)b == '\n')
					System.out.print(msg);
			}
			is.close();
		}catch(Exception ex){
			ex.printStackTrace();
		}
		System.out.println("thread is done...");
	}
	
}
class ExecThread extends Thread{
  private String[] command;
  ExecThread(String[] cmd){
    super();
    command = cmd;
  }
  public void run(){
    System.out.println("running command in separate thread...");
    CommonUtil.execute(command);
  }
}

