/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medicalapp;


import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;

public class Stats{
    private int correct;
    private int incorrect;
    //Integer: label, Pair: number of correctly classified, and total number
    // of that class points...
    private Map<Integer,Pair<Double,Double>> map = new HashMap<Integer,Pair<Double,Double>>();
    public Stats(){}
    public int getCorrect(){ return correct;}
    public int getIncorrect(){ return incorrect;}
    public float getAccuracy(){ return (float) correct / total();}
    public float getErrRate(){ return (float) incorrect / total();}
    public float getRate(){ return (float) correct / incorrect;}
    public int total(){ return correct + incorrect;}
    public void update(boolean isCorrect){
    	if(isCorrect){
    		correct++;
    	}else{
    		incorrect++;
    	}
    }
    public void update(int label, boolean isCorrect){
    	update(isCorrect);
    	Pair<Double,Double> p = map.get(label);
    	if(p == null){
    		if(isCorrect)
    			p = new Pair<Double,Double>(1.0,1.0);
    		else
    			p = new Pair<Double,Double>(0.0,1.0);
    	}else{
    		if(isCorrect){
    			p.setFirst(p.First()+1);
    			p.setSecond(p.Second()+1);
    		}else{
    			p.setSecond(p.Second()+1);
    		}
    	}
    	map.put(label,p);
    }

    private String map2string(){
    	Iterator<Integer> iter = map.keySet().iterator();
    	StringBuffer sb = new StringBuffer(514);
    	while(iter.hasNext()){
    		int label = iter.next();
    		Pair<Double,Double> p = map.get(label);
    		sb.append("\n[label:").append(label).append(",correct:").
    		append(p.First()).append(", total:").append(p.Second()).
    		append("]====>").append("Accuracy:").
    		append(p.First()/p.Second()).append("\n");
    	}
    	return sb.toString();
    }

    public String toString(){
    	StringBuffer sb = new StringBuffer(1024);
    	sb.append("Stats:\n").append("correct:").append(correct).append(",\n").
	    append("incorrect:").append(incorrect).append(",\n").
	    append("total:").append(total()).append(",\n").
	    append("Over all Accuracy:").append(getAccuracy()).append(",\n").
	    append("ErrRate:").append(getErrRate()).append(",\n").
	    append("Rate:").append(getRate()).append(",\n").
	    append(map2string());
    	return sb.toString();
    }
}
////////////////////////////////
class Pair<T extends Comparable<T> ,S extends Comparable<S> > 
		implements Comparable<Pair<T,S>>{
	protected T first;
	protected S second;
	
	public Pair(){}
	public Pair(T first, S second){
		this.first = first;
		this.second = second;
	}
	public T First(){ return first;}
	public S Second(){ return second;}
	public void setFirst(T first){ this.first = first;}
	public void setSecond(S second){ this.second = second;}
	public String toString(){
		return "(" + first + "," + second + ")";
	}
	public boolean equals(Pair<T,S> p){
		return p.first.equals(this.first) && p.second.equals(this.second);
	}
	 public int hashCode(){
		 String str = this.first.toString() + "" + this.second.toString();
		 return str.hashCode();
	 }
	 public int compareTo(Pair<T,S> pair){
		 return pair.second.compareTo(this.second);
	 }
}

