/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medicalapp;

import java.io.*;
public class Logger{


   private static final String DEFAULT_LOG_FILE = "debug.log";
   private static final String DEFAULT_LOG_DIR = "./";
   private static final String MY_NAME = "Logger";
   private static final String EMPTY_STR = "";

   private String guestClassName = "";
   private boolean isActive = true;
   private boolean isWithTime = false;
   private PrintStream out = System.out;
   private boolean isRaw = false;
   
   private Logger( String logDir, 
                  String logFileName, 
                  boolean append,
                  boolean isActive,
                  boolean isSTDOUT
                 )
   {
      try{
         if(isSTDOUT){
           out = System.out;
         }else{
           out = new PrintStream(new FileOutputStream(logDir + logFileName,append),true);
         }
         this.isActive = isActive;
      }catch(Exception ex){
         System.out.println("Logger:" + ex);
         System.exit(-1);
      }
   }
   
   public Logger(){
     this(DEFAULT_LOG_DIR , DEFAULT_LOG_FILE, false,true,true);
   }

   public Logger(String logDir, String logFileName, boolean append){
     this(logDir , logFileName, append,true,false);     
   }

   public Logger(String logFileName, boolean append){
     this("" , logFileName, append,true,false);     
   }

   public void setClassName(Object obj){
     this.guestClassName = obj.getClass().getName();
   }

   public void setLogger(boolean b){
     isActive = b;
   }

   public void setWithTime(boolean b){
     isWithTime = b;
   }

   public void setRaw(boolean raw){
     this.isRaw = raw;
   }
   
   public static long getTime(){
     return System.currentTimeMillis();
   }
   
   private StringBuffer sb = new StringBuffer(1024);
   private String str(Object msg){
	   if(isRaw) return msg.toString();
	   sb.delete(0, sb.length());
	   String cn = this.guestClassName + " >>";
	   String _msg = msg.toString();
	   sb.append(cn);
	   String time = EMPTY_STR;	   
	   if(isWithTime)   {
		   time = getTime() + "";
		   sb.append(":").append(time).append(":>>").append(_msg);
	   }else{
		   sb.append(_msg);
	   }
	   return sb.toString();	   
   }

   public Logger debug(Object msg){
	   if(!isActive) return this;
	   out.print(str(msg));
	   out.flush();
	   return this;
   }

   public Logger debugxxx(Object msg){          
      String time = EMPTY_STR;
      String cn = this.guestClassName + " >>";
      if(isRaw)
        cn = "";
      String _msg = msg.toString();
      if(!isActive) return this;
      if(isWithTime)   time = getTime() + "";
      if(time == EMPTY_STR)
        out.print(cn + _msg);
      else
         out.print(cn + ":" + time + ": >>"+ _msg);
      out.flush();
      return this;
   }

   public Logger debug(float[] msg){
     return print(msg);
   }
   public Logger debugln(float[] msg){
     return println(msg);
   }
   public Logger println(float[] fa){
     StringBuffer sb = new StringBuffer(1000);
     for(int j=0;j<fa.length;j++){
       sb.append(fa[j]).append(" ");
     }
     return debugln(sb.toString()+"\n");     
   }
   
   public Logger print(float[] fa){
     StringBuffer sb = new StringBuffer(1000);
     for(int j=0;j<fa.length;j++){
       sb.append(fa[j]).append(" ");
     }
     return debugln(sb.toString());
   }

    public Logger print(int[] fa){
	return printIntArray(fa,false);
    }
    public Logger println(int[] fa){
	return printIntArray(fa,true);
    }

   public Logger printIntArray(int[] fa,boolean flag){
     StringBuffer sb = new StringBuffer(1000);
     for(int j=0;j<fa.length;j++){
       sb.append(fa[j]).append(" ");
     }
     if(flag) sb.append('\n');
     return debugln(sb.toString());
   }
   
   public Logger debugln(Object msg){
      return debug(msg.toString() + "\n");
   }
   public Logger debugln(){
     return debug("\n");
   }
   public Logger println(Object msg){
      return debugln(msg);
   }
   public Logger print(Object msg){
      return debug(msg);
   }
   public Logger println(double msg){
      return debugln(msg + "");
   }
   public Logger print(double msg){
      return debug(msg + "");
   }
   public Logger println(){
     return debugln();
   }
   public void close(){
       try{
	   this.out.close();
       }catch(Exception ex){
       }
   }
}

