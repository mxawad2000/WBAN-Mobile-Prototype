/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medicalapp;

import libsvm.*;
import java.util.*;
import java.io.*;
/*
Usage: svm-train [options] training_set_file [model_file]
options:
-s svm_type : set type of SVM (default 0)
        0 -- C-SVC
        1 -- nu-SVC
        2 -- one-class SVM
        3 -- epsilon-SVR
        4 -- nu-SVR
-t kernel_type : set type of kernel function (default 2)
        0 -- linear: u'*v
        1 -- polynomial: (gamma*u'*v + coef0)^degree
        2 -- radial basis function: exp(-gamma*|u-v|^2)
        3 -- sigmoid: tanh(gamma*u'*v + coef0)
        4 -- precomputed kernel (kernel values in training_set_file)
-d degree : set degree in kernel function (default 3)
-g gamma : set gamma in kernel function (default 1/num_features)
-r coef0 : set coef0 in kernel function (default 0)
-c cost : set the parameter C of C-SVC, epsilon-SVR, and nu-SVR (default 1)
-n nu : set the parameter nu of nu-SVC, one-class SVM, and nu-SVR (default 0.5)
-p epsilon : set the epsilon in loss function of epsilon-SVR (default 0.1)
-m cachesize : set cache memory size in MB (default 100)
-e epsilon : set tolerance of termination criterion (default 0.001)
-h shrinking : whether to use the shrinking heuristics, 0 or 1 (default 1)
-b probability_estimates : whether to train a SVC or SVR model for probability estimates, 0 or 1 (default 0)
-wi weight : set the parameter C of class i to weight*C, for C-SVC (default 1)
-v n: n-fold cross validation mode
-q : quiet mode (no outputs)
*/
public class SVMUtil {

    public static float[] string2floatArray(String line, String sep) {
        StringTokenizer st = new StringTokenizer(line, sep);
        try {
            float[] vec = new float[st.countTokens()];
            for (int i = 0; i < vec.length; i++) {
                vec[i] = Float.parseFloat(st.nextToken());
            }
            return vec;
        } catch (Exception ex) {
            System.err.println("invalid format during parsing line:" + line);
            return null;
        }
    }

    public static svm_node get_svm_node(int index, float value) {
        svm_node node = new svm_node();
        node.index = index;
        node.value = value;
        return node;
    }

    public static svm_node get_svm_node(int index, double value) {
        svm_node node = new svm_node();
        node.index = index;
        node.value = value;
        return node;
    }

    public static svm_problem set_svm_problem(List<float[]> vecs, List<Integer> targets) {
        List<svm_node[]> vx = new ArrayList<svm_node[]>();
        for (int j = 0; j < vecs.size(); j++) {
            float[] ref = vecs.get(j);
            svm_node[] x = getSvmNode(ref);
            vx.add(x);
        }
        svm_problem prob = new svm_problem();
        prob.l = targets.size();
        prob.x = new svm_node[prob.l][];
        for (int i = 0; i < prob.l; i++) {
            prob.x[i] = vx.get(i);
        }
        prob.y = new double[prob.l];
        for (int i = 0; i < prob.l; i++) {
            prob.y[i] = targets.get(i).floatValue();
        }
        return prob;
    }

    public static svm_problem set_svm_problem2(List<double[]> vecs, List<Integer> targets) {
        List<svm_node[]> vx = new ArrayList<svm_node[]>();
        for (int j = 0; j < vecs.size(); j++) {
            double[] ref = vecs.get(j);
            svm_node[] x = getSvmNode(ref);
            vx.add(x);
        }
        svm_problem prob = new svm_problem();
        prob.l = targets.size();
        prob.x = new svm_node[prob.l][];
        for (int i = 0; i < prob.l; i++) {
            prob.x[i] = vx.get(i);
        }
        prob.y = new double[prob.l];
        for (int i = 0; i < prob.l; i++) {
            prob.y[i] = targets.get(i).floatValue();
        }
        return prob;
    }

    public static svm_node[] get_svm_node(float[] ref) {
        svm_node[] x = new svm_node[ref.length];
        for (int i = 0; i < ref.length; i++) {
            x[i] = get_svm_node(i + 1, (float) ref[i]);
        }
        return x;
    }

    public static svm_node[] get_svm_node(String strRef) {
        float[] ref = string2floatArray(strRef, " ");
        svm_node[] x = new svm_node[ref.length];
        for (int i = 0; i < ref.length; i++) {
            x[i] = get_svm_node(i + 1, (float) ref[i]);
        }
        return x;
    }

    public static svm_node[] getSvmNode(float[] ref) {
        int node_dim = 0;
        for (int i = 0; i < ref.length; i++) {
            if (ref[i] != 0f) {
                node_dim++;
            }
        }
        svm_node[] x = new svm_node[node_dim];
        for (int i = 0, j = 0; i < ref.length; i++) {
            if (ref[i] != 0f) {
                x[j] = get_svm_node(i + 1, ref[i]);
                j++;
            }
        }
        return x;
    }

    public static svm_node[] getSvmNode(float[] ref, int from, int to) {
        int node_dim = 0;
        for (int i = from; i < to; i++) {
            if (ref[i] != 0f) {
                node_dim++;
            }
        }
        svm_node[] x = new svm_node[node_dim];
        for (int i = from, j = 0; i < to; i++) {
            if (ref[i] != 0f) {
                x[j] = get_svm_node(i - from + 1, ref[i]);
                j++;
            }
        }
        return x;
    }

    public static svm_node[] getSvmNode(double[] ref) {
        int node_dim = 0;
        for (int i = 0; i < ref.length; i++) {
            if (ref[i] != 0f) {
                node_dim++;
            }
        }
        svm_node[] x = new svm_node[node_dim];
        for (int i = 0, j = 0; i < ref.length; i++) {
            if (ref[i] != 0f) {
                x[j] = get_svm_node(i + 1, ref[i]);
                j++;
            }
        }
        return x;
    }

    public static svm_node[] getSvmNode(float[] ref, int dim) {
        svm_node[] x = new svm_node[dim];
        for (int i = 0, j = 0; i < ref.length; i++) {
            if (ref[i] != 0f) {
                x[j] = get_svm_node(i + 1, ref[i]);
                j++;
            }
        }
        return x;
    }

    public static svm_parameter get_svm_param(Config argv) {
        svm_parameter param = new svm_parameter();
        // default values
        param.svm_type = svm_parameter.C_SVC;
        param.kernel_type = svm_parameter.RBF;
        param.degree = 3;
        param.gamma = 0.1;	// 1/k
        param.coef0 = 0;
        param.nu = 0.5;
        param.cache_size = 40;
        param.C = 1;
        param.eps = 1e-3;
        param.p = 0.1;
        param.shrinking = 1;
        param.probability = 0;
        param.nr_weight = 0;
        param.weight_label = new int[0];
        param.weight = new double[0];
        //int i_tmp = argv.getInt("svm_type");
        if (argv.hasKey("svm_type")) {
            param.svm_type = argv.getInt("svm_type");
        }
        //i_tmp = argv.getInt("kernel");
        //System.out.println("kernel type:" + i_tmp);
        if (argv.hasKey("kernel")) {
            param.kernel_type = argv.getInt("kernel");
        }
        String tmp = argv.getString("degree");
        if (tmp != null) {
            param.degree = Integer.parseInt(tmp);
        }
        tmp = argv.getString("gamma");
        if (tmp != null) {
            param.gamma = Float.parseFloat(tmp);
        }
        tmp = argv.getString("coef0");
        if (tmp != null) {
            param.coef0 = Float.parseFloat(tmp);
        }
        tmp = argv.getString("nu");
        if (tmp != null) {
            param.nu = Float.parseFloat(tmp);
        }
        tmp = argv.getString("cache_size");
        if (tmp != null) {
            param.cache_size = Float.parseFloat(tmp);
        }
        tmp = argv.getString("C");
        if (tmp != null) {
            param.C = Float.parseFloat(tmp);
        }
        tmp = argv.getString("eps");
        if (tmp != null) {
            param.eps = Float.parseFloat(tmp);
        }
        tmp = argv.getString("p");
        if (tmp != null) {
            param.p = Float.parseFloat(tmp);
        }
        //i_tmp = argv.getInt("shrinking");
        if (argv.hasKey("shrinking")) {
            param.shrinking = argv.getInt("shrinking");
        }
        //i_tmp = argv.getInt("probability");
        if (argv.hasKey("probability")) {
            param.probability = argv.getInt("probability");
        }
        System.out.println("params kernel:" + param.kernel_type);
        System.out.println("params svm_type:" + param.svm_type);
        System.out.println("params gamma:" + param.gamma);
        System.out.println("params coef:" + param.coef0);
        System.out.println("params degree:" + param.degree);
        System.out.println("Config:" + argv);
        
        
        
        return param;
    }

    public static svm_model load_svm_model(String file_path) {
        try {
            svm_model model = svm.svm_load_model(file_path);
            return model;
        } catch (Exception ex) {
            System.out.println("Exception during loading the svm_model:" + file_path);
            return null;
        }
    }

    public static svm_model train_svm(
            svm_problem problem,
            svm_parameter param,
            String model_name,
            Logger logger
    ) {
        BenchMark bm = new BenchMark();
        logger.println("training SVM ...........................");
        bm.start("training");
        svm_model model = svm.svm_train(problem, param);
        logger.println("saving the model...");
        logger.println("model:" + model_name);
        try {
            logger.println("persisting model:" + model_name);
            svm.svm_save_model(model_name, model);
        } catch (Exception ex) {
            logger.println(ex);
        }
        logger.println("training is done ............");
			  //logger.println("total training time:" + bm.end("training") + " millis");
        //logger.println("total training time:" + bm.getSeconds("training") + " seconds");	
        //logger.println("total training time:" + bm.getMinutes("training") + " minutes");
        //logger.println("testing the model:");
        return model;
    }

    public static svm_model train_svm(
            List<float[]> dataset,
            List<Integer> targets,
            String model_name,
            Config conf,
            Logger logger) {
        svm_problem svm_p = set_svm_problem(dataset, targets);
        svm_parameter params = get_svm_param(conf);
        BenchMark bm = new BenchMark();
        bm.start("train_svm");
        svm_model model = train_svm(svm_p, params, model_name, logger);
        logger.println("total training time:" + bm.end("train_svm") + " ms");
        Stats stat = new Stats();
        bm.start("test_svm");
        test_svm1(model, dataset, targets, logger, stat);
        long t = bm.end("test_svm");
        logger.println("average pred time:" + ((float)t/dataset.size()) + " ms");
        System.out.println(stat);
        logger.println(stat);
        return model;
    }

    public static void test_svm1(
            svm_model model,
            List<float[]> dset,
            List<Integer> tset,
            Logger cout,
            Stats stat) {
        cout.println("testing model.................");
        cout.println("size of testing set:" + dset.size());
        for (int i = 0; i < dset.size(); i++) {
            float[] ref = dset.get(i);
            int label = tset.get(i);
            svm_node[] node = getSvmNode(ref);
            int t = (int) svm.svm_predict(model, node);
            if (i % 1000 == 0) {
                //cout.println(i + " records already processed");
                //System.out.println("ref:" + Arrays.toString(ref) + "--> " + label + "===>" + t);
            }
            stat.update(label, t == label);
        }
        cout.println(stat);
    }

    public static Stats test_svm2(svm_model model, List<float[]> dset, List<Integer> tset, Logger cout) {
        Stats stat = new Stats();
        test_svm1(model, dset, tset, cout, stat);
        return stat;
    }

    public static List<Pair<Integer, Float>> test_svm_mc_1_rest(
            Map<Integer, svm_model> models,
            float[] ref,
            Map<Integer, String> exclude_lst) {
        List<Pair<Integer, Float>> lst = new ArrayList<Pair<Integer, Float>>();
        Iterator<Integer> iter = models.keySet().iterator();
        for (; iter.hasNext();) {
            int c = iter.next();
            if (exclude_lst.get(c) == null) {
                continue;
            }
            svm_model model = models.get(c);
            svm_node[] node = getSvmNode(ref);
            int t = (int) svm.svm_predict(model, node);
            if (t == c) {
                float margin = (float) Math.abs(svm_predict_values(model, node));
                lst.add(new Pair<Integer, Float>(t, margin));
            }
        }
        Collections.sort(lst);
        return lst;
    }

    /**
     * Pair<label, margin>
     *
     */
    public static Pair<Integer, Double> predict_binary(String modelFile, svm_node[] x) {
        try {
            double[] res = new double[1];
            svm_model model = svm.svm_load_model(modelFile);
            int label = (int) svm.svm_predict_values(model, x, res);
            return new Pair<Integer, Double>(label, res[0]);
        } catch (Exception ex) {
            ex.printStackTrace();
            System.exit(0);
        }
        return null;

    }

    public static Pair<Integer, Double> predict_binary(
            String modelFile,
            float[] ref,
            boolean isWithLabel) {
        double[] res = new double[1];
        svm_node[] x;
        if (isWithLabel) {
            x = getSvmNode(ref, 0, ref.length - 1);
        } else {
            x = getSvmNode(ref);
        }
        try {
            svm_model model = svm.svm_load_model(modelFile);
		    	//for(svm_node node : x)
            //System.out.print(node+" ");
            int label = (int) svm.svm_predict_values(model, x, res);
            return new Pair<Integer, Double>(label, res[0]);
        } catch (Exception ex) {
            ex.printStackTrace();
            System.exit(0);
        }
        return null;
    }

    public static Pair<Integer, Double> predict_binary(
            svm_model model,
            float[] ref,
            boolean isWithLabel) {
        double[] res = new double[1];
        svm_node[] x;
        if (isWithLabel) {
            x = getSvmNode(ref, 0, ref.length - 1);
        } else {
            x = getSvmNode(ref);
        }
        try {
            int label = (int) svm.svm_predict_values(model, x, res);
            return new Pair<Integer, Double>(label, res[0]);
        } catch (Exception ex) {
            ex.printStackTrace();
            System.exit(0);
        }
        return null;
    }

    public static double svm_predict_values(svm_model model, svm_node[] x) {
        double[] res = new double[1];
        svm.svm_predict_values(model, x, res);
        return res[0];
    }

    public static int svm_predict(svm_model model, float[] ref) {
        svm_node[] x = getSvmNode(ref);
        return svm_predict(model, x);
    }

    public static int svm_predict(svm_model model, svm_node[] x) {
        return (int) svm.svm_predict(model, x);
    }

    public static void trainSVMModel(String svmFN, String modelPath) {
        trainSVMModel(svmFN, modelPath, svm_parameter.LINEAR);
    }

    public static void trainSVMModel(String svmFN, String modelPath, int kernel) {
        //System.out.println("training Example Classifer starts now...........");
        System.out.println("svm File:" + svmFN);
        String path = ".\\svm_bin\\libsvm-3.1\\java\\";
        String classpath = path + ";" + path + "libsvm.jar ";
        String[] cmd = {"java.exe", "-Xmx800M", "-Xms800M", "-classpath", classpath,
            "svm_train", "-t", "" + kernel, svmFN, modelPath + ".model"};
        CommonUtil.execute(cmd);
    }

    /**
     * predict an example using SVM model
     *
     * @param testFN the file where testing examples reside in
     * @param modelPath location of SVM models.
     */
    public static void predictSVM(String testFN, String modelPath) {
        System.out.println("testing Example Classifer starts now...........");
        System.out.println("svm File:" + testFN);
        String path = ".\\svm_bin\\libsvm-3.1\\java\\";
        String classpath = path + ";" + path + "libsvm.jar ";
        String[] cmd = {"java.exe", "-Xmx800M", "-Xms800M", "-classpath", classpath,
            "svm_predict", testFN, modelPath + ".model", testFN + ".output"};
        CommonUtil.execute(cmd);
    }

    /**
     * start an ANN program for training...
     *
     * @param ANNCmd the command/program location and name.
     * @param conf configuration file to configure the ANN
     */
    public static void trainANN(String ANNCmd, String conf) {
        System.out.println("Running ANN command:" + ANNCmd);
        System.out.println("ANN Conf file:" + conf);
        String[] cmd = {ANNCmd, "-conf", conf};
        CommonUtil.execute(cmd);
    }

}
