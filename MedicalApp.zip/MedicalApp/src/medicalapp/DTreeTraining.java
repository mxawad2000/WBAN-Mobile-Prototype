/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medicalapp;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import static jdk.nashorn.internal.objects.NativeJava.type;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.meta.FilteredClassifier;
import weka.classifiers.misc.SerializedClassifier;
import weka.classifiers.trees.J48;
import weka.core.Attribute;
import weka.core.Debug;
import weka.core.DenseInstance;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.CSVLoader;
import weka.filters.supervised.instance.Resample;
//import weka.filters.supervised.instance.SMOTE;
/*
http://weka.sourceforge.net/doc.dev/weka/classifiers/trees/J48.html
parmeter list from weka docs:
alid options are:
 -U
  Use unpruned tree.
 -O
  Do not collapse tree.
 -C <pruning confidence>
  Set confidence threshold for pruning.
  (default 0.25
 -M <minimum number of instances>
  Set minimum number of instances per leaf.
  (default 2)
 -R
  Use reduced error pruning.
 -N <number of folds>
  Set number of folds for reduced error
  pruning. One fold is used as pruning set.
  (default 3)
 -B
  Use binary splits only.
 -S
  Don't perform subtree raising.
 -L
  Do not clean up after the tree has been built.
 -A
  Laplace smoothing for predicted probabilities.
 -J
  Do not use MDL correction for info gain on numeric attributes.
 -Q <seed>
  Seed for random data shuffling (default 1).
 -doNotMakeSplitPointActualValue
  Do not make split point actual value.
*/
/**
 *
 * @author Mamoun.Awad
 */
public class DTreeTraining {
    static List<String> labels = new ArrayList();
    static String[] j48_params = {"U", "O","C","M", "R", "N","B","S","L","A","J","Q","doNotMakeSplitPointActualValue"};
    static Config config;
    static String trainingResult;
    static J48 j48;
    public static Instances loadInstances(String CSVFilePath) {
        Instances data = null;
        try {
            CSVLoader loader = new CSVLoader();
            loader.setSource(new File(CSVFilePath));
            String[] options = new String[1];
            options[0] = "-H";
            loader.setOptions(options);
            data = loader.getDataSet();
            data.setClassIndex(data.numAttributes()-1);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        //System.out.println("data:" + data.toString());
        return data;
    }
    private static  void setJ48(J48 j48, Config config){
        if(config.getInt("U")==1) j48.setUnpruned(true);
        if(config.getInt("O")==1) j48.setCollapseTree(true);
        if(config.hasKey("C") ) j48.setConfidenceFactor(config.getFloat("C"));
        if(config.hasKey("M") ) j48.setMinNumObj(config.getInt("M"));
        if(config.getInt("R")==1 ) j48.setReducedErrorPruning(true);
        if(config.hasKey("N")) j48.setNumFolds(config.getInt("N"));
        if(config.getInt("B")==1 ) j48.setBinarySplits(true);
        if(config.getInt("S")==1 ) j48.setSubtreeRaising(true);
        System.out.println("unpruned:" + j48.getUnpruned());
        System.out.println("confidence:" + j48.getConfidenceFactor());
        System.out.println("Min Leaf:" + j48.getMinNumObj());
    }
    
    public static Classifier trainJ48(String dataset,String conf){
        try{
            config = new Config(conf);
            System.out.println("config:"+config);
            Instances data = loadInstances(dataset);
            //resample object.
            Resample resample = new Resample();
            resample.setInputFormat(data);
            j48 = new J48();
            setJ48(j48,config);
            j48.setConfidenceFactor(0.4f);
            j48.buildClassifier(data);
           
            //classifier filter
            FilteredClassifier fc = new FilteredClassifier();
            fc.setClassifier(j48);
            fc.setFilter(resample);
            
            Evaluation eval = new Evaluation(data);	
		eval.crossValidateModel(fc, data, 10, new Random(1));
            System.out.println(eval.toSummaryString());
            System.out.printf(" precision %4.3f recall %4.3f fMeasure:%4.3f\n", eval.precision(0), eval.recall(0), eval.fMeasure(0));
            System.out.printf(" precision %4.3f recall %4.3f fMeasure:%4.3f\n", eval.precision(1), eval.recall(1), eval.fMeasure(1));
            System.out.printf(" Accuracy rate %4.3f \n\n", (1-eval.errorRate()));
            System.out.println("Tree:" + j48.toString());
            trainingResult = 
                    String.format("%s\n", eval.toSummaryString())+
                    String.format(" precision %4.3f recall %4.3f fMeasure:%4.3f\n", eval.precision(0), eval.recall(0), eval.fMeasure(0))+
                    String.format(" precision %4.3f recall %4.3f fMeasure:%4.3f\n", eval.precision(1), eval.recall(1), eval.fMeasure(1))+
                    String.format(" Accuracy rate %4.3f \n\n", (1-eval.errorRate())) +
                    String.format("Tree:" + j48.toString());
            ///////////////////////////////////////////////////////////////////////
            System.out.println("persisting the model...");
            String model = dataset+"_dt.weka";
            Debug.saveToFile(model, j48);
            //predict..
            Instances tdata = loadInstances("./data/small.csv");
            System.out.println("retrieving the model and evaluation....");
            SerializedClassifier classifier = new SerializedClassifier();
            classifier.setModelFile(new File(model));
            eval = new Evaluation(tdata);	
		eval.crossValidateModel(classifier, tdata, 10, new Random(1));
            System.out.println(eval.toSummaryString());
            labels.clear();
            for(int i=0;i<tdata.classAttribute().numValues();i++){
                System.out.println("Values:" +  tdata.classAttribute().value(i));
                labels.add(tdata.classAttribute().value(i));
            }
            ///////////////////////////////////////////////////////////////////
            double[] arr = {113,324,1017,2.6,15,14,-67};
            Instance inst = getWekaInstance(arr);
            double v = j48.classifyInstance(inst);
            System.out.println("Prediction:" + inst.classAttribute().value((int) v));
            return j48;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return null;
    }
    public static String crossValidate(String dataset,String conf){
        String cv_results = "No Results...";
        try{
            config = new Config(conf);
            System.out.println("config:"+config);
            Instances data = loadInstances(dataset);
            //resample object.
            Resample resample = new Resample();
            resample.setInputFormat(data);
            j48 = new J48();
            setJ48(j48,config);
            j48.setConfidenceFactor(0.4f);
            j48.buildClassifier(data);
           
            //classifier filter
            FilteredClassifier fc = new FilteredClassifier();
            fc.setClassifier(j48);
            fc.setFilter(resample);
            
            Evaluation eval = new Evaluation(data);	
		eval.crossValidateModel(fc, data, 10, new Random(1));
            System.out.println(eval.toSummaryString());
            System.out.printf(" precision %4.3f recall %4.3f fMeasure:%4.3f\n", eval.precision(0), eval.recall(0), eval.fMeasure(0));
            System.out.printf(" precision %4.3f recall %4.3f fMeasure:%4.3f\n", eval.precision(1), eval.recall(1), eval.fMeasure(1));
            System.out.printf(" Accuracy rate %4.3f \n\n", (1-eval.errorRate()));
            System.out.println("Tree:" + j48.toString());
            cv_results = 
                    String.format("%s\n", eval.toSummaryString())+
                    String.format(" precision %4.3f recall %4.3f fMeasure:%4.3f\n", eval.precision(0), eval.recall(0), eval.fMeasure(0))+
                    String.format(" precision %4.3f recall %4.3f fMeasure:%4.3f\n", eval.precision(1), eval.recall(1), eval.fMeasure(1))+
                    String.format(" Accuracy rate %4.3f \n\n", (1-eval.errorRate())) +
                    String.format("Tree:" + j48.toString());
            ///////////////////////////////////////////////////////////////////////
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return cv_results;
    }
    public static String validate(Classifier classifier,String csv_testset){
        try{
        //////////////////////////////////////////
        Instances tdata = loadInstances(csv_testset);
        System.out.println("retrieving the model and evaluation....");
        Evaluation eval = new Evaluation(tdata);	
	eval.crossValidateModel(classifier, tdata, 10, new Random(1));
        System.out.println(eval.toSummaryString());
        return 
            String.format("%s\n", eval.toSummaryString())+
            String.format(" precision %4.3f recall %4.3f fMeasure:%4.3f\n", eval.precision(0), eval.recall(0), eval.fMeasure(0))+
            String.format(" precision %4.3f recall %4.3f fMeasure:%4.3f\n", eval.precision(1), eval.recall(1), eval.fMeasure(1))+
            String.format(" Accuracy rate %4.3f \n\n", (1-eval.errorRate())) ;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return "Error in validations";
    }
    
    public static Instance getWekaInstance(double[] arr){
        ArrayList<Attribute> attributes = new ArrayList();
        for(int i=0;i<arr.length;i++){
            attributes.add(new Attribute("attrib" + (i+1)));
        }  
        
        List<String> labels = new ArrayList();
        labels.add("Battery Alarm");
        labels.add("Hardware Alarm");
        labels.add("Normal");
        Attribute ca = new Attribute("class", labels);
        attributes.add(ca);
        
        Instances data  = new Instances("TestInstances", attributes, 0);
        //data.setClassIndex(data.numAttributes() - 1);
        Instance inst = new DenseInstance(arr.length);
        for(int i=0;i<arr.length;i++){
            inst.setValue(i, arr[i]);
        }
        data.add(inst);
        inst.setDataset(data);
        return inst;
    }
    public static void saveJ48Model(String path){
        
    }
}
