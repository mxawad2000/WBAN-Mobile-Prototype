package ae.ac.uaeu.annlearning;

import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.util.ArrayList;

import libsvm.svm;
import libsvm.svm_model;
import libsvm.svm_node;
import weka.classifiers.trees.J48;
import weka.core.Attribute;
import weka.core.Debug;
import weka.core.DenseInstance;
import weka.core.Instance;
import weka.core.Instances;

/**
 * Created by Mamoun.Awad on 6/3/2019.
 */

public class DTreeModel extends PredModel {
    private J48 smodel;
    public DTreeModel() { }
    public DTreeModel(String modelId, String fbKey, String date, String fn, String type, byte[] content) {
        this.modelId = modelId;
        this.fbKey = fbKey;
        this.date = date;
        setFileName(fn);
        this.binary = content;
        this.type = type;
    }
    double[] tmpArr;
    public int predict(float[] data){
        try {
            if(tmpArr == null) tmpArr = new double[data.length];
            GenUtil.float2double(data,tmpArr);
            Instance instance = getWekaInstance(tmpArr);
            //Log.i(MyApp.TAG,"weka instance:" + instance.toString());
            return (int) smodel.classifyInstance(instance);
        }catch(Exception ex){
            Log.e(MyApp.getLogTag(),ex.getMessage(),ex);
        }
        return -1;
    }

    public void setInterpreter() {
        if(smodel != null) return;
        try {
            File file = new File(MyApp.getAppContext().getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),
                    this.fileName);
            this.smodel = (J48) Debug.loadFromFile(file.getAbsolutePath());
        } catch (Exception ex) {
            Log.d(MyApp.TAG, "Exception:" + ex.getMessage());
        }
    }
    public String getPredLabel(int ind){
        return this.labels.get((ind+""));
    }
    private static Instances dataset;
    private static ArrayList<String> labelList = new ArrayList<>();
    private Instance getWekaInstance(double[] arr){
        if(dataset == null){
            ArrayList<Attribute> attributes = new ArrayList();
            for(int i=0;i<arr.length;i++){
                attributes.add(new Attribute("att" + (i + 1)) );
            }
            labelList.addAll(super.labels.values());
            //Log.i(MyApp.TAG,"list of labels:" + labelList);
            Attribute ca = new Attribute("class", labelList);
            attributes.add(ca);
            dataset  = new Instances("TestInstances", attributes, 0);
            dataset.setClassIndex(dataset.numAttributes() - 1);
        }
        Instance inst = new DenseInstance(arr.length);
        for(int i=0;i<arr.length;i++)inst.setValue(i, arr[i]);
        inst.setDataset(dataset);
        return inst;
    }
}
