package ae.ac.uaeu.annlearning;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.Manifest;
import android.widget.Toolbar;

import com.google.firebase.auth.FirebaseAuthException;

import java.util.HashMap;
import java.util.Map;
//https://stackoverflow.com/questions/45874245/keras-deep-learning-model-to-android
//https://omid.al/posts/2017-02-20-Tutorial-Build-Your-First-Tensorflow-Android-App/
//https://medium.com/@elye.project/applying-tensorflow-in-android-in-4-steps-to-recognize-superhero-f224597eb055

public class MainActivity extends AppCompatActivity {
    static final int SMS_SEND_REQ_CODE = 10;
    String SVM_MODEL_KY= "patient1/ft/svm/svm_model1";
    String ANN_MODEL_KY= "patient1/ft/ann/ann_model1";
    MainBroadcastReceiver receiver ;
    Handler timerHandler = new Handler();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.i(MyApp.TAG,"OnCreate..................");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActionBar actionBar = this.getSupportActionBar();
        if(actionBar != null)
            actionBar.setDisplayHomeAsUpEnabled(true);
        enableCheckButtons(false);
        //set the broadcast receiver object..
        this.receiver = new MainBroadcastReceiver();
        registerEvents();
        FaultDetector.getInstance().startFaultDetector();
        setDialog();
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////
    private void registerEvents(){
        this.registerReceiver(receiver, new IntentFilter(MainBroadcastReceiver.ACTION_DOWNLOAD));
        this.registerReceiver(receiver, new IntentFilter(MainBroadcastReceiver.ACTION_RETRIEVED));
        this.registerReceiver(receiver, new IntentFilter(MainBroadcastReceiver.ACTION_TRAFFIC_ARRIVED) );
        this.registerReceiver(receiver, new IntentFilter(MainBroadcastReceiver.ACTION_FAULT_DETECTED) );
        this.registerReceiver(receiver, new IntentFilter(MainBroadcastReceiver.ACTION_FAULT_SENSOR_DOWN) );
        this.registerReceiver(receiver, new IntentFilter(MainBroadcastReceiver.ACTION_FAULT_SENSOR_PROFILE_NOT_FOUND) );
        this.registerReceiver(receiver, new IntentFilter(MainBroadcastReceiver.ACTION_FAULT_PREDICTION_MODEL_NOT_FOUND) );
        this.registerReceiver(receiver, new IntentFilter(MainBroadcastReceiver.ACTION_SENSOR_PROFILES_DOWNLOAD_DONE) );
        this.registerReceiver(receiver, new IntentFilter(MainBroadcastReceiver.ACTION_FAULT_SENSOR_STUCK_AT_ZERO) );
        this.registerReceiver(receiver, new IntentFilter(MainBroadcastReceiver.ACTION_FAULT_SENSOR_SPIKE) );
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    private void checkPermission(){
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                final String[] PERMISSIONS = {Manifest.permission.SEND_SMS};
                ActivityCompat.requestPermissions(this, PERMISSIONS, SMS_SEND_REQ_CODE);
        }else{
            MyApp.addPermission(Manifest.permission.SEND_SMS);
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Log.i("sms","SMS Granting results...");
        switch (requestCode) {
            case SMS_SEND_REQ_CODE: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    MyApp.addPermission(Manifest.permission.SEND_SMS);
                } else {
                    Log.i("sms", "SEND_SMS was not granted...");
                }
                return;
            }
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    protected void onStart(){
        Log.i(MyApp.TAG,"onStart....");
        super.onStart();
        checkPermission();
        //this.startTimer();
    }
    @Override
    protected void onStop(){
        super.onStop();
        Log.i(MyApp.TAG,"onStop.............");
        FaultAlertNotifier.getInstance().stopAlarm();
    }
    @Override
    protected void onPause(){
        super.onPause();
        FaultAlertNotifier.getInstance().stopAlarm();
        unregisterReceiver(receiver);
    }
    @Override
    protected void onResume(){
        super.onResume();
        registerEvents();
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////
    public void handle(View view) {
        PredModel model = null;
        int ann_res =-1;
        int svm_res = -1;
        boolean is_download =false;
        String predLabel = "";
        int id = view.getId();
        EditText et = findViewById(R.id.et_data);
        String[] v = et.getText().toString().split(",");
        float[] data = new float[v.length];
        for(int i=0;i<v.length;i++) data[i] = Float.parseFloat(v[i]);
        ////////////////////////////////////////////////////////////////////////////////////////////
        EditText et2 = findViewById(R.id.et_model);
        String k= et2.getText().toString();
        //Log.i(MyApp.TAG,"key is empty:" + k.isEmpty() + "-->" + k);
        ////////////////////////////////////////////////////////////////////////////////////////////
        if(id == R.id.bt_ann){
            model = AppManager.getInstance().getModel(ANN_MODEL_KY);
            ann_res = model.predict(data);
            predLabel = model.getPredLabel( ann_res);
        }else if(id == R.id.bt_svm){
            model = AppManager.getInstance().getModel(SVM_MODEL_KY);
            svm_res =model.predict(data);
            predLabel = model.getPredLabel(svm_res);
        }else if(id == R.id.bt_download){
            is_download = true;
            if(k.isEmpty()){
                //Log.i(MyApp.TAG,"key is empty...");
                String[] keys = GenUtil.getModelKeys();
                for(String key : keys) AppManager.getInstance().readModel(key);
            }else{
                AppManager.getInstance().readModel(k);
            }

        }
        TextView tv = findViewById(R.id.tv_results);
        if(ann_res != -1){
            tv.setText("ANN predicts:" + ann_res + "-->" + predLabel);
        }else if(svm_res != -1){
            tv.setText("SVM predicts:" + svm_res +"-->" + predLabel);
        }else{
            tv.setText("Download Models requires restart to upload the new models.");
        }
    }
    private void enableCheckButtons(boolean flag){
        int[] ids = {R.id.bt_ann,R.id.bt_svm};
        for(int id : ids){
            Button b = (Button) findViewById(id);
            b.setEnabled(flag);
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    private boolean isCheckOn = false;
    public void handleCheckData(View view) {
        isCheckOn = !isCheckOn;
        View v = findViewById(R.id.lo_chk_traffic);
        if(isCheckOn) {
            v.setVisibility(View.VISIBLE);
            isDownloadOn = false;
            findViewById(R.id.lo_download2).setVisibility(View.GONE);
        }
        else v.setVisibility(View.GONE);
    }
    private boolean isDownloadOn = false;
    public void handleDownload(View view) {
        isDownloadOn = !isDownloadOn;
        View v = findViewById(R.id.lo_download2);
        if(isDownloadOn) {
            v.setVisibility(View.VISIBLE);
            isCheckOn = false;
            findViewById(R.id.lo_chk_traffic).setVisibility(View.GONE);
        }
        else v.setVisibility(View.GONE);
    }
    //int dummy = 0;
    //int dummy2 = 0;
    //int dummy3= 0;
    //int dummy4 = 0;
    ////////////////////////////////////////////////////////////////////////////////////////////////
    public class MainBroadcastReceiver extends BroadcastReceiver {
        public static final String ACTION_DOWNLOAD = "ae.ac.uaeu.ACTION_DOWNLOAD";
        public static final String ACTION_RETRIEVED = "ae.ac.uaeu.ACTION_RETRIEVED";
        public static final String ACTION_FAILED = "ae.ac.uaeu.ACTION_FAILED";
        public static final String ACTION_TRAFFIC_ARRIVED = "ae.ac.uaeu.ACTION_traffic_arrived";
        public static final String ACTION_FAULT_DETECTED="ae.ac.uaeu.ACTION_fault_detected";
        public static final String ACTION_FAULT_SENSOR_DOWN="ae.ac.uaeu.ACTION_Sensor_down";
        public static final String ACTION_FAULT_SENSOR_PROFILE_NOT_FOUND="ae.ac.uaeu.ACTION_Sensor_down_profile_not_found";
        public static final String ACTION_FAULT_PREDICTION_MODEL_NOT_FOUND="ae.ac.uaeu.ACTION_PREDICITON_MODEL_NOT_FOUND";
        public static final String ACTION_SENSOR_PROFILES_DOWNLOAD_DONE="ae.ac.uaeu.ACTION_profiles_download_done";
        public static final String ACTION_FAULT_SENSOR_STUCK_AT_ZERO="ae.ac.uaeu.ACTION_sensor_stuck_at_zero";
        public static final String ACTION_FAULT_SENSOR_SPIKE="ae.ac.uaeu.ACTION_sensor_spike_value";
        Map<String,Integer> countMap  = new HashMap();
        int MAX_ALERT = 2;
        private boolean checkKey(String key,String sensorID){
            key = key + "-" + sensorID;
            int v = 0;
            if(countMap.containsKey(key)){
                v = countMap.get(key);
            }
            countMap.put(key,v+1);
            if(v >= MAX_ALERT) return false;
            return true;
        }
        @Override
        public void onReceive(Context context, Intent intent) {
            if(intent.getAction() == ACTION_RETRIEVED) {
                //Log.i(MyApp.TAG, "keys were retrieved....");
                Toast.makeText(MainActivity.this,"Retrieving models..",Toast.LENGTH_SHORT).show();
                enableCheckButtons(true);
            }else if(intent.getAction() == ACTION_DOWNLOAD){
                Log.i(MyApp.TAG,"keys were downloaded from FB");
                Toast.makeText(MainActivity.this,"Models were downloaded successfully...",Toast.LENGTH_SHORT).show();
                enableCheckButtons(true);
            }else if(intent.getAction() == ACTION_FAILED){
                Log.i(MyApp.TAG,"Failed to download");
                Toast.makeText(MainActivity.this,"Failed to find/download models, check WIFI",Toast.LENGTH_SHORT).show();
                enableCheckButtons(false);
            }else if(intent.getAction() == ACTION_TRAFFIC_ARRIVED){
                Log.i(MyApp.TAG,"Traffic was read.. starting the Simulation");
                //you can start the FaultDetector thread
            }else if(intent.getAction() == ACTION_FAULT_DETECTED){
                String model_id = intent.getStringExtra("model_id");
                String fault = intent.getStringExtra("fault");
                String pkt = intent.getStringExtra("pkt");
                String sensorID= intent.getStringExtra("sensor_id");
                String output = "sensor id:" + sensorID + " model:" + model_id + "---->" + fault;
                updateTrafficInfo(pkt,MyApp.randObj.nextInt(100),MyApp.randObj.nextInt(120),77,output);
                builder.setMessage(output);
                if(checkKey(ACTION_FAULT_DETECTED,sensorID)) {
                    FaultAlertNotifier.getInstance().sendSMS(output,sensorID);
                    builder.show();
                }
            }else if(intent.getAction() == ACTION_FAULT_SENSOR_DOWN){
                String duration = intent.getStringExtra("duration");
                String sensorID= intent.getStringExtra("sensor_id");
                String output = "sensor id:" + sensorID + " is DOWN for " + duration + " seconds";
                updateTrafficInfo("",89,88,77,output);
                Log.i(MyApp.TAG, output);
                builder.setMessage(output);
                //builder.show();
                if(checkKey(ACTION_FAULT_SENSOR_DOWN,sensorID)){
                    FaultAlertNotifier.getInstance().sendSMS(output,sensorID);
                    builder.show();
                }
            }else if(intent.getAction() == ACTION_FAULT_SENSOR_PROFILE_NOT_FOUND){
                String profile = intent.getStringExtra("profile");
                String output = "sensor profile:" + profile + " was not found";
                builder.setMessage(output);
                //builder.show();
                if(checkKey(ACTION_FAULT_SENSOR_PROFILE_NOT_FOUND, profile)){
                    FaultAlertNotifier.getInstance().sendSMS(output,profile);
                    builder.show();
                }
            }else if(intent.getAction() == ACTION_FAULT_PREDICTION_MODEL_NOT_FOUND){
                String model = intent.getStringExtra("model");
                String output = "Prediction Model:" + model + " was not found";
                builder.setMessage(output);
                if(checkKey(ACTION_FAULT_PREDICTION_MODEL_NOT_FOUND, "")){
                    FaultAlertNotifier.getInstance().sendSMS(output,model);
                    builder.show();
                }
            }else if(intent.getAction() == ACTION_SENSOR_PROFILES_DOWNLOAD_DONE){
                String output = "Profile Download is Done";
                builder.setMessage(output);
                builder.show();
            }else if(intent.getAction() == ACTION_FAULT_SENSOR_STUCK_AT_ZERO){
                String sensorID = intent.getStringExtra("profile");
                String output = "sensor:" + sensorID + " Stuck at Zero";
                builder.setMessage(output);
                builder.show();
            }else if(intent.getAction() == ACTION_FAULT_SENSOR_SPIKE){
                String sensorID = intent.getStringExtra("profile");
                String output = "sensor:" + sensorID + " spiked...";
                builder.setMessage(output);
                builder.show();
            }

        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    private void updateTrafficInfo(String packet, int temp, int pressure, int heart, String trafficCat){
        TextView tv = (TextView) findViewById(R.id.tv_temp);
        tv.setText(temp+"");
        tv = (TextView) findViewById(R.id.tv_blood_pressure);
        tv.setText(pressure+"");
        tv = (TextView) findViewById(R.id.tv_heart_beat);
        tv.setText(heart+"");
        tv = (TextView) findViewById(R.id.tv_monitor);
        tv.setText(trafficCat+"");
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    AlertDialog.Builder builder;
    private void setDialog(){
        this.builder = new AlertDialog.Builder(this);
        builder.setMessage("Sensor Down Fault");
        builder.setPositiveButton("OK", dialogClickListener);
        //builder.setNegativeButton(“no”, dialogClickListener);
    }
    DialogInterface.OnClickListener dialogClickListener =
            new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Log.i(MyApp.TAG,"onClick DialogInterface...");
                switch (which){
                    case DialogInterface.BUTTON_POSITIVE: //Yes, Button clicked
                        FaultAlertNotifier.getInstance().stopAlarm();
                     break;
                case DialogInterface.BUTTON_NEGATIVE://No button clicked
                    break;
                }
            }};
     ////////////////////////////////////////////////////////////////////////////////////////////////
    //Menu items...
    private Menu menu;
     @Override
     public boolean onCreateOptionsMenu(Menu menu) {
         MenuInflater inflater = getMenuInflater();
         inflater.inflate(R.menu.menu_main,menu);
         return true;
     }
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == R.id.mi_dwn_profile) {
            Thread t = new Thread(){
                public void run(){
                    AppManager.getInstance().downloadSensorProfiles();
                }
            };
            t.start();
            return true;
        }else if (id == R.id.mi_dwn_models) {
            Thread t = new Thread(){
                public void run(){
                    AppManager.getInstance().downloadKeys();
                }
            };
            t.start();
            return true;
        }else if(id == R.id.mi_start_stop_fault_detector){
            if(item.getTitle().toString().contains("Stop")){
                item.setTitle("Start Fault Detector");
                FaultDetector.getInstance().stopFaultDetector();
            }else{
                item.setTitle("Stop Fault Detector");
                FaultDetector.getInstance().startFaultDetector();
            }

        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public boolean onSupportNavigateUp(){
         //clean up...
         finish();
         return true;
     }


}
