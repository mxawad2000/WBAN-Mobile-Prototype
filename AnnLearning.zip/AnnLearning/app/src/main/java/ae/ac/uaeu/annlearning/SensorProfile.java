package ae.ac.uaeu.annlearning;

import java.io.Serializable;

/**
 * Created by Mamoun.Awad on 9/18/2019.
 */

public class SensorProfile implements Serializable {
    public static final long serialVersionUID = 123L;
    String sensorId;
    String type;
    float minValue =0;
    float maxValue =0;
    String description;
    String model;
    String serialNo;
    float ft_dead_th =3; //how long to decide sensor is dead in seconds.
    float ft_spike_th = 3;  // how long to warn against spike: 3 consecutive spiked values
    float ft_stuck_th = 3;// how long to warn against stuck to zero - 3 consecutive zero values
    float ft_battery_th=3;// how long to warn against low battery, 3 consecutive zero values
    float ft_hardware_th=3;// how long to warn against hardware fault - 3 consecutive zero values
    public SensorProfile(){}

    public String getSensorId() {
        return sensorId;
    }

    public String getType() {
        return type;
    }

    public float getMinValue() {
        return minValue;
    }

    public float getMaxValue() {
        return maxValue;
    }

    public String getDescription() {
        return description;
    }

    public String getModel() {
        return model;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public float getFt_dead_th() {
        return ft_dead_th;
    }

    public float getFt_spike_th() {
        return ft_spike_th;
    }

    public float getFt_stuck_th() {
        return ft_stuck_th;
    }

    public void setSensorId(String sensorId) {
        this.sensorId = sensorId;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setMinValue(float minValue) {
        this.minValue = minValue;
    }

    public void setMaxValue(float maxValue) {
        this.maxValue = maxValue;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public void setFt_dead_th(float ft_dead_th) {
        this.ft_dead_th = ft_dead_th;
    }

    public void setFt_spike_th(float ft_spike_th) {
        this.ft_spike_th = ft_spike_th;
    }

    public void setFt_stuck_th(float ft_stuck_th) {
        this.ft_stuck_th = ft_stuck_th;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SensorProfile that = (SensorProfile) o;

        return sensorId != null ? sensorId.equals(that.sensorId) : that.sensorId == null;
    }

    @Override
    public int hashCode() {
        return sensorId != null ? sensorId.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "SensorProfile{" +
                "sensorId='" + sensorId + '\'' +
                ", type='" + type + '\'' +
                ", minValue=" + minValue +
                ", maxValue=" + maxValue +
                ", description='" + description + '\'' +
                ", model='" + model + '\'' +
                ", serialNo='" + serialNo + '\'' +
                ", ft_dead_th=" + ft_dead_th +
                ", ft_spike_th=" + ft_spike_th +
                ", ft_stuck_th=" + ft_stuck_th +
                '}';
    }

    public float getFt_battery_th() {
        return ft_battery_th;
    }

    public float getFt_hardware_th() {
        return ft_hardware_th;
    }

    public void setFt_battery_th(float ft_battery_th) {
        this.ft_battery_th = ft_battery_th;
    }

    public void setFt_hardware_th(float ft_hardware_th) {
        this.ft_hardware_th = ft_hardware_th;
    }
}
