package ae.ac.uaeu.annlearning;

import android.util.Log;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by Mamoun.Awad on 6/3/2019.
 */

abstract public class PredModel {
    public String modelId;
    public String fbKey;
    protected String fileName;
    public String type;
    public byte[] binary;
    public String date;
    Map<String,String> labels = new HashMap();
    public PredModel(){}
    public void setFileName(String fn){
        this.fileName = fn.replace("/","_");
    }

    @Override
    public String toString() {
        return "PredModel{" +
                "modelId='" + modelId + '\'' +
                ", fbKey='" + fbKey + '\'' +
                ", fileName='" + fileName + '\'' +
                ", type='" + type + '\'' +
                ", binary=" + Arrays.toString(binary) +
                ", date='" + date + '\'' +
                '}';
    }
    //labels are in the form of key:value
    public void setLabels(String labels){
        String[] elems = labels.trim().split(",");
        for(String elem : elems){
            String[] kv = elem.split(":");
            this.labels.put(kv[0],kv[1]);
        }
        Log.i(MyApp.TAG,"Labels:" + labels);
    }
    public String labels2String(){
        Iterator<String> keys =this.labels.keySet().iterator();
        String labStr = "";
        while(keys.hasNext()){
            String k = keys.next();
            String v  = labels.get(k);
            labStr += k + ":" + v + ",";
        }
        return labStr.substring(0,labStr.length()-1);
    }
    public abstract String getPredLabel(int index);
    public abstract void setInterpreter();
    public abstract int predict(float[] vec);
}
