package ae.ac.uaeu.annlearning;

import android.*;
import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.telephony.SmsManager;
import android.util.Log;

import com.google.firebase.auth.FirebaseAuthException;

/**
 * Created by Mamoun.Awad on 9/11/2019.
 */

public class FaultAlertNotifier {
    private static FaultAlertNotifier instance = new FaultAlertNotifier();
    private String SENT = "SMS_SENT";
    static final String TAG = "sms";
    private String phone = "00971559372354";
    MediaPlayer mediaPlayer ;
    private FaultAlertNotifier() {
        MyApp.getAppContext().registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context arg0, Intent arg1) {
                int resultCode = getResultCode();
                if(Activity.RESULT_OK == resultCode) {
                    Log.i(MyApp.TAG, "SMS sent");
                }else{
                    //to do resend again...
                }
            }
        }, new IntentFilter(SENT));
    }

    public static FaultAlertNotifier getInstance() {
        return instance;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////


    public void sendSMS(final String msg, final String sensorID) {
        if(!MyApp.hasPermission(Manifest.permission.SEND_SMS)) return;
        Log.i(MyApp.TAG,"permission is there, sending...");
        Thread t = new Thread() {
            public void run() {
                try {
                    playAlarm();
                    PendingIntent sentPI = PendingIntent.getBroadcast(MyApp.getAppContext(),
                            0, new Intent(SENT), 0);
                    SmsManager smsMgr = SmsManager.getDefault();
                    smsMgr.sendTextMessage(phone, null,
                            "Alert Msg:" + msg + " sensor id:" + sensorID ,
                            sentPI, null);
                } catch (Exception e) {
                    Log.e(MyApp.TAG,e.getMessage(),e);
                }
            }
        };
        t.start();
    }
    public void playAlarm(){
        try {
            Uri myUri = Uri.parse(String.format("android.resource://%s/%s",
                    MyApp.getAppContext().getPackageName(), R.raw.alarm));
            if(mediaPlayer != null) {
                //if(mediaPlayer.isPlaying()) mediaPlayer.stop();
                mediaPlayer.release();
            }
            mediaPlayer = new MyMediaPlayer(3);
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    MyMediaPlayer mmp = (MyMediaPlayer)mediaPlayer;
                    mmp.count++;
                    if(!mmp.isDone()){
                        mmp.seekTo(0);
                        mmp.start();
                    }
                }
            });
            mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mediaPlayer.setDataSource(MyApp.getAppContext(), myUri);
            //mediaPlayer.setLooping(true);
            mediaPlayer.prepare();
            mediaPlayer.start();
        }catch(Exception ex){
            Log.e(MyApp.TAG,ex.getMessage(),ex);
        }
    }
    public void stopAlarm(){
        if(mediaPlayer != null){
            //mediaPlayer.setLooping(false);
            mediaPlayer.release();
        }
    }

// For receiving sms

    class SMSReceiver extends BroadcastReceiver {
        private static final String ACTION = "android.provider.Telephony.SMS_RECEIVED";

        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null && intent.getAction() != null && ACTION.compareToIgnoreCase(intent.getAction()) == 0) {
                // Sms Received Your code here
                Log.i(MyApp.TAG,"received code:SMS was received.....");
            }
        }
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////
class MyMediaPlayer extends MediaPlayer {
    int count =0;
    int maxLoop = 3;
    public MyMediaPlayer(){
        super();
    }
    public MyMediaPlayer(int maxLoop){
        super();
        this.maxLoop = maxLoop;
    }
    public boolean isDone(){ return count == maxLoop;}
}