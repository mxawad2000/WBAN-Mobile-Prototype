package ae.ac.uaeu.annlearning;

import android.content.Intent;
import android.util.Log;

import com.google.firebase.FirebaseApp;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by Mamoun.Awad on 9/4/2019.
 */

public class FaultDetector {
    private static FaultDetector instance = new FaultDetector();
    private FaultDetector(){
        Log.i(MyApp.TAG,"in Fautl Detecter check...");
        String[] profiles = MyApp.getSensorProfiles();
        for(int i=0;i<MyApp.getNumSensors();i++){
            String k = profiles[i];
            hb_dict.put(k, System.currentTimeMillis());
            fc_dict.put(k, 0);
        }
        hb_dict.put("4",System.currentTimeMillis()); //to check..
        fc_dict.put("4",0);
        //testAccuracy();

    }
    private void testAccuracy() {
        try {
            Thread.sleep(2000);
        } catch (Exception ex) {
        }
        NetworkSimulator sim = NetworkSimulator.getInstance();
        for (TrafficEntry entry : sim.traffic) {
            testPrediction(entry);
            if (count % 1000 == 0)
                Log.i(MyApp.TAG, String.format("prediction accuracy svm:%f/%f=%f ann:%f/%f=%f, dt: %f/%f=%f", svm_acc, count, svm_acc / count,
                        ann_acc, count, ann_acc / count, dt_acc, count, dt_acc / count));
        }
        Log.i(MyApp.TAG, String.format("prediction accuracy svm:%f/%f=%f ann:%f/%f=%f, dt: %f/%f=%f", svm_acc, count, svm_acc / count,
                ann_acc, count, ann_acc / count, dt_acc, count, dt_acc / count));
    }
    public static FaultDetector getInstance(){ return instance;}
    ////////////////////////////////////////////////////////////////////////////////////////////////
    private Map<String,Integer> fc_dict = new HashMap<>(); //fault tolerance dictionary
    private Map<String,Long> hb_dict = new HashMap<>(); // heart beat dictionary.
    private Map<String,Integer> stuck_dict = new HashMap<>(); //stuck_at zero fault...
    private Map<String,Integer> spike_dict =new HashMap<>();//spike reading > max normal reading..

    double svm_acc = 0,ann_acc=0,dt_acc=0,count=0;
    private void testPrediction(TrafficEntry pkt) {
        count++;
        for (String modelID : GenUtil.getModelKeys()) {
            PredModel model = AppManager.getInstance().getModel(modelID);
            if (model != null) {
                int res = model.predict(pkt.entry);
                String predLabel = model.getPredLabel(res);
                //if(predLabel == null) Log.i(MyApp.TAG,"null label for pred:" + res+ " model:" + model.type + " name:" + model.fileName);
                if (predLabel.equals(pkt.target)) {
                    if (model.type.equals("svm")) svm_acc++;
                    else if (model.type.equals("ann")) ann_acc++;
                    else if (model.type.equals("dt")) dt_acc++;
                }
            }
        }
    }
    private void predictFaults(TrafficEntry pkt){
        //TrafficEntry pkt = NetworkSimulator.getInstance().getRandomEntry();
        //hb_dict.put(pkt.sensorID,System.currentTimeMillis());
        //Log.i(MyApp.TAG, "FaultDetector: receiving Traffic:" + pkt);
        //String categ = "";
        count++;
        for(String modelID : GenUtil.getModelKeys()){
            PredModel model = AppManager.getInstance().getModel(modelID);
            if (model != null) {
                int res = model.predict(pkt.entry);
                String predLabel = model.getPredLabel(res);
                //Log.i(MyApp.TAG, "Model:" + model.modelId + " Predicted:" + predLabel + "---> Correct one:" + pkt.target);
                if(predLabel.equals(pkt.target)){
                    if(model.type.equals("svm")) svm_acc++;
                    else if (model.type.equals("ann")) ann_acc++;
                    else if (model.type.equals("dt")) dt_acc++;
                }
                if(!predLabel.toLowerCase().equals("normal")) {
                    Log.i(MyApp.TAG,"Broadcasting fault:" + predLabel);
                    SensorProfile profile  = AppManager.getInstance().getSensorProfile(pkt.sensorID);
                    float threshold = 0;
                    if(predLabel.equalsIgnoreCase("hardware alarm")){
                        threshold = profile.getFt_hardware_th();
                        Log.i(MyApp.TAG,"Dead Threshold for sensor:" + pkt.sensorID + " -hardware is " + threshold);
                    }else if(predLabel.equalsIgnoreCase("battery alarm")){
                        threshold = profile.getFt_battery_th();
                        Log.i(MyApp.TAG,"Dead Threshold for sensor:" + pkt.sensorID + " -battery is " + threshold);
                    }
                    if(this.fc_dict.get(pkt.sensorID) > threshold) { //threshold is 3
                        Intent intent = new Intent();
                        intent.setAction(MainActivity.MainBroadcastReceiver.ACTION_FAULT_DETECTED);
                        intent.putExtra("model_id", model.modelId);
                        intent.putExtra("fault", predLabel);
                        intent.putExtra("pkt", Arrays.toString(pkt.entry));
                        intent.putExtra("sensor_id", pkt.sensorID);
                        MyApp.getAppContext().sendBroadcast(intent);
                        this.fc_dict.put(pkt.sensorID,0);//reset the count...
                    }else{
                        int count  = this.fc_dict.get(pkt.sensorID) + 1;
                        this.fc_dict.put(pkt.sensorID,count);
                    }
                }
            }
        }
    }
    private void analyze(){
        TrafficEntry pkt = NetworkSimulator.getInstance().getRandomEntry();
        hb_dict.put(pkt.sensorID,System.currentTimeMillis());
        Log.i(MyApp.TAG, "FaultDetector: receiving Traffic:" + pkt);
        String sensorID = pkt.sensorID;
        SensorProfile profile = AppManager.getInstance().getSensorProfile(sensorID);
        if(profile != null){
            //check for stuck at zero
            if(pkt.getBioReading() != 0) this.stuck_dict.put(sensorID,0);
            else incrementDict(stuck_dict,sensorID);
            //check threshold...
            if(stuck_dict.get(sensorID) >= profile.getFt_stuck_th()){
                Map<String,String> data = new HashMap();
                data.put("profile", sensorID);
                sendAlert(MainActivity.MainBroadcastReceiver.ACTION_FAULT_SENSOR_STUCK_AT_ZERO,data);
                return;
            }
            //check against spiked value..
            if(pkt.getBioReading() < profile.getMaxValue()) this.spike_dict.put(sensorID,0);
            else incrementDict(spike_dict,sensorID);
            //check threshold...
            if(spike_dict.get(sensorID) >= profile.getMaxValue()){
                Map<String,String> data = new HashMap();
                data.put("profile", sensorID);
                sendAlert(MainActivity.MainBroadcastReceiver.ACTION_FAULT_SENSOR_SPIKE,data);
                return;
            }
            //check against prediction models....
            predictFaults(pkt);
        }else{
            Log.i(MyApp.TAG,"Profile of Sensor:" + sensorID + " was not found...");
            Map<String,String> data = new HashMap();
            data.put("profile", sensorID);
            sendAlert(MainActivity.MainBroadcastReceiver.ACTION_FAULT_SENSOR_PROFILE_NOT_FOUND,data);
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    private void sendAlert(String alertType, Map<String,String> data){
        Intent intent = new Intent();
        intent.setAction(alertType);
        Iterator<String> iter = data.keySet().iterator();
        while(iter.hasNext()) {
            String name = iter.next();
            intent.putExtra(name, data.get(name));
        }
        MyApp.getAppContext().sendBroadcast(intent);
    }
    private void incrementDict(Map<String,Integer> map,String key){
        int v = 0;
        if(map.containsKey(key)){
            v =map.get(key);
        }
        map.put(key,v+1);
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    private void checkDownFailure(){
        Iterator<String> iter = hb_dict.keySet().iterator();
        while(iter.hasNext()){
            String key = iter.next();
            double seconds = (System.currentTimeMillis() - hb_dict.get(key) ) / 1000.0;
            SensorProfile profile = AppManager.getInstance().getSensorProfile(key);
            if(profile == null){
                Log.i(MyApp.TAG,"null profile for " + key);
                //sendBroadcast for this matter. ///////////////////////////////////////////////////
                return;
            }
            Log.i(MyApp.TAG,"Dead Threshold for sensor:" + key + " is " + profile.getFt_dead_th());
            if(seconds >  profile.getFt_dead_th() ){

                Intent intent = new Intent();
                intent.setAction(MainActivity.MainBroadcastReceiver.ACTION_FAULT_SENSOR_DOWN);
                intent.putExtra("sensor_id",key);
                intent.putExtra("duration",seconds + "");
                MyApp.getAppContext().sendBroadcast(intent);
            }
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * in case we want to reset heart beat (last packet arrival time) for each sensor.
     */
    public void resetDownFailure(){
        String[] profiles = MyApp.getSensorProfiles();
        for(int i=1;i<=MyApp.getNumSensors();i++){
            String k = profiles[i];
            hb_dict.put(k, System.currentTimeMillis());
            fc_dict.put(k,0);
        }
        hb_dict.put("4",System.currentTimeMillis()); //to check..
        fc_dict.put("4",0);
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////
    private boolean isDone = false;
    Timer timer = new Timer();
    Timer hbTimer = new Timer();
    public void startFaultDetector(){
        timer =new Timer();
        timer.scheduleAtFixedRate(new DetectionTask(),5000,3000);
        hbTimer = new Timer();
        hbTimer.scheduleAtFixedRate(new SensorDownTask(),6000,3000);
    }
    public void stopFaultDetector(){
        timer.cancel();
        hbTimer.cancel();
    }
    class DetectionTask extends TimerTask {
            @Override
            public void run() {
                Log.i(MyApp.TAG,"timer started at:" + System.currentTimeMillis());
                analyze();
            }
    }
    class SensorDownTask extends TimerTask {
        @Override
        public void run() {
            Log.i(MyApp.TAG,"timer started at:" + System.currentTimeMillis());
            checkDownFailure();
        }

    }
}
