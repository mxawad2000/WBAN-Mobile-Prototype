package ae.ac.uaeu.annlearning;

import android.content.Context;
import android.content.res.AssetManager;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Mamoun.Awad on 8/26/2019.
 */

public class GenUtil {
    /**
     * check if the WIFI adapter is on or off.
     * @return
     */
    public static boolean checkWifiConnection(){
        Context context = MyApp.getAppContext();
        WifiManager mgr = (WifiManager)
                MyApp.getAppContext().getSystemService(Context.WIFI_SERVICE);
        if(mgr.isWifiEnabled()){
            WifiInfo info = mgr.getConnectionInfo();
            if( info.getNetworkId() == -1 ){
                return false; // Not connected to an access point
            }
            return true;
        }
        return false;
    }

    /**
     *
     * @return
     */
    public static String[] getModelKeys(){
        try{
            List<String> keys = new ArrayList();
            AssetManager mgr = MyApp.getAppContext().getAssets();
            InputStream is = mgr.open("models.txt");
            BufferedReader reader = new BufferedReader( new InputStreamReader(is));
            String key = null;
            while( (key = reader.readLine()) != null){
                if(key.startsWith("#") || key.trim().isEmpty()) continue;
                keys.add(key);
            }
            return keys.toArray(new String[0]);
        }catch(Exception ex){
            Log.e(MyApp.TAG,"Error reading file models.txt",ex);
        }
        return new String[0];
    }

    public static String[] getSensorsIDs(){
        try{
            List<String> keys = new ArrayList();
            AssetManager mgr = MyApp.getAppContext().getAssets();
            InputStream is = mgr.open("sensors.txt");
            BufferedReader reader = new BufferedReader( new InputStreamReader(is));
            String key = null;
            while( (key = reader.readLine()) != null){
                if(key.startsWith("#") || key.trim().isEmpty()) continue;
                keys.add(key);
            }
            return keys.toArray(new String[0]);
        }catch(Exception ex){
            Log.e(MyApp.TAG,"Error reading file sensors.txt",ex);
        }
        return new String[0];
    }

    public static List<TrafficEntry> getTraffic(){
        List<TrafficEntry> keys = new ArrayList();
        try{
            AssetManager mgr = MyApp.getAppContext().getAssets();
            InputStream is = mgr.open("test.txt");
            BufferedReader reader = new BufferedReader( new InputStreamReader(is));
            String key = null;
            String[] sensorIDs = getSensorsIDs();
            while( (key = reader.readLine()) != null){
                if(key.startsWith("#") || key.trim().isEmpty()) continue;
                TrafficEntry entry = line2TrafficEntry( key );
                entry.sensorID =  sensorIDs [MyApp.randObj.nextInt(MyApp.getNumSensors() )];
                //Log.i(MyApp.TAG,"sensor id:" + entry.sensorID);
                keys.add(entry);
            }
        }catch(Exception ex){
            Log.e(MyApp.TAG,"Error reading file models.txt",ex);
        }
        return keys;
    }
    public static TrafficEntry line2TrafficEntry(String value){
        String[] sValues = value.split(",");
        float[] data = new float[sValues.length -1 ];
        String target = sValues[ sValues.length - 1];
        for(int i=0;i<data.length;i++) data[i] = Float.parseFloat(sValues[i]);
        return new TrafficEntry(data,target);
    }

    public static double[] float2double(float[] arr){
        double[] darr = new double[arr.length];
        for(int i=0;i<arr.length;i++) darr[i] = arr[i];
        return darr;
    }
    public static void float2double(float[] src, double[] dest){
        for(int i=0;i<src.length;i++) dest[i] = src[i];
    }
}
