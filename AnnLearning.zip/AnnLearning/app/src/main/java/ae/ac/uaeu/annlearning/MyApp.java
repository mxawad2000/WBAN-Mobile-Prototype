package ae.ac.uaeu.annlearning;

/**
 * Created by Mamoun.Awad on 6/3/2019.
 */

import android.app.Application;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/**
 * Created by Mamoun.Awad on 12/17/2018.
 */

public class MyApp extends Application
{
    static Set<String> permissions = new HashSet();
    static Random randObj = new Random(System.currentTimeMillis());
    static String[] sensorProfiles = new String[0];
    public static final String TAG = "ann_app";
    private static Context context;
    public void onCreate() {
        super.onCreate();
        MyApp.context = getApplicationContext();
        sensorProfiles = GenUtil.getSensorsIDs();
        NetworkSimulator.getInstance();
        AppManager.getInstance();
    }
    public static Context getAppContext() {    return MyApp.context;  }
    public static String getLogTag(){return TAG;}
    public static int getNumSensors(){ return sensorProfiles.length; }
    public static boolean hasPermission(String code){ return permissions.contains(code); }
    public static void addPermission(String code){ permissions.add(code);}
    public static String[] getSensorProfiles(){
        return sensorProfiles;
    }

    /*
    public static int getDeviceWidth(){
        return Resources.getSystem().getDisplayMetrics().widthPixels;
    }
    public static int getDeviceHeight(){
        return Resources.getSystem().getDisplayMetrics().heightPixels;
    }
    public static int dp2px(int dp){
        return Math.round ( Resources.getSystem().getDisplayMetrics().density * dp);
    }
    public static int px2dp(int px){
        return Math.round ( px / Resources.getSystem().getDisplayMetrics().density);
    }
    public static SharedPreferences getSharedPreferences(){
        return context.getSharedPreferences(TAG,Context.MODE_PRIVATE);
    }
    public static  Random getRandom(){ return randObj;}
    public static boolean isTablet() {
        return (context.getResources().getConfiguration().screenLayout
                & Configuration.SCREENLAYOUT_SIZE_MASK)
                >= Configuration.SCREENLAYOUT_SIZE_LARGE;
    }
    */
}


