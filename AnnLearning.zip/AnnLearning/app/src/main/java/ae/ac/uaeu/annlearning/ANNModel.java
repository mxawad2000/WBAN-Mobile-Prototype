package ae.ac.uaeu.annlearning;

import android.os.Environment;
import android.util.Log;

import org.tensorflow.lite.Interpreter;

import java.io.File;
import java.io.FileInputStream;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Arrays;

/**
 * Created by Mamoun.Awad on 6/3/2019.
 */

public class ANNModel extends PredModel {
    Interpreter interpreter;
    static {
        System.loadLibrary("tensorflow_inference");
    }

    public ANNModel() { }
    public ANNModel(String modelId, String fbKey, String date, String fn,String type, byte[] content) {
        this.modelId = modelId;
        this.fbKey = fbKey;
        this.date = date;
        setFileName(fn);
        this.binary = content;
        this.type = type;
    }

    public void setInterpreter() {
        if(interpreter != null) return;
        try {
            File file = new File(MyApp.getAppContext().getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),
                    this.fileName);
            MappedByteBuffer mbuffer = new FileInputStream(file).getChannel().map(
                    FileChannel.MapMode.READ_ONLY, 0, file.length());
            this.interpreter = new Interpreter(mbuffer);
            Log.d(MyApp.TAG, "interpreter is ready....");
        } catch (Exception ex) {
            Log.d(MyApp.TAG, "Exception:" + ex.getMessage());
        }
    }
    public int predict(float[] data){
        try {
            if(this.interpreter == null){setInterpreter();  return -1; }
            float[] input = data ;
            //Log.i(MyApp.TAG,"data:" + Arrays.toString(data));
            float[][] output = new float[1][3];
            this.interpreter.run(
                    input,
                    output);
            int ind = 0;
            for(int i=1;i<output[0].length;i++){
                if(output[0][i] > output[0][ind]) ind = i;
            }
            //Log.i("ann_app","index of result:"  + ind);
            //Log.i("ann_app","result:" + Arrays.toString(output[0]));
            return ind;
        }catch(Exception ex){
            Log.e("ann_app","exception",ex);
            return -1;
        }
    }
    public float[] getPrediction(float[] data){
        try {
            if(this.interpreter == null){setInterpreter();  return null; }
            float[] input = data ;
            float[][] output = new float[1][3];
            this.interpreter.run(
                    input,
                    output);

            return output[0];
        }catch(Exception ex){
            Log.e("ann_app","exception",ex);
            return null;
        }
    }
    public String getPredLabel(int ind){
        return labels.get(ind+"");
    }
}
