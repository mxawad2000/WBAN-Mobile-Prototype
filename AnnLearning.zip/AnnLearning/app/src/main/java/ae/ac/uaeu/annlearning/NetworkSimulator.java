package ae.ac.uaeu.annlearning;

import android.content.Intent;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Created by Mamoun.Awad on 8/26/2019.
 */

public class NetworkSimulator {
    private static NetworkSimulator instance = new NetworkSimulator();
    private static Random randomObj = new Random(System.currentTimeMillis());
    private NetworkSimulator() {
        init();
    }
    public static NetworkSimulator getInstance() {
        return instance;
    }
    List<TrafficEntry> traffic = new ArrayList();
    ////////////////////////////////////////////////////////////////////////////////////////////////
    private void init() {
        new Thread() {
            public void run() {
                try {
                    traffic.addAll( GenUtil.getTraffic());
                    Log.i(MyApp.TAG,"Size of Traffic:" + traffic.size());
                    Intent intent = new Intent();
                    intent.setAction(MainActivity.MainBroadcastReceiver.ACTION_TRAFFIC_ARRIVED);
                    MyApp.getAppContext().sendBroadcast(intent);
                } catch (Exception ex) {
                    Log.e(MyApp.TAG, "Error:", ex);
                }
            }
        }.start();
    }
    public TrafficEntry getRandomEntry(){
        int ind = randomObj.nextInt( traffic.size());
        return traffic.get(ind);
    }
}
