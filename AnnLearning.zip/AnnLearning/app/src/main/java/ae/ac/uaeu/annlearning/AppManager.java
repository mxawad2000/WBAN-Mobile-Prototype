package ae.ac.uaeu.annlearning;

import android.content.BroadcastReceiver;
import android.content.Intent;
import android.os.Environment;
import android.util.Base64;
import android.util.Log;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by Mamoun.Awad on 6/3/2019.
 */

public class AppManager {
    static File APP_DOC_PATH = MyApp.getAppContext().getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);

    private static AppManager instance = new AppManager();
    private AppManager(){init();}
    public static AppManager getInstance(){ return instance;}
    Map<String,PredModel> models = new HashMap<>();
    Map<String,SensorProfile> sensorProfileMap = new HashMap<>();
    ////////////////////////////////////////////////////////////////////////////////////////////////
    private void init() {
        new Thread() {
            public void run() {
                try {
                    boolean isOK = readModels();
                    if(!isOK ){
                        //download from firebase DB / CLoud..
                        Log.i(MyApp.TAG,"Downloading models...");
                        downloadKeys();
                    }else{
                        Intent intent = new Intent();
                        intent.setAction(MainActivity.MainBroadcastReceiver.ACTION_RETRIEVED);
                        MyApp.getAppContext().sendBroadcast(intent);
                    }
                } catch (Exception ex) {
                    Log.e(MyApp.TAG, "Error:", ex);
                }
            }
        }.start();
        new Thread() {
            public void run() {
                try {
                    sensorProfileMap.put("4",new SensorProfile());
                    boolean isOK = readSensorProfiles();
                    if(!isOK ){
                        //download from firebase DB / CLoud..
                        Log.i(MyApp.TAG,"Downloading Profiles...");
                        downloadSensorProfiles();
                    }else{
                        Intent intent = new Intent();
                        intent.setAction(MainActivity.MainBroadcastReceiver.ACTION_RETRIEVED);
                        MyApp.getAppContext().sendBroadcast(intent);
                    }
                } catch (Exception ex) {
                    Log.e(MyApp.TAG, "Error:", ex);
                }
            }
        }.start();
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    private boolean readModels(){
        try {
            Log.i(MyApp.TAG,"Reading the models from the storage.....");
            File path = MyApp.getAppContext().getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
            File[] files = path.listFiles();
            for(File file : files){
                addModel(file);
            }
            Log.d(MyApp.TAG,"keys:" + models.keySet().toString());
            return !models.isEmpty();
        } catch (Exception ex) {
            Log.e(MyApp.TAG, "Error:", ex);
            return false;
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    private boolean readSensorProfiles(){
        try {
            Log.i(MyApp.TAG,"Reading the models from the storage.....");
            File path = new File(MyApp.getAppContext().getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),
                    "sensor_profiles.obj");
            ObjectInputStream ois = new ObjectInputStream( new FileInputStream( path));
            Map<String,SensorProfile> map = (Map<String,SensorProfile>)ois.readObject();
            this.sensorProfileMap.putAll(map);
            Log.i(MyApp.TAG,"profiles:" + this.sensorProfileMap.toString());
            ois.close();
            return !this.sensorProfileMap.isEmpty();
        } catch (Exception ex) {
            Log.e(MyApp.TAG, "Error:", ex);
            return false;
        }
    }
    private void saveSensorProfiles(){
        try {
            Log.i(MyApp.TAG,"Saving the models from the storage.....");
            File path = new File (
                    MyApp.getAppContext().getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),
                "/sensor_profiles.obj");
            ObjectOutputStream ois = new ObjectOutputStream( new FileOutputStream( path ));
            ois.writeObject(this.sensorProfileMap);
            ois.close();
        } catch (Exception ex) {
            Log.e(MyApp.TAG, "Error: Failed to persist profiles...", ex);
        }
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////
    private void addModel(File file){
        Log.i(MyApp.TAG,"adding the model file:" + file.getName());
        if(file.getName().endsWith(".meta")){
            PredModel model = load_model(file);
            if(model == null) {
                Log.d(MyApp.TAG,"No model was read...");
                return;
            }
            models.put(model.modelId,model);
            //Log.i(MyApp.TAG,"New model was uploaded in memory:" + file.getName());
            notifyActivity(MainActivity.MainBroadcastReceiver.ACTION_RETRIEVED);
        }
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////
    public PredModel getModel(String key){
        return this.models.get(key);
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    public void save(String fn,byte[] content) {
        try{
            File file = new File( MyApp.getAppContext().getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),fn);
            FileOutputStream fstream = new FileOutputStream( file);
            fstream.write(content);
            fstream.close();
        } catch (Exception ex) {
            Log.e(MyApp.TAG, "Error:", ex);
        }
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////
    public void downloadKeys(){
        String[] keys = GenUtil.getModelKeys();
        for (String k : keys) {
            Log.i(MyApp.TAG,"Downloading the key:" + k);
            readModel(k);
        }
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////
    public void downloadSensorProfiles(){
        String[] keys = MyApp.getSensorProfiles();
        for (String k : keys) {
            //this is asynch call. We don't know when the data arrive.
            downloadSensorProfile(k);
            Log.i(MyApp.TAG,"Downloading the key:" + k );
            //save them, but you need to make sure that reading is over..
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    private void notifyActivity(String action){
        Intent intent = new Intent();
        intent.setAction(action);
        MyApp.getAppContext().sendBroadcast(intent);
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    AtomicInteger profileCount = new AtomicInteger(0);
    public void downloadSensorProfile(final String key){
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("sensor_profiles/" + key);
        Log.i(MyApp.TAG,"retrieving from FB the key:" + "sensor_profiles/" + key);
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                Iterator<DataSnapshot> iter = dataSnapshot.getChildren().iterator();
                //I know there is only one record...
                if(!iter.hasNext()) {
                    Log.i(MyApp.TAG,"Error reading, not found...");
                    profileCount.getAndIncrement();
                    Intent intent = new Intent();
                    intent.setAction(MainActivity.MainBroadcastReceiver.ACTION_FAULT_SENSOR_PROFILE_NOT_FOUND);
                    intent.putExtra("profile",key);
                    MyApp.getAppContext().sendBroadcast(intent);
                    if(profileCount.get() == MyApp.getNumSensors()) {
                        profileCount.set(0);
                        saveSensorProfiles();
                    }
                    return;
                }
                DataSnapshot rec = iter.next();
                String profileId = key;
                String fbKey = rec.getKey();
                Map<String,String> value = (Map<String,String>)rec.getValue();
                Log.d(MyApp.TAG,"retreived Profile value:" + value);
                SensorProfile profile = new SensorProfile();
                profile.setSensorId(value.get("id"));
                profile.setModel( value.get("model") );
                profile.setType( value.get ("type" ) ) ;
                profile.setDescription( value.get("description"));
                profile.setSerialNo(value.get("serial") );
                profile.setFt_dead_th( Float.parseFloat( value.get("ft_dead") ));
                profile.setFt_stuck_th( Float.parseFloat( value.get("ft_stuck") ));
                profile.setFt_spike_th( Float.parseFloat( value.get("ft_spike") ));
                profile.setMaxValue(Float.parseFloat(value.get("max_value")));
                profile.setMinValue(Float.parseFloat(value.get("min_value")));
                profile.setFt_battery_th(Float.parseFloat(value.get("ft_low_battery")));
                profile.setFt_hardware_th(Float.parseFloat(value.get("ft_hardware")));

                Log.i(MyApp.TAG,"Downloaded profile:" + profile.toString());
                sensorProfileMap.put(profile.getSensorId(), profile);
                profileCount.getAndIncrement();
                if(profileCount.get() == (MyApp.getNumSensors()-1)){
                    saveSensorProfiles();
                    profileCount.set(0);
                    Intent intent = new Intent();
                    intent.setAction(MainActivity.MainBroadcastReceiver.ACTION_SENSOR_PROFILES_DOWNLOAD_DONE);
                    MyApp.getAppContext().sendBroadcast(intent);
                }
            }
            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.i(MyApp.TAG, "Failed to read value.", error.toException());
            }

        });
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    public void readModel(final String key){
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("models/" + key);
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                Iterator<DataSnapshot> iter = dataSnapshot.getChildren().iterator();
                //I know there is only one record...
                if(!iter.hasNext()){
                    Log.i(MyApp.TAG,"Error: model was not found...");
                    Intent intent = new Intent();
                    intent.setAction(MainActivity.MainBroadcastReceiver.ACTION_FAULT_PREDICTION_MODEL_NOT_FOUND);
                    intent.putExtra("model",key);
                    MyApp.getAppContext().sendBroadcast(intent);
                    return;
                }
                DataSnapshot rec = iter.next();
                String modelId = key;
                String fbKey = rec.getKey();
                Map<String,String> value = (Map<String,String>)rec.getValue();
                Log.d(MyApp.TAG,"retreived value:" + value);
                byte[] binary = Base64.decode(value.get("binary"),Base64.DEFAULT);
                String date = value.get("create_at");
                String fn = value.get("file_name");
                String type = value.get("model_type");
                String labels = value.get("labels");
                if(type.equals("ann")){
                    ANNModel model = new ANNModel(modelId, fbKey,date,fn,type,binary);
                    model.setLabels(labels);
                    save( fn, binary );
                    File mfn = save_metadata(model);
                    Log.d(MyApp.TAG, "Value is: " + model);
                    //update the models..
                    addModel(mfn);
                }else if(type.equals("svm")){
                    Log.i(MyApp.TAG,"Reading the model key:" + fbKey);
                    SVMModel model = new SVMModel(modelId, fbKey,date,fn,type,binary);
                    //Log.i(MyApp.TAG,"retreived labels:" + labels);
                    model.setLabels(labels);
                    save( fn, binary );
                    File mfn = save_metadata(model);
                    Log.d(MyApp.TAG, "Value is: " + model);
                    addModel(mfn);
                }else if(type.equals("dt")){
                    Log.i(MyApp.TAG,"Reading the model key:" + fbKey);
                    DTreeModel model = new DTreeModel(modelId, fbKey,date,fn,type,binary);
                    //Log.i(MyApp.TAG,"retreived labels:" + labels);
                    model.setLabels(labels);
                    save( fn, binary );
                    File mfn = save_metadata(model);
                    Log.d(MyApp.TAG, "Value is: " + model);
                    addModel(mfn);
                }
            }
            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.i(MyApp.TAG, "Failed to read value.", error.toException());
            }
        });
    }
    private File save_metadata(PredModel model){
        try{
            File f = new File( APP_DOC_PATH, model.fileName + ".meta");
            BufferedWriter bw = new BufferedWriter( new FileWriter(f));
            bw.write(model.date+"\n");
            bw.write(model.fbKey+"\n");
            bw.write(model.modelId+"\n");
            bw.write(model.type+"\n");
            bw.write(model.fileName+"\n");
            bw.write(model.labels2String()+"\n");
            bw.close();
            return f;
        }catch(Exception ex){
            Log.d(MyApp.TAG,"Exception saving meta data:" + ex.getMessage());
            return null;
        }
    }
    private PredModel load_model(File metaFile){
        try{
            BufferedReader br = new BufferedReader( new FileReader(metaFile));
            String date = br.readLine();
            String fbKey = br.readLine();
            String modelId = br.readLine();
            String type = br.readLine();
            String fileName = br.readLine();
            String labels = br.readLine();
            br.close();
            PredModel model = null;
            if(type.equals("ann")){
                model = new ANNModel();
            }else if(type.equals("svm")){
                //model = new SVMModel();
                model = new SVMModel();
            }else if(type.equalsIgnoreCase("dt")){
                model = new DTreeModel();
            }
            model.fileName = fileName;
            model.fbKey = fbKey;
            model.modelId = modelId;
            model.type = type;
            model.date = date;
            model.setLabels(labels);
            model.setInterpreter();
            return model;
        }catch(Exception ex){
            Log.d(MyApp.TAG,"Exception saving meta data:" + ex.getMessage());
        }
        return null;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    public SensorProfile getSensorProfile(String key){
        return this.sensorProfileMap.get(key);
    }

}
