package ae.ac.uaeu.annlearning;

import java.util.Arrays;

/**
 * Created by Mamoun.Awad on 8/26/2019.
 */

public class TrafficEntry {
    float[] entry;
    String target,sensorID;
    float bioReading =0;
    public TrafficEntry(){}
    public TrafficEntry(float[] entry, String target){
        this.entry = entry;
        this.target = target;
    }
    public TrafficEntry(float[] entry, String target, String sensorID){
        this(entry,target);
        this.sensorID = sensorID;
    }
    public String toString(){
        return "Sensor:" + sensorID +":" + Arrays.toString(entry) + " -- > " + target;
    }
    public float getBioReading(){
        return MyApp.randObj.nextInt(200);
    }
}
