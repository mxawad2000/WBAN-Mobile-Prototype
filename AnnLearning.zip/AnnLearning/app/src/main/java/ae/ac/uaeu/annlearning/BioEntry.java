package ae.ac.uaeu.annlearning;

/**
 * Created by Mamoun.Awad on 9/21/2019.
 */

public class BioEntry {
    float temperature;
    float blood_pressure;
    //others...
}
