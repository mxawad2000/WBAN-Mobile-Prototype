package ae.ac.uaeu.annlearning;

import android.os.Environment;
import android.util.Log;
import android.widget.TextView;

import org.tensorflow.lite.Interpreter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Arrays;

import libsvm.svm;
import libsvm.svm_model;
import libsvm.svm_node;

/**
 * Created by Mamoun.Awad on 6/3/2019.
 */

public class SVMModel extends PredModel {
    private svm_model smodel;
    public SVMModel() { }
    public SVMModel(String modelId, String fbKey, String date, String fn, String type, byte[] content) {
        this.modelId = modelId;
        this.fbKey = fbKey;
        this.date = date;
        setFileName(fn);
        this.binary = content;
        this.type = type;
    }

    public static svm_node[] get_svm_node(float[] ref) {
        //Log.i(MyApp.TAG,"data:" + Arrays.toString(ref));
        svm_node[] x = new svm_node[ref.length];
        for (int i = 0; i < ref.length; i++) {
            svm_node node = new svm_node();
            node.index = i+1;
            node.value = ref[i];
            x[i] = node;
        }
        return x;
    }
    public int predict(float[] data){
        double res = svm.svm_predict(smodel,get_svm_node(data));
        return (int)res;
    }

    public void setInterpreter() {
        if(smodel != null) return;
        try {
            File file = new File(MyApp.getAppContext().getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),
                    this.fileName);
            this.smodel = svm.svm_load_model(file.getAbsolutePath());
        } catch (Exception ex) {
            Log.d(MyApp.TAG, "Exception:" + ex.getMessage());
        }
    }
    public String getPredLabel(int ind){
        //Log.i(MyApp.TAG,"predicted index:" + ind);
        return labels.get(ind +"");
    }
}
